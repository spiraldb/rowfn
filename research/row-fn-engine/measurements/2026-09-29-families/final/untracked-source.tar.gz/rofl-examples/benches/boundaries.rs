// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Compare collection, complete invocation, and the retained Vortex executor in one binary.
//!
//! The workspace bench profile uses 16 CGUs without LTO. Keep compiler, target features, allocator,
//! and profile identical for every result, especially the deferred Boolean retry comparisons.

use std::sync::Arc;

use arrow_array::{Array, ArrayRef, BooleanArray, Int64Array};
use arrow_buffer::NullBuffer;
use arrow_schema::Field;
use divan::Bencher;
use divan::black_box;
use rofl::{OutputBinding, OutputBuffer};
use rofl::kernels::lane_kernels::LaneZip;
use rofl_arrow::{ArrowHost, ArrowOperand};
use rofl_examples::{Add, NoOptions, PositiveSum};
use vortex_array::{ArrayRef as VortexArrayRef, IntoArray, VortexSessionExecute, array_session};
use vortex_array::arrays::{ConstantArray, PrimitiveArray};
use vortex_array::dtype::DType;
use vortex_array::scalar_fn::{EmptyOptions, ScalarFnId, VecExecutionArgs};
use vortex_array::scalar_fn::unstable::rofl::{self as adapter, VortexHost};
use vortex_array::scalar_fn::unstable::row::{self as legacy, RowFn as LegacyRowFn};
use vortex_array::validity::Validity;
use vortex_error::{VortexExpect, VortexResult, vortex_ensure};
use vortex_session::registry::CachedId;

const SIZES: &[usize] = &[0, 1, 64, 1024, 16_384];

fn main() {
    divan::main();
}

fn values(rows: usize) -> Vec<i64> {
    (0..rows).map(|row| i64::try_from(row % 1024).vortex_expect("fixture is below 1024")).collect()
}

fn operand(column: ArrayRef, scalar: bool) -> ArrowOperand {
    ArrowOperand {
        dtype: Field::new("input", column.data_type().clone(), column.null_count() != 0),
        column,
        scalar,
    }
}

#[divan::bench(consts = SIZES)]
fn direct_typed_collection<const ROWS: usize>(bencher: Bencher) {
    let lhs = values(ROWS);
    let rhs = values(ROWS);
    bencher.bench(|| {
        let mut output = <ArrowHost as OutputBinding<i64>>::allocate(ROWS, &mut ()).vortex_expect("benchmark fixtures must satisfy the selected signature");
        for ((slot, lhs), rhs) in output.slots().iter_mut().zip(black_box(&lhs)).zip(black_box(&rhs)) {
            slot.write(lhs.wrapping_add(*rhs));
        }
        // SAFETY: the fixed output allocation and both inputs contain exactly ROWS elements.
        unsafe { output.finish(ROWS) }
    });
}

#[divan::bench(consts = SIZES)]
fn shared_collection<const ROWS: usize>(bencher: Bencher) {
    let lhs = values(ROWS);
    let rhs = values(ROWS);
    bencher.bench(|| {
        let source = LaneZip::new(black_box(lhs.as_slice()), black_box(rhs.as_slice()));
        <ArrowHost as OutputBinding<i64>>::build_from(source, |(lhs, rhs)| lhs.wrapping_add(rhs), &mut ()).vortex_expect("benchmark fixtures must satisfy the selected signature")
    });
}

#[divan::bench(consts = SIZES)]
fn shared_executor<const ROWS: usize>(bencher: Bencher) {
    let inputs = [
        operand(Arc::new(Int64Array::from(values(ROWS))), false),
        operand(Arc::new(Int64Array::from(values(ROWS))), false),
    ];
    let output = rofl_arrow::plan(&Add::<false>, &NoOptions, &inputs.each_ref().map(|input| input.dtype.clone())).vortex_expect("benchmark fixtures must satisfy the selected signature");
    bencher.bench(|| {
        rofl::execute::<ArrowHost, _>(&Add::<false>, &NoOptions, black_box(&inputs), ROWS, &output, &mut ()).vortex_expect("benchmark fixtures must satisfy the selected signature")
    });
}

#[divan::bench(consts = SIZES, args = [false, true])]
fn arrow_invocation<const ROWS: usize>(bencher: Bencher, scalar: bool) {
    let inputs = [
        operand(Arc::new(Int64Array::from(values(ROWS))), false),
        operand(Arc::new(Int64Array::from(if scalar { vec![1] } else { values(ROWS) })), scalar),
    ];
    let output = rofl_arrow::plan(&Add::<false>, &NoOptions, &inputs.each_ref().map(|input| input.dtype.clone())).vortex_expect("benchmark fixtures must satisfy the selected signature");
    bencher.bench(|| rofl_arrow::invoke(&Add::<false>, &NoOptions, black_box(&inputs), ROWS, output.clone()).vortex_expect("benchmark fixtures must satisfy the selected signature"));
}

#[divan::bench(consts = SIZES, args = [false, true])]
fn arrow_native_wrapping_add<const ROWS: usize>(bencher: Bencher, scalar: bool) {
    let lhs = Int64Array::from(values(ROWS));
    let rhs = Int64Array::from(values(ROWS));
    let constant = Int64Array::new_scalar(1);
    bencher.bench(|| {
        if scalar {
            arrow_arith::numeric::add_wrapping(black_box(&lhs), black_box(&constant)).vortex_expect("benchmark fixtures must satisfy the selected signature")
        } else {
            arrow_arith::numeric::add_wrapping(black_box(&lhs), black_box(&rhs)).vortex_expect("benchmark fixtures must satisfy the selected signature")
        }
    });
}

#[derive(Clone)]
struct LegacyAdd;
impl LegacyRowFn for LegacyAdd {
    type Options = EmptyOptions;
    const ARG_NAMES: &'static [&'static str] = &["lhs", "rhs"];
    const INFALLIBLE: bool = true;
    fn id(&self) -> ScalarFnId {
        static ID: CachedId = CachedId::new("bench.rofl.legacy_add");
        *ID
    }
    fn dispatch<V: legacy::RowVisitor>(&self, _: &EmptyOptions, _: &[DType], visitor: V)
        -> VortexResult<V::VisitResult> {
        visitor.visit::<(i64, i64), i64>(|(lhs, rhs)| lhs.wrapping_add(rhs))
    }
}

#[derive(Clone)]
struct LegacyPredicate<const MULTIVERSIONED: bool>;
impl<const MULTIVERSIONED: bool> LegacyRowFn for LegacyPredicate<MULTIVERSIONED> {
    type Options = EmptyOptions;
    const ARG_NAMES: &'static [&'static str] = &["lhs", "rhs"];
    const INFALLIBLE: bool = false;
    fn id(&self) -> ScalarFnId {
        static ID: CachedId = CachedId::new("bench.rofl.legacy_predicate");
        *ID
    }
    fn dispatch<V: legacy::RowVisitor>(&self, _: &EmptyOptions, _: &[DType], visitor: V)
        -> VortexResult<V::VisitResult> {
        visitor.visit_deferred_bool::<(i64, i64), bool, MULTIVERSIONED>(|(lhs, rhs)| {
            let (sum, failed) = lhs.overflowing_add(rhs);
            (sum > 0, failed)
        }, |failed| {
            vortex_ensure!(!failed, "integer overflow in positive sum");
            Ok(())
        })
    }
}

#[divan::bench(consts = SIZES, args = [false, true])]
fn vortex_add<const ROWS: usize>(bencher: Bencher, extracted: bool) {
    let inputs = [PrimitiveArray::from_iter(values(ROWS)).into_array(), ConstantArray::new(1i64, ROWS).into_array()];
    let output = rofl::plan::<VortexHost, _>(&Add::<false>, &NoOptions, &inputs.each_ref().map(|array| array.dtype().clone())).vortex_expect("benchmark fixtures must satisfy the selected signature");
    let args = VecExecutionArgs::new(inputs.to_vec(), ROWS);
    let session = array_session();
    bencher.with_inputs(|| session.create_execution_ctx()).bench_refs(|ctx| {
        if extracted {
            adapter::execute(&Add::<false>, &NoOptions, black_box(&inputs), ROWS, output.output_type(), ctx).vortex_expect("benchmark fixtures must satisfy the selected signature")
        } else {
            legacy::execute_rows(&LegacyAdd, &EmptyOptions, black_box(&args), ctx).vortex_expect("benchmark fixtures must satisfy the selected signature")
        }
    });
}

#[derive(Clone, Copy, Debug)]
enum BoolHost { LegacyVortex, ExtractedVortex, Arrow, ArrowBaseline }
const BOOL_HOSTS: &[BoolHost] = &[BoolHost::LegacyVortex, BoolHost::ExtractedVortex, BoolHost::Arrow, BoolHost::ArrowBaseline];

#[divan::bench(args = BOOL_HOSTS, consts = [false, true])]
fn nullable_bool<const NULL_FAILURE: bool>(bencher: Bencher, host: &BoolHost) {
    const ROWS: usize = 16_384;
    let valid: Vec<_> = (0..ROWS).map(|row| !row.is_multiple_of(8)).collect();
    let values: Vec<_> = values(ROWS).into_iter().zip(&valid)
        .map(|(value, valid)| if NULL_FAILURE && !valid { i64::MAX } else { value }).collect();
    let lhs = Int64Array::new(values.clone().into(), Some(NullBuffer::from(valid.clone())));
    let inputs = [operand(Arc::new(lhs.clone()), false), operand(Arc::new(Int64Array::from(vec![1])), true)];
    let arrow_output = rofl_arrow::plan(&PositiveSum::<true>, &NoOptions, &inputs.each_ref().map(|input| input.dtype.clone())).vortex_expect("benchmark fixtures must satisfy the selected signature");
    let vortex: [VortexArrayRef; 2] = [
        PrimitiveArray::new(values, Validity::from_iter(valid)).into_array(),
        ConstantArray::new(1i64, ROWS).into_array(),
    ];
    let output = rofl::plan::<VortexHost, _>(&PositiveSum::<true>, &NoOptions, &vortex.each_ref().map(|array| array.dtype().clone())).vortex_expect("benchmark fixtures must satisfy the selected signature");
    let args = VecExecutionArgs::new(vortex.to_vec(), ROWS);
    let session = array_session();
    bencher.with_inputs(|| session.create_execution_ctx()).bench_refs(|ctx| {
        match host {
            BoolHost::LegacyVortex => { black_box(legacy::execute_rows(&LegacyPredicate::<true>, &EmptyOptions, &args, ctx).vortex_expect("benchmark fixtures must satisfy the selected signature")); }
            BoolHost::ExtractedVortex => { black_box(adapter::execute(&PositiveSum::<true>, &NoOptions, &vortex, ROWS, output.output_type(), ctx).vortex_expect("benchmark fixtures must satisfy the selected signature")); }
            BoolHost::Arrow => { black_box(rofl_arrow::invoke(&PositiveSum::<true>, &NoOptions, &inputs, ROWS, arrow_output.clone()).vortex_expect("benchmark fixtures must satisfy the selected signature")); }
            BoolHost::ArrowBaseline => {
                // This baseline observes errors only on valid rows, matching strict row semantics.
                let output = BooleanArray::from_iter(lhs.iter().map(|value| value.map(|value| {
                    value.checked_add(1).vortex_expect("only null fixture payloads can overflow") > 0
                })));
                black_box(output);
            }
        }
    });
}
