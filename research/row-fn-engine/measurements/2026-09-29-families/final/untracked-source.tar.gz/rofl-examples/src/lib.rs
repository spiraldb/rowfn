// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Portable proof functions, their semantic host mappings, and downstream timestamp bindings.
//!
//! Function bodies import only `rofl` and the small capabilities defined here. Adapter mappings
//! and cross-host fixtures live in this package so the independent crates never depend on Vortex.

#![deny(missing_docs)]

mod domains;
pub use domains::*;

mod functions;
pub use functions::*;

mod integer_kernels;
pub use integer_kernels::*;

mod float_kernels;
pub use float_kernels::*;

mod comparisons;
pub use comparisons::*;

mod like;
pub use like::{Like, RegexpIsMatch};

mod substring;
pub use substring::{SubstringBytes, SubstringChars};

mod text;
mod text_length;
mod text_length_bindings;
pub use text::{Concat, StringPredicate};
pub use text_length::{BitLength, ByteLength, TextLengthHost};

mod mappings;
mod timestamp;

mod registration;
pub use registration::SevenPlugin;
