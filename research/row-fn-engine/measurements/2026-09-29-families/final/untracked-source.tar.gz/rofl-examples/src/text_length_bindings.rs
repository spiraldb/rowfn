// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Native width mapping for portable UTF-8 length functions.

use arrow_schema::ArrowError;
use arrow_schema::DataType;
use arrow_schema::Field;
use rofl::InputBinding;
use rofl::Utf8;
use rofl_arrow::ArrowHost;
use vortex_array::dtype::DType;
use vortex_array::scalar_fn::unstable::rofl::VortexHost;
use vortex_error::VortexResult;

use crate::TextLengthHost;

impl TextLengthHost for ArrowHost {
    fn large_utf8(dtype: &Field) -> Result<bool, ArrowError> {
        <Self as InputBinding<Utf8>>::validate(dtype)?;
        Ok(dtype.data_type() == &DataType::LargeUtf8)
    }
}

impl TextLengthHost for VortexHost {
    fn large_utf8(dtype: &DType) -> VortexResult<bool> {
        <Self as InputBinding<Utf8>>::validate(dtype)?;
        Ok(false)
    }
}
