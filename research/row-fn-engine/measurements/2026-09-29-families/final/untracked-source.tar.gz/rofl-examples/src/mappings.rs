// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Native semantic mappings. Function dispatch rules remain in the shared function definitions.

use arrow_schema::{ArrowError, DataType, Field};
use rofl::{Host, InputBinding};
use rofl_arrow::ArrowHost;
use vortex_array::dtype::{DType, PType};
use vortex_array::scalar_fn::unstable::rofl::VortexHost;
use vortex_error::{VortexResult, vortex_bail};

use crate::{ComparisonHost, ComparisonKind, FloatWidth, Integer, IntegerHost, ListHost, TextComparisonHost};

impl IntegerHost for VortexHost {
    fn integer(dtype: &DType) -> VortexResult<Integer> {
        Ok(match dtype {
            DType::Primitive(PType::I8, _) => Integer::I8,
            DType::Primitive(PType::I16, _) => Integer::I16,
            DType::Primitive(PType::I32, _) => Integer::I32,
            DType::Primitive(PType::I64, _) => Integer::I64,
            DType::Primitive(PType::U8, _) => Integer::U8,
            DType::Primitive(PType::U16, _) => Integer::U16,
            DType::Primitive(PType::U32, _) => Integer::U32,
            DType::Primitive(PType::U64, _) => Integer::U64,
            _ => vortex_bail!("expected semantic integer input, got {dtype}"),
        })
    }
}
impl IntegerHost for ArrowHost {
    fn integer(dtype: &Field) -> Result<Integer, ArrowError> {
        if dtype.metadata().contains_key("ARROW:extension:name") {
            return Err(Self::error("unknown extension is not an integer domain"));
        }
        Ok(match dtype.data_type() {
            DataType::Int8 => Integer::I8, DataType::Int16 => Integer::I16,
            DataType::Int32 => Integer::I32, DataType::Int64 => Integer::I64,
            DataType::UInt8 => Integer::U8, DataType::UInt16 => Integer::U16,
            DataType::UInt32 => Integer::U32, DataType::UInt64 => Integer::U64,
            _ => return Err(Self::error("expected semantic integer input")),
        })
    }
}
impl ComparisonHost for VortexHost {
    fn comparison_kind(dtype: &DType) -> VortexResult<ComparisonKind> {
        match dtype {
            DType::Primitive(PType::F32, _) => Ok(ComparisonKind::Float32),
            DType::Primitive(PType::F64, _) => Ok(ComparisonKind::Float64),
            _ => Self::integer(dtype).map(ComparisonKind::Integer),
        }
    }
}
impl TextComparisonHost for VortexHost {
    fn validate_text_pair(lhs: &DType, rhs: &DType) -> VortexResult<()> {
        if !matches!(lhs, DType::Utf8(_)) {
            vortex_bail!("expected UTF-8 comparison input, got {lhs}");
        }
        if !matches!(rhs, DType::Utf8(_)) {
            vortex_bail!("expected UTF-8 comparison input, got {rhs}");
        }

        Ok(())
    }
}
impl ComparisonHost for ArrowHost {
    fn comparison_kind(dtype: &Field) -> Result<ComparisonKind, ArrowError> {
        if dtype.metadata().contains_key("ARROW:extension:name") {
            return Err(Self::error("unknown extension is not a numeric comparison domain"));
        }

        match dtype.data_type() {
            DataType::Float32 => Ok(ComparisonKind::Float32),
            DataType::Float64 => Ok(ComparisonKind::Float64),
            _ => Self::integer(dtype).map(ComparisonKind::Integer),
        }
    }
}
impl TextComparisonHost for ArrowHost {
    fn validate_text_pair(lhs: &Field, rhs: &Field) -> Result<(), ArrowError> {
        if lhs.metadata().contains_key("ARROW:extension:name")
            || rhs.metadata().contains_key("ARROW:extension:name")
            || !matches!(lhs.data_type(), DataType::Utf8 | DataType::LargeUtf8 | DataType::Utf8View)
            || lhs.data_type() != rhs.data_type()
        {
            return Err(Self::error("Arrow string comparisons require matching non-extension types"));
        }

        Ok(())
    }
}
impl ListHost for VortexHost {
    fn list_shape(dtype: &DType) -> VortexResult<(FloatWidth, usize)> {
        match dtype {
            DType::FixedSizeList(child, width, _) => match child.as_ref() {
                DType::Primitive(PType::F32, _) => {
                    <Self as InputBinding<rofl::FixedSizeList<f32>>>::validate(dtype)?;
                    Ok((FloatWidth::F32, *width as usize))
                }
                DType::Primitive(PType::F64, _) => {
                    <Self as InputBinding<rofl::FixedSizeList<f64>>>::validate(dtype)?;
                    Ok((FloatWidth::F64, *width as usize))
                }
                _ => vortex_bail!("expected float list children, got {child}"),
            },
            _ => vortex_bail!("expected fixed-size list, got {dtype}"),
        }
    }
}
impl ListHost for ArrowHost {
    fn list_shape(dtype: &Field) -> Result<(FloatWidth, usize), ArrowError> {
        let DataType::FixedSizeList(child, width) = dtype.data_type() else {
            return Err(Self::error("expected fixed-size list"));
        };
        let width = usize::try_from(*width).map_err(|_| Self::error("list width must be nonnegative"))?;
        match child.data_type() {
            DataType::Float32 => {
                <Self as InputBinding<rofl::FixedSizeList<f32>>>::validate(dtype)?;
                Ok((FloatWidth::F32, width))
            }
            DataType::Float64 => {
                <Self as InputBinding<rofl::FixedSizeList<f64>>>::validate(dtype)?;
                Ok((FloatWidth::F64, width))
            }
            _ => Err(Self::error("expected float list children")),
        }
    }
}
