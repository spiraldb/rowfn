// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Downstream timestamp bindings, legal because the row kind is local to this package.

use arrow_array::{ArrayRef as ArrowArrayRef, PrimitiveArray as ArrowPrimitiveArray};
use arrow_array::types::{TimestampSecondType, TimestampMillisecondType, TimestampMicrosecondType, TimestampNanosecondType};
use arrow_buffer::ScalarBuffer;
use arrow_schema::{ArrowError, DataType, Field, TimeUnit as ArrowTimeUnit};
use rofl::{Host, InputBinding, RowView};
use rofl_arrow::ArrowHost;
use vortex_array::{ArrayRef, ExecutionCtx};
use vortex_array::arrays::{ExtensionArray, PrimitiveArray};
use vortex_array::arrays::extension::ExtensionArrayExt;
use vortex_array::dtype::{DType, Nullability};
use vortex_array::extension::datetime::{TimeUnit, Timestamp};
use vortex_array::scalar_fn::unstable::rofl::VortexHost;
use vortex_buffer::Buffer;
use vortex_error::{VortexResult, vortex_bail, vortex_ensure};

use crate::{TimestampHost, TimestampTicks};

/// A borrowed tick slice with timestamp semantics established at binding.
pub struct TicksView<'a>(&'a [i64]);
// SAFETY: a retained primitive slice has stable initialized values at every index below its length.
unsafe impl<'a> RowView<'a, TimestampTicks> for TicksView<'a> {
    fn len(&self) -> usize { self.0.len() }
    unsafe fn get_unchecked(&self, index: usize) -> i64 {
        // SAFETY: the caller bounds index by this retained slice length.
        unsafe { *self.0.get_unchecked(index) }
    }
}
impl TimestampHost for VortexHost {
    fn timestamp_label(dtype: &DType) -> VortexResult<DType> {
        let DType::Extension(extension) = dtype else { vortex_bail!("expected timestamp extension, got {dtype}"); };
        let Some(metadata) = extension.metadata_opt::<Timestamp>() else { vortex_bail!("unknown extension is not timestamp ticks"); };
        vortex_ensure!(metadata.unit != TimeUnit::Days, "timestamp tick adapter does not support day units");
        Ok(dtype.with_nullability(Nullability::NonNullable))
    }
}
impl InputBinding<TimestampTicks> for VortexHost {
    type Decoded = Buffer<i64>;
    type View<'a> = TicksView<'a>;
    const DENSE_SAFE: bool = true;
    const DECODE_INFALLIBLE: bool = true;
    fn validate(dtype: &DType) -> VortexResult<()> { Self::timestamp_label(dtype).map(|_| ()) }
    fn decode(column: &ArrayRef, scalar: bool, ctx: &mut ExecutionCtx) -> VortexResult<Buffer<i64>> {
        let column = vortex_array::scalar_fn::unstable::rofl::decoded_input(column, scalar)?;
        let extension = column.execute::<ExtensionArray>(ctx)?;
        Ok(extension.storage_array().clone().execute::<PrimitiveArray>(ctx)?.into_buffer::<i64>())
    }
    fn can_decode_null_tolerant(_: &ArrayRef) -> VortexResult<bool> { Ok(true) }
    fn view(decoded: &Buffer<i64>) -> TicksView<'_> { TicksView(decoded.as_slice()) }
}
impl TimestampHost for ArrowHost {
    fn timestamp_label(dtype: &Field) -> Result<Field, ArrowError> {
        if !matches!(dtype.data_type(), DataType::Timestamp(_, _)) || dtype.metadata().contains_key("ARROW:extension:name") {
            return Err(Self::error("expected native Arrow timestamp ticks"));
        }
        Ok(dtype.clone().with_name("result").with_nullable(false))
    }
}
impl InputBinding<TimestampTicks> for ArrowHost {
    type Decoded = ScalarBuffer<i64>;
    type View<'a> = TicksView<'a>;
    const DENSE_SAFE: bool = true;
    const DECODE_INFALLIBLE: bool = true;
    fn validate(dtype: &Field) -> Result<(), ArrowError> { Self::timestamp_label(dtype).map(|_| ()) }
    fn decode(column: &ArrowArrayRef, _: bool, _: &mut ()) -> Result<ScalarBuffer<i64>, ArrowError> {
        macro_rules! ticks {
            ($t:ty) => { column.as_any().downcast_ref::<ArrowPrimitiveArray<$t>>()
                .map(|array| array.values().clone()).ok_or_else(|| Self::error("timestamp storage downcast failed")) };
        }
        match column.data_type() {
            DataType::Timestamp(ArrowTimeUnit::Second, _) => ticks!(TimestampSecondType),
            DataType::Timestamp(ArrowTimeUnit::Millisecond, _) => ticks!(TimestampMillisecondType),
            DataType::Timestamp(ArrowTimeUnit::Microsecond, _) => ticks!(TimestampMicrosecondType),
            DataType::Timestamp(ArrowTimeUnit::Nanosecond, _) => ticks!(TimestampNanosecondType),
            _ => Err(Self::error("expected timestamp storage")),
        }
    }
    fn can_decode_null_tolerant(_: &ArrowArrayRef) -> Result<bool, ArrowError> { Ok(true) }
    fn view(decoded: &ScalarBuffer<i64>) -> TicksView<'_> { TicksView(decoded.as_ref()) }
}
