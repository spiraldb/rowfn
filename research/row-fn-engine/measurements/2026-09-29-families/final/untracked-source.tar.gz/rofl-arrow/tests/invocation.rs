// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Complete invocation also has a fixture that compiles without any Vortex dependency.

use std::sync::Arc;

use arrow_array::Int64Array;
use arrow_schema::ArrowError;
use arrow_schema::DataType;
use arrow_schema::Field;
use rofl::Host;
use rofl::HostResult;
use rofl::InputBinding;
use rofl::OutputBinding;
use rofl::RowFn;
use rofl::RowVisitor;
use rofl_arrow::ArrowOperand;

#[derive(Clone)]
struct Increment;

impl<H> RowFn<H> for Increment
where
    H: Host + InputBinding<i64> + OutputBinding<i64>,
{
    type Options = ();
    const ARG_NAMES: &'static [&'static str] = &["value"];
    const INFALLIBLE: bool = true;

    fn dispatch<V: RowVisitor<H>>(
        &self,
        _: &(),
        _: &[H::NativeType],
        visitor: V,
    ) -> HostResult<H, V::VisitResult> {
        visitor.visit::<(i64,), i64>(|(value,)| value.wrapping_add(1))
    }
}

#[test]
fn independent_arrow_invocation_preserves_nullable_values() -> Result<(), ArrowError> {
    let input = ArrowOperand {
        column: Arc::new(Int64Array::from(vec![Some(i64::MAX), None, Some(-2)])),
        dtype: Field::new("value", DataType::Int64, true),
        scalar: false,
    };
    let field = rofl_arrow::plan(&Increment, &(), &[input.dtype.clone()])?;
    let result = rofl_arrow::invoke(&Increment, &(), &[input], 3, field.clone())?;
    let values = result.array.as_any().downcast_ref::<Int64Array>().unwrap();

    assert_eq!(values.iter().collect::<Vec<_>>(), vec![Some(i64::MIN), None, Some(-1)]);
    assert_eq!(result.field, field);
    Ok(())
}
