// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Strict numeric comparisons shared by the Vortex and Arrow hosts.
//!
//! Each comparison uses the same runtime width dispatch and row operation on both hosts. Null
//! propagation belongs to the shared executor. Floating values use IEEE totalOrder as Arrow does,
//! so signed zero and distinct NaN bit patterns retain their ordering.

use std::cmp::Ordering;

use rofl::{HostResult, RowFn, RowVisitor};

use crate::{ComparisonHost, ComparisonKind, Integer, NoOptions};

macro_rules! float_comparison {
    ($lhs:ident, $rhs:ident, ==) => { $lhs.to_bits() == $rhs.to_bits() };
    ($lhs:ident, $rhs:ident, !=) => { $lhs.to_bits() != $rhs.to_bits() };
    ($lhs:ident, $rhs:ident, <) => { $lhs.total_cmp(&$rhs) < Ordering::Equal };
    ($lhs:ident, $rhs:ident, <=) => { $lhs.total_cmp(&$rhs) <= Ordering::Equal };
    ($lhs:ident, $rhs:ident, >) => { $lhs.total_cmp(&$rhs) > Ordering::Equal };
    ($lhs:ident, $rhs:ident, >=) => { $lhs.total_cmp(&$rhs) >= Ordering::Equal };
}

macro_rules! define_comparison {
    ($name:ident, $description:literal, $operator:tt) => {
        #[doc = $description]
        #[derive(Clone, Copy)]
        pub struct $name;

        impl<H: ComparisonHost> RowFn<H> for $name {
            type Options = NoOptions;

            const ARG_NAMES: &'static [&'static str] = &["lhs", "rhs"];
            const INFALLIBLE: bool = true;

            fn dispatch<V: RowVisitor<H>>(
                &self,
                _: &NoOptions,
                args: &[H::NativeType],
                visitor: V,
            ) -> HostResult<H, V::VisitResult> {
                match H::comparison_kind(&args[0])? {
                    ComparisonKind::Integer(kind) => match kind {
                        Integer::I8 => visitor.visit_bool::<(i8, i8), false>(|(a, b)| a $operator b),
                        Integer::I16 => visitor.visit_bool::<(i16, i16), false>(|(a, b)| a $operator b),
                        Integer::I32 => visitor.visit_bool::<(i32, i32), false>(|(a, b)| a $operator b),
                        Integer::I64 => visitor.visit_bool::<(i64, i64), false>(|(a, b)| a $operator b),
                        Integer::U8 => visitor.visit_bool::<(u8, u8), false>(|(a, b)| a $operator b),
                        Integer::U16 => visitor.visit_bool::<(u16, u16), false>(|(a, b)| a $operator b),
                        Integer::U32 => visitor.visit_bool::<(u32, u32), false>(|(a, b)| a $operator b),
                        Integer::U64 => visitor.visit_bool::<(u64, u64), false>(|(a, b)| a $operator b),
                    },
                    ComparisonKind::Float32 => visitor.visit_bool::<(f32, f32), false>(|(a, b)| {
                        float_comparison!(a, b, $operator)
                    }),
                    ComparisonKind::Float64 => visitor.visit_bool::<(f64, f64), false>(|(a, b)| {
                        float_comparison!(a, b, $operator)
                    }),
                }
            }
        }
    };
}

define_comparison!(Equal, "Strict numeric equality.", ==);
define_comparison!(NotEqual, "Strict numeric inequality.", !=);
define_comparison!(LessThan, "Strict numeric less-than comparison.", <);
define_comparison!(LessThanOrEqual, "Strict numeric less-than-or-equal comparison.", <=);
define_comparison!(GreaterThan, "Strict numeric greater-than comparison.", >);
define_comparison!(GreaterThanOrEqual, "Strict numeric greater-than-or-equal comparison.", >=);
