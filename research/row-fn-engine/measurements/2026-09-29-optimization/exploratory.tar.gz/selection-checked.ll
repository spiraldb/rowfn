; boundaries-3c3a77a76c6fcdfa.boundaries.ecd45eb892372cfc-cgu.03.rcgu.ll
; <core::iter::adapters::map::Map<core::slice::iter::Iter<rofl::host::Operand<rofl_arrow::ArrowHost>>, rofl_arrow::invoke<rofl_examples::functions::PositiveSum<true>>::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::GenericShunt<core::iter::adapters::map::Map<core::slice::iter::Iter<rofl::host::Operand<rofl_arrow::ArrowHost>>, rofl_arrow::invoke<rofl_examples::functions::PositiveSum<true>>::{closure#0}>, core::result::Result<core::convert::Infallible, arrow_schema::error::ArrowError>> as core::iter::traits::iterator::Iterator>::try_fold<(), core::iter::traits::iterator::Iterator::try_for_each::call<rofl::host::Operand<rofl_arrow::ArrowHost>, core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>, core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>::Break>::{closure#0}, core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>>::{closure#0}, core::ops::control_flow::ControlFlow<core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>>>
define hidden void @_RINvXs0_NtNtNtCslWxY2MhVcag_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENCINvB20_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEEB3V_8try_folduNCINvNvB3V_12try_for_each4callB1n_INtNtNtBc_3ops12control_flow11ControlFlowB1n_ENcNtB7y_5Break0E0B7y_E0IB7z_B7y_EECskkDzpO6M0zw_10boundaries(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([136 x i8]) align 8 captures(none) dereferenceable(136) %_0, ptr noalias nofree noundef align 8 captures(none) dereferenceable(16) %self, ptr noalias nofree noundef nonnull readnone captures(none) %g.0, ptr noalias nofree noundef align 8 captures(none) dereferenceable(32) %g.1) unnamed_addr #0 personality ptr @rust_eh_personality !dbg !2763 {
start:
  %_8.sroa.4.i.i.i = alloca [128 x i8], align 8
  %_16.i.i.i = alloca [112 x i8], align 8
  %_15.sroa.6.i.i.i = alloca [32 x i8], align 8
  %_11.i.i.i = alloca [32 x i8], align 8
  %_9.i.i.i = alloca [16 x i8], align 8
  %_7.i.i = alloca [136 x i8], align 8
  %_5.sroa.4.i.i = alloca [32 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !2764), !dbg !2767
  tail call void @llvm.experimental.noalias.scope.decl(metadata !2768), !dbg !2767
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.4.i.i.i)
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %ptr.i19.i = load ptr, ptr %self, align 8, !dbg !2770, !alias.scope !2777, !noalias !2764, !nonnull !28, !noundef !28
  %end_or_len.i20.i = load ptr, ptr %0, align 8, !dbg !2780, !alias.scope !2777, !noalias !2764, !nonnull !28, !noundef !28
  %_6.i21.i = icmp eq ptr %ptr.i19.i, %end_or_len.i20.i, !dbg !2782
  br i1 %_6.i21.i, label %_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvB1m_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit, label %bb3.lr.ph.i, !dbg !2786

bb3.lr.ph.i:                                      ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 8
  %2 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 16
  %3 = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 8
  %4 = getelementptr inbounds nuw i8, ptr %_16.i.i.i, i64 8
  %_32.sroa.5.0._16.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i, i64 40
  %_8.sroa.0.sroa.6.0._0.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 40
  %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 8
  %_8.sroa.5.0._0.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 112
  %_8.sroa.6.0._0.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 120
  %_8.sroa.7.0._0.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 128
  %_8.sroa.4.40._8.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_8.sroa.4.i.i.i, i64 32
  br label %bb3.i, !dbg !2786

bb3.i:                                            ; preds = %bb7.i, %bb3.lr.ph.i
  %ptr.i22.i = phi ptr [ %ptr.i19.i, %bb3.lr.ph.i ], [ %ptr.i.i, %bb7.i ]
  %_16.i.i = getelementptr inbounds nuw i8, ptr %ptr.i22.i, i64 136, !dbg !2787
  store ptr %_16.i.i, ptr %self, align 8, !dbg !2790, !alias.scope !2777, !noalias !2764
  call void @llvm.experimental.noalias.scope.decl(metadata !2791), !dbg !2794
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.sroa.4.i.i), !dbg !2795
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i.i), !dbg !2798, !noalias !2799
  call void @llvm.experimental.noalias.scope.decl(metadata !2801), !dbg !2798
  call void @llvm.experimental.noalias.scope.decl(metadata !2804), !dbg !2798
  %5 = getelementptr inbounds nuw i8, ptr %ptr.i22.i, i64 112, !dbg !2806
  %_22.0.i.i.i = load ptr, ptr %5, align 8, !dbg !2806, !alias.scope !2819, !noalias !2820, !nonnull !28, !noundef !28
  %6 = getelementptr inbounds nuw i8, ptr %ptr.i22.i, i64 120, !dbg !2806
  %_22.1.i.i.i = load ptr, ptr %6, align 8, !dbg !2806, !alias.scope !2819, !noalias !2820, !nonnull !28, !align !91, !noundef !28
  %7 = getelementptr inbounds nuw i8, ptr %_22.1.i.i.i, i64 16, !dbg !2821
  %8 = load i64, ptr %7, align 8, !dbg !2821, !range !120, !invariant.load !28, !noalias !2822
  %9 = add nsw i64 %8, -1, !dbg !2821
  %10 = and i64 %9, -16, !dbg !2821
  %11 = getelementptr inbounds nuw i8, ptr %_22.0.i.i.i, i64 %10, !dbg !2821
  %_5.0.i.i.i = getelementptr inbounds nuw i8, ptr %11, i64 16, !dbg !2821
  %12 = getelementptr inbounds nuw i8, ptr %_22.1.i.i.i, i64 56, !dbg !2823
  %13 = load ptr, ptr %12, align 8, !dbg !2823, !invariant.load !28, !noalias !2822, !nonnull !28
  %_4.i.i.i = call noundef nonnull align 8 ptr %13(ptr noundef nonnull %_5.0.i.i.i) #24, !dbg !2824, !noalias !2822
  %_6.i.i.i = getelementptr inbounds nuw i8, ptr %ptr.i22.i, i64 24, !dbg !2825
; call <arrow_schema::datatype::DataType as core::cmp::PartialEq>::eq
  %_23.i.i.i = call fastcc noundef zeroext i1 @_RNvXs5_NtCsahM43VdRvdp_12arrow_schema8datatypeNtB5_8DataTypeNtNtCslWxY2MhVcag_4core3cmp9PartialEq2eq(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %_4.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %_6.i.i.i) #24, !dbg !2832, !noalias !2820
  br i1 %_23.i.i.i, label %bb4.i.i.i, label %bb2.i.i.i, !dbg !2823

bb4.i.i.i:                                        ; preds = %bb3.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i), !dbg !2840, !noalias !2822
  call void @llvm.lifetime.start.p0(ptr nonnull %_11.i.i.i), !dbg !2840, !noalias !2822
; call rofl_arrow::batch::materialize
  call void @_RNvNtCs7Kazvvc7DnG_10rofl_arrow5batch11materialize(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(address) dereferenceable(32) %_11.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(16) %5), !dbg !2840, !noalias !2820
  %14 = load i64, ptr %_11.i.i.i, align 8, !dbg !2841, !range !2844, !noalias !2822, !noundef !28
  %.not.i.i.i = icmp eq i64 %14, -1, !dbg !2841
  %_25.0.i.i.i = load ptr, ptr %1, align 8, !dbg !2845, !noalias !2822
  %_25.1.i.i.i = load ptr, ptr %2, align 8, !dbg !2845, !noalias !2822
  br i1 %.not.i.i.i, label %bb15.i.i.i, label %bb14.i.i.i, !dbg !2846

bb2.i.i.i:                                        ; preds = %bb3.i
; call <rofl_arrow::ArrowHost as rofl::host::Host>::error
  call void @_RNvXCs7Kazvvc7DnG_10rofl_arrowNtB2_9ArrowHostNtNtCshZi9mpuUhIi_4rofl4host4Host5error(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bfc989ecbdcd99568aec48d513c2fe63, i64 noundef 41), !dbg !2847, !noalias !2848
  br label %_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.thread.i.i, !dbg !2849

bb14.i.i.i:                                       ; preds = %bb4.i.i.i
  %_26.sroa.6.0._11.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 24, !dbg !2851
  %_26.sroa.6.0.copyload.i.i.i = load i64, ptr %_26.sroa.6.0._11.sroa_idx.i.i.i, align 8, !dbg !2851, !noalias !2822
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i.i), !dbg !2852, !noalias !2822
  store i64 %14, ptr %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, align 8, !dbg !2853, !alias.scope !2801, !noalias !2848
  %_29.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 16, !dbg !2853
  store ptr %_25.0.i.i.i, ptr %_29.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !2853, !alias.scope !2801, !noalias !2848
  %_29.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 24, !dbg !2853
  store ptr %_25.1.i.i.i, ptr %_29.sroa.5.0..sroa_idx.i.i.i, align 8, !dbg !2853, !alias.scope !2801, !noalias !2848
  %_29.sroa.6.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 32, !dbg !2853
  store i64 %_26.sroa.6.0.copyload.i.i.i, ptr %_29.sroa.6.0..sroa_idx.i.i.i, align 8, !dbg !2853, !alias.scope !2801, !noalias !2848
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i), !dbg !2861, !noalias !2822
  br label %_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.thread.i.i, !dbg !2849

bb15.i.i.i:                                       ; preds = %bb4.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i.i), !dbg !2852, !noalias !2822
  store ptr %_25.0.i.i.i, ptr %_9.i.i.i, align 8, !dbg !2840, !noalias !2822
  store ptr %_25.1.i.i.i, ptr %3, align 8, !dbg !2840, !noalias !2822
  call void @llvm.lifetime.start.p0(ptr nonnull %_15.sroa.6.i.i.i), !dbg !2862
  call void @llvm.lifetime.start.p0(ptr nonnull %_16.i.i.i), !dbg !2862, !noalias !2822
; invoke rofl_arrow::batch::logical_field
  invoke void @_RNvNtCs7Kazvvc7DnG_10rofl_arrow5batch13logical_field(ptr noalias nofree noundef nonnull sret([112 x i8]) align 8 captures(none) dereferenceable(112) %_16.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(136) %ptr.i22.i)
          to label %bb7.i.i.i unwind label %cleanup.i.i.i, !dbg !2862, !noalias !2820

cleanup.i.i.i:                                    ; preds = %bb15.i.i.i
  %15 = landingpad { ptr, i32 }
          cleanup
  %_2.i.i.i.i.i = atomicrmw sub ptr %_25.0.i.i.i, i64 1 release, align 8, !dbg !2863, !noalias !2872
  %16 = icmp eq i64 %_2.i.i.i.i.i, 1, !dbg !2877
  br i1 %16, label %bb2.i.i.i.i.i, label %common.resume.i.i, !dbg !2877

bb2.i.i.i.i.i:                                    ; preds = %cleanup.i.i.i
  fence acquire, !dbg !2878
; invoke <alloc::sync::Arc<dyn arrow_array::array::Array>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcDNtNtCs6AFQLBbsvVR_11arrow_array5array5ArrayEL_E9drop_slowBL_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %_9.i.i.i) #21
          to label %common.resume.i.i unwind label %terminate.i.i.i, !dbg !2880, !noalias !2820

bb7.i.i.i:                                        ; preds = %bb15.i.i.i
  %17 = load i64, ptr %_16.i.i.i, align 8, !dbg !2881, !range !146, !noalias !2822, !noundef !28
  %18 = icmp eq i64 %17, -1, !dbg !2881
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_15.sroa.6.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %4, i64 32, i1 false), !dbg !2884, !noalias !2822
  br i1 %18, label %bb16.i.i.i, label %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i.thread, !dbg !2885

bb16.i.i.i:                                       ; preds = %bb7.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i.i.i), !dbg !2886, !noalias !2822
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_15.sroa.6.i.i.i, i64 32, i1 false), !dbg !2886, !noalias !2848
  store i64 -1, ptr %_7.i.i, align 8, !dbg !2887, !alias.scope !2801, !noalias !2848
  %_2.i.i8.i.i.i = atomicrmw sub ptr %_25.0.i.i.i, i64 1 release, align 8, !dbg !2893, !noalias !2898
  %19 = icmp eq i64 %_2.i.i8.i.i.i, 1, !dbg !2903
  br i1 %19, label %bb2.i.i9.i.i.i, label %_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.i.i, !dbg !2903

bb2.i.i9.i.i.i:                                   ; preds = %bb16.i.i.i
  fence acquire, !dbg !2904
; call <alloc::sync::Arc<dyn arrow_array::array::Array>>::drop_slow
  call void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcDNtNtCs6AFQLBbsvVR_11arrow_array5array5ArrayEL_E9drop_slowBL_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %_9.i.i.i) #21, !dbg !2906, !noalias !2820
  br label %_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.i.i, !dbg !2906

_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i.thread: ; preds = %bb7.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(72) %_8.sroa.0.sroa.6.0._0.sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(72) %_32.sroa.5.0._16.sroa_idx.i.i.i, i64 72, i1 false), !dbg !2907, !noalias !2848
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i.i.i), !dbg !2886, !noalias !2822
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_15.sroa.6.i.i.i, i64 32, i1 false), !dbg !2862, !noalias !2848
  %20 = getelementptr inbounds nuw i8, ptr %ptr.i22.i, i64 128, !dbg !2908
  %21 = load i8, ptr %20, align 8, !dbg !2908, !range !2909, !alias.scope !2819, !noalias !2820, !noundef !28
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i), !dbg !2861, !noalias !2822
  store ptr %_25.0.i.i.i, ptr %_8.sroa.5.0._0.sroa_idx.i.i.i, align 8, !dbg !2910, !alias.scope !2801, !noalias !2848
  store ptr %_25.1.i.i.i, ptr %_8.sroa.6.0._0.sroa_idx.i.i.i, align 8, !dbg !2910, !alias.scope !2801, !noalias !2848
  store i8 %21, ptr %_8.sroa.7.0._0.sroa_idx.i.i.i, align 8, !dbg !2910, !alias.scope !2801, !noalias !2848
  call void @llvm.lifetime.end.p0(ptr nonnull %_15.sroa.6.i.i.i), !dbg !2911
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(96) %_8.sroa.4.40._8.sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(96) %_8.sroa.0.sroa.6.0._0.sroa_idx.i.i.i, i64 96, i1 false), !dbg !2912
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.4.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, i64 32, i1 false), !dbg !2918
  br label %bb8.i.sink.split, !dbg !2919

terminate.i.i.i:                                  ; preds = %bb2.i.i.i.i.i
  %22 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #22, !dbg !2922, !noalias !2820
  unreachable, !dbg !2922

common.resume.i.i:                                ; preds = %cleanup3.i.i.i, %bb2.i.i.i.i.i, %cleanup.i.i.i
  %common.resume.op.i.i = phi { ptr, i32 } [ %26, %cleanup3.i.i.i ], [ %15, %bb2.i.i.i.i.i ], [ %15, %cleanup.i.i.i ]
  resume { ptr, i32 } %common.resume.op.i.i, !dbg !2923

_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.thread.i.i: ; preds = %bb14.i.i.i, %bb2.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_5.sroa.4.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, i64 32, i1 false), !dbg !2795, !noalias !2799
  br label %bb3.i.i.i, !dbg !2924

_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.i.i: ; preds = %bb2.i.i9.i.i.i, %bb16.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i), !dbg !2861, !noalias !2822
  call void @llvm.lifetime.end.p0(ptr nonnull %_15.sroa.6.i.i.i), !dbg !2911
  %_5.sroa.0.0.copyload.pr.pre.i.i = load i64, ptr %_7.i.i, align 8, !dbg !2795, !noalias !2799
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_5.sroa.4.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, i64 32, i1 false), !dbg !2795, !noalias !2799
  %23 = icmp eq i64 %_5.sroa.0.0.copyload.pr.pre.i.i, -1, !dbg !2925
  br i1 %23, label %bb3.i.i.i, label %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i, !dbg !2924

bb3.i.i.i:                                        ; preds = %_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.i.i, %_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.thread.i.i
  %24 = load i64, ptr %g.1, align 8, !dbg !2926, !range !2844, !alias.scope !2930, !noalias !2933, !noundef !28
  %25 = icmp eq i64 %24, -1, !dbg !2926
  br i1 %25, label %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i, label %bb2.i5.i.i.i, !dbg !2926

bb2.i5.i.i.i:                                     ; preds = %bb3.i.i.i
; invoke core::ptr::drop_glue::<arrow_schema::error::ArrowError>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorECskkDzpO6M0zw_10boundaries.llvm.4229899229583720697(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %g.1)
          to label %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i unwind label %cleanup3.i.i.i, !dbg !2937, !noalias !2940

cleanup3.i.i.i:                                   ; preds = %bb2.i5.i.i.i
  %26 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %g.1, ptr noundef nonnull align 8 dereferenceable(32) %_5.sroa.4.i.i, i64 32, i1 false), !dbg !2941, !noalias !2942
  br label %common.resume.i.i, !dbg !2943

_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i: ; preds = %bb2.i5.i.i.i, %bb3.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %g.1, ptr noundef nonnull align 8 dereferenceable(32) %_5.sroa.4.i.i, i64 32, i1 false), !dbg !2941, !noalias !2942
  br label %bb8.i.sink.split, !dbg !2919

_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i: ; preds = %_RNCINvCs7Kazvvc7DnG_10rofl_arrow6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0CskkDzpO6M0zw_10boundaries.exit.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(96) %_8.sroa.4.40._8.sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(96) %_8.sroa.0.sroa.6.0._0.sroa_idx.i.i.i, i64 96, i1 false), !dbg !2912
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.4.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.0.sroa.5.0._0.sroa_idx.i.i.i, i64 32, i1 false), !dbg !2918
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i.i), !dbg !2944, !noalias !2799
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.4.i.i), !dbg !2944
  %.not.i.i = icmp eq i64 %_5.sroa.0.0.copyload.pr.pre.i.i, -2, !dbg !2945
  br i1 %.not.i.i, label %bb7.i, label %bb8.i, !dbg !2919

bb8.i.sink.split:                                 ; preds = %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i, %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i.thread
  %_9.sroa.0.07.i.ph = phi i64 [ %17, %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i.thread ], [ -1, %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i.i), !dbg !2944, !noalias !2799
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.4.i.i), !dbg !2944
  br label %bb8.i, !dbg !2946

bb8.i:                                            ; preds = %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i, %bb8.i.sink.split
  %_9.sroa.0.07.i = phi i64 [ %_9.sroa.0.07.i.ph, %bb8.i.sink.split ], [ %_5.sroa.0.0.copyload.pr.pre.i.i, %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i ]
  %residual.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !2946
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %residual.sroa.4.0._0.sroa_idx.i, ptr noundef nonnull align 8 dereferenceable(128) %_8.sroa.4.i.i.i, i64 128, i1 false), !dbg !2952, !noalias !2768
  br label %_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvB1m_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit, !dbg !2954

bb7.i:                                            ; preds = %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvB1D_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7r_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i
  %ptr.i.i = load ptr, ptr %self, align 8, !dbg !2770, !alias.scope !2777, !noalias !2764, !nonnull !28, !noundef !28
  %end_or_len.i.i = load ptr, ptr %0, align 8, !dbg !2780, !alias.scope !2777, !noalias !2764, !nonnull !28, !noundef !28
  %_6.i.i = icmp eq ptr %ptr.i.i, %end_or_len.i.i, !dbg !2782
  br i1 %_6.i.i, label %_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvB1m_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit, label %bb3.i, !dbg !2786

_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvB1m_6invokeINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit: ; preds = %bb7.i, %bb8.i, %start
  %storemerge.i = phi i64 [ %_9.sroa.0.07.i, %bb8.i ], [ -2, %start ], [ -2, %bb7.i ], !dbg !2955
  store i64 %storemerge.i, ptr %_0, align 8, !dbg !2955, !alias.scope !2764, !noalias !2768
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.4.i.i.i), !dbg !2956
  ret void, !dbg !2957
}

; boundaries-3c3a77a76c6fcdfa.boundaries.ecd45eb892372cfc-cgu.03.rcgu.ll
; <core::iter::adapters::map::Map<core::slice::iter::Iter<rofl::host::Operand<rofl_arrow::ArrowHost>>, rofl::execute::selected<rofl_arrow::ArrowHost, rofl_examples::functions::PositiveSum<true>>::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::GenericShunt<core::iter::adapters::map::Map<core::slice::iter::Iter<rofl::host::Operand<rofl_arrow::ArrowHost>>, rofl::execute::selected<rofl_arrow::ArrowHost, rofl_examples::functions::PositiveSum<true>>::{closure#0}>, core::result::Result<core::convert::Infallible, arrow_schema::error::ArrowError>> as core::iter::traits::iterator::Iterator>::try_fold<(), core::iter::traits::iterator::Iterator::try_for_each::call<rofl::host::Operand<rofl_arrow::ArrowHost>, core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>, core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>::Break>::{closure#0}, core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>>::{closure#0}, core::ops::control_flow::ControlFlow<core::ops::control_flow::ControlFlow<rofl::host::Operand<rofl_arrow::ArrowHost>>>>
define hidden void @_RINvXs0_NtNtNtCslWxY2MhVcag_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENCINvNtB1s_7execute8selectedB1Y_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEEB4b_8try_folduNCINvNvB4b_12try_for_each4callB1n_INtNtNtBc_3ops12control_flow11ControlFlowB1n_ENcNtB7O_5Break0E0B7O_E0IB7P_B7O_EECskkDzpO6M0zw_10boundaries(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([136 x i8]) align 8 captures(none) dereferenceable(136) %_0, ptr noalias nofree noundef align 8 captures(none) dereferenceable(32) %self, ptr noalias nofree noundef nonnull readnone captures(none) %g.0, ptr noalias nofree noundef align 8 captures(none) dereferenceable(32) %g.1) unnamed_addr #0 personality ptr @rust_eh_personality !dbg !3124 {
start:
  %_8.sroa.4.i.i.i = alloca [128 x i8], align 8
  %_7.i.i = alloca [136 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !3125), !dbg !3128
  tail call void @llvm.experimental.noalias.scope.decl(metadata !3129), !dbg !3128
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.4.i.i.i)
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %end_or_len.i.i = load ptr, ptr %0, align 8, !alias.scope !3131, !noalias !3125, !nonnull !28, !noundef !28
  %self.promoted.i = load ptr, ptr %self, align 8, !alias.scope !3131, !noalias !3125
  %_6.i14.i = icmp eq ptr %self.promoted.i, %end_or_len.i.i, !dbg !3134
  br i1 %_6.i14.i, label %_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvNtBO_7execute8selectedB1k_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit, label %bb3.lr.ph.i, !dbg !3141

bb3.lr.ph.i:                                      ; preds = %start
  %f = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !3142
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_5.sroa.4.0._7.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 8
  %_5.sroa.7.0._7.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_7.i.i, i64 40
  %_8.sroa.4.40._8.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_8.sroa.4.i.i.i, i64 32
  %_9.val.i.i = load ptr, ptr %f, align 8, !noalias !3143, !nonnull !28, !align !91, !noundef !28
  %_9.val1.i.i = load ptr, ptr %1, align 8, !noalias !3143, !nonnull !28, !noundef !28
  br label %bb3.i, !dbg !3141

bb3.i:                                            ; preds = %bb7.i, %bb3.lr.ph.i
  %ptr.i1315.i = phi ptr [ %self.promoted.i, %bb3.lr.ph.i ], [ %_16.i.i, %bb7.i ]
  %_16.i.i = getelementptr inbounds nuw i8, ptr %ptr.i1315.i, i64 136, !dbg !3147
  store ptr %_16.i.i, ptr %self, align 8, !dbg !3149, !alias.scope !3131, !noalias !3125
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i.i), !dbg !3150, !noalias !3143
; call <rofl_arrow::ArrowHost as rofl::host::BatchBinding>::filter
  call void @_RNvXs0_NtCs7Kazvvc7DnG_10rofl_arrow5batchNtB7_9ArrowHostNtNtCshZi9mpuUhIi_4rofl4host12BatchBinding6filter(ptr noalias nofree noundef nonnull sret([136 x i8]) align 8 captures(none) dereferenceable(136) %_7.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(136) %ptr.i1315.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(56) %_9.val.i.i, ptr noalias nofree noundef nonnull %_9.val1.i.i), !dbg !3153, !noalias !3157
  %_5.sroa.0.0.copyload.i.i = load i64, ptr %_7.i.i, align 8, !dbg !3158, !noalias !3143
  %2 = icmp eq i64 %_5.sroa.0.0.copyload.i.i, -1, !dbg !3159
  br i1 %2, label %bb3.i.i.i, label %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i, !dbg !3163

bb3.i.i.i:                                        ; preds = %bb3.i
  %3 = load i64, ptr %g.1, align 8, !dbg !3164, !range !2844, !alias.scope !3167, !noalias !3170, !noundef !28
  %4 = icmp eq i64 %3, -1, !dbg !3164
  br i1 %4, label %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i, label %bb2.i5.i.i.i, !dbg !3164

bb2.i5.i.i.i:                                     ; preds = %bb3.i.i.i
; invoke core::ptr::drop_glue::<arrow_schema::error::ArrowError>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorECskkDzpO6M0zw_10boundaries.llvm.4229899229583720697(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %g.1)
          to label %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i unwind label %cleanup3.i.i.i, !dbg !3174, !noalias !3176

cleanup3.i.i.i:                                   ; preds = %bb2.i5.i.i.i
  %5 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %g.1, ptr noundef nonnull align 8 dereferenceable(32) %_5.sroa.4.0._7.sroa_idx.i.i, i64 32, i1 false), !dbg !3177, !noalias !3143
  resume { ptr, i32 } %5, !dbg !3178

_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i: ; preds = %bb2.i5.i.i.i, %bb3.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %g.1, ptr noundef nonnull align 8 dereferenceable(32) %_5.sroa.4.0._7.sroa_idx.i.i, i64 32, i1 false), !dbg !3177, !noalias !3143
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i.i), !dbg !3179, !noalias !3143
  br label %bb8.i, !dbg !3180

_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i: ; preds = %bb3.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(96) %_8.sroa.4.40._8.sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(96) %_5.sroa.7.0._7.sroa_idx.i.i, i64 96, i1 false), !dbg !3182, !noalias !3183
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_8.sroa.4.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_5.sroa.4.0._7.sroa_idx.i.i, i64 32, i1 false), !dbg !3184, !noalias !3183
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i.i), !dbg !3179, !noalias !3143
  %.not.i.i = icmp eq i64 %_5.sroa.0.0.copyload.i.i, -2, !dbg !3185
  br i1 %.not.i.i, label %bb7.i, label %bb8.i, !dbg !3180

bb8.i:                                            ; preds = %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i, %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.thread.i
  %residual.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3186
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %residual.sroa.4.0._0.sroa_idx.i, ptr noundef nonnull align 8 dereferenceable(128) %_8.sroa.4.i.i.i, i64 128, i1 false), !dbg !3190, !noalias !3129
  br label %_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvNtBO_7execute8selectedB1k_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit, !dbg !3191

bb7.i:                                            ; preds = %_RNCINvNtNtNtCslWxY2MhVcag_4core4iter8adapters3map12map_try_foldRINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEINtNtBa_6result6ResultB10_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB3v_B10_EENCINvNtB15_7execute8selectedB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB6_INtB6_12GenericShuntINtB4_3MapINtNtNtBa_5slice4iter4IterB10_EB4k_EIB2f_NtNtBa_7convert10InfallibleB2E_EENtNtNtB8_6traits8iterator8Iterator8try_folduNCINvNvB7H_12try_for_each4callB10_B49_NcNtB49_5Break0E0B49_E0E0CskkDzpO6M0zw_10boundaries.exit.i
  %_6.i.i = icmp eq ptr %_16.i.i, %end_or_len.i.i, !dbg !3134
  br i1 %_6.i.i, label %_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvNtBO_7execute8selectedB1k_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit, label %bb3.i, !dbg !3141

_RINvYINtNtNtCslWxY2MhVcag_4core5slice4iter4IterINtNtCshZi9mpuUhIi_4rofl4host7OperandNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostEENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtB24_8adapters3map12map_try_foldRBJ_INtNtBa_6result6ResultBJ_NtNtCsahM43VdRvdp_12arrow_schema5error10ArrowErrorEuINtNtNtBa_3ops12control_flow11ControlFlowIB4L_BJ_EENCINvNtBO_7execute8selectedB1k_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE0NCINvXB2U_INtB2U_12GenericShuntINtB2S_3MapB3_B5z_EIB3w_NtNtBa_7convert10InfallibleB3U_EEB1Y_8try_folduNCINvNvB1Y_12try_for_each4callBJ_B5p_NcNtB5p_5Break0E0B5p_E0E0B4K_ECskkDzpO6M0zw_10boundaries.exit: ; preds = %bb7.i, %bb8.i, %start
  %storemerge.i = phi i64 [ %_5.sroa.0.0.copyload.i.i, %bb8.i ], [ -2, %start ], [ -2, %bb7.i ], !dbg !3192
  store i64 %storemerge.i, ptr %_0, align 8, !dbg !3192, !alias.scope !3125, !noalias !3129
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.4.i.i.i), !dbg !3193
  ret void, !dbg !3194
}