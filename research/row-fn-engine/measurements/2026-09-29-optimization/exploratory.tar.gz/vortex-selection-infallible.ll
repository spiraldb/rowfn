; target/release/deps/boundaries-3c3a77a76c6fcdfa.boundaries.ecd45eb892372cfc-cgu.07.rcgu.ll
define hidden void @_RINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB5_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1z_7execute13selected_rowsNtB7_10VortexHostB2l_NCINvMNtB37_5ownedINtB37_7ExecuteB3A_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4d_INtNtB1z_7visitor10RowVisitorB3A_E19visit_deferred_boolB5G_bKB5s_NCINvXs1_B4z_B4w_INtB60_5RowFnB3A_E8dispatchB4d_Es4_0NCB72_s5_0E0NCB5P_s_0B7R_Es_0Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(16) %self, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(48) %0, ptr noalias nofree noundef align 8 captures(none) dereferenceable(8) %1) unnamed_addr #0 personality ptr @rust_eh_personality !dbg !9434 {
start:
  %_6.i = alloca [40 x i8], align 8
  %_3 = load i64, ptr %self, align 8, !dbg !9435, !range !4419, !noundef !24
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 8, !dbg !9435
  switch i64 %_3, label %default.unreachable77 [
    i64 0, label %bb4
    i64 1, label %bb6
    i64 2, label %bb2
  ], !dbg !9436

default.unreachable77:                            ; preds = %start
  unreachable

bb4:                                              ; preds = %start
  %_7 = load i64, ptr %2, align 8, !dbg !9437, !noundef !24
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9439), !dbg !9442
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9445), !dbg !9442
  %_0.i.i.i7.i.not = icmp eq i64 %_7, 0, !dbg !9447
  br i1 %_0.i.i.i7.i.not, label %bb6, label %bb3.lr.ph.i, !dbg !9455

bb3.lr.ph.i:                                      ; preds = %bb4
  %.promoted.i = load i64, ptr %1, align 8, !alias.scope !9445, !noalias !9456
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %_16.i.i.i.i = load ptr, ptr %3, align 8, !alias.scope !9458, !noalias !9461, !nonnull !24, !align !1357, !noundef !24
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %_17.1.i.i.i.i = load i64, ptr %4, align 8, !alias.scope !9439, !noalias !9461
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %_18.0.i.i.i.i = load ptr, ptr %5, align 8, !alias.scope !9439, !noalias !9461, !nonnull !24
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %_19.i.i.i.i = load ptr, ptr %6, align 8, !alias.scope !9439, !noalias !9461, !nonnull !24
  %view.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 8
  %_6.i5 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 24
  %view.i2.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 32
  %7 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 16
  %8 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 40
  br label %bb3.i, !dbg !9455

bb3.i:                                            ; preds = %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4t_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5W_bKB5I_NCINvXs1_B4P_B4M_INtB6g_5RowFnB2X_E8dispatchB4t_Es4_0NCB7i_s5_0E0NCB65_s_0B87_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, %bb3.lr.ph.i
  %_0.i1.i.i68.i = phi i64 [ 0, %bb3.lr.ph.i ], [ %_0.i1.i.i.i, %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4t_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5W_bKB5I_NCINvXs1_B4P_B4M_INtB6g_5RowFnB2X_E8dispatchB4t_Es4_0NCB7i_s5_0E0NCB65_s_0B87_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i ]
  %9 = phi i64 [ %.promoted.i, %bb3.lr.ph.i ], [ %17, %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4t_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5W_bKB5I_NCINvXs1_B4P_B4M_INtB6g_5RowFnB2X_E8dispatchB4t_Es4_0NCB7i_s5_0E0NCB65_s_0B87_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9462), !dbg !9463
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9468), !dbg !9471
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9473), !dbg !9476, !noalias !9478
  %10 = load ptr, ptr %_16.i.i.i.i, align 8, !dbg !9479, !alias.scope !9481, !noalias !9478, !noundef !24
  %.not.i.i2 = icmp eq ptr %10, null, !dbg !9479
  br i1 %.not.i.i2, label %bb3.i.i, label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, !dbg !9482

bb3.i.i:                                          ; preds = %bb3.i
  %view.val.i.i = load ptr, ptr %view.i.i, align 8, !dbg !9483, !alias.scope !9481, !noalias !9478, !nonnull !24, !align !1357, !noundef !24
  %view.val2.i.i = load i64, ptr %7, align 8, !dbg !9483, !alias.scope !9481, !noalias !9478, !noundef !24
  %_5.i3.i.i = icmp ult i64 %9, %view.val2.i.i, !dbg !9484
  tail call void @llvm.assume(i1 %_5.i3.i.i), !dbg !9488, !noalias !9478
  %_4.i.i.i = getelementptr inbounds nuw i64, ptr %view.val.i.i, i64 %9, !dbg !9489
  br label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, !dbg !9490

_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i: ; preds = %bb3.i, %bb3.i.i
  %_0.sroa.0.0.in.i.i = phi ptr [ %_4.i.i.i, %bb3.i.i ], [ %10, %bb3.i ]
  %_0.sroa.0.0.i.i4 = load i64, ptr %_0.sroa.0.0.in.i.i, align 8, !dbg !9491, !noalias !9493, !noundef !24
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9494), !dbg !9476, !noalias !9478
  %11 = load ptr, ptr %_6.i5, align 8, !dbg !9497, !alias.scope !9499, !noalias !9478, !noundef !24
  %.not.i1.i = icmp eq ptr %11, null, !dbg !9497
  br i1 %.not.i1.i, label %bb3.i8.i, label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit, !dbg !9500

bb3.i8.i:                                         ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i
  %view.val.i9.i = load ptr, ptr %view.i2.i, align 8, !dbg !9501, !alias.scope !9499, !noalias !9478, !nonnull !24, !align !1357, !noundef !24
  %view.val2.i10.i = load i64, ptr %8, align 8, !dbg !9501, !alias.scope !9499, !noalias !9478, !noundef !24
  %_5.i3.i11.i = icmp ult i64 %9, %view.val2.i10.i, !dbg !9502
  tail call void @llvm.assume(i1 %_5.i3.i11.i), !dbg !9506, !noalias !9478
  %_4.i.i12.i = getelementptr inbounds nuw i64, ptr %view.val.i9.i, i64 %9, !dbg !9507
  br label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit, !dbg !9508

_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit: ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, %bb3.i8.i
  %_0.sroa.0.0.in.i6.i = phi ptr [ %_4.i.i12.i, %bb3.i8.i ], [ %11, %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i ]
  %exitcond.not.i = icmp eq i64 %_0.i1.i.i68.i, %_17.1.i.i.i.i, !dbg !9509
  br i1 %exitcond.not.i, label %panic.i.i.i.i, label %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4t_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5W_bKB5I_NCINvXs1_B4P_B4M_INtB6g_5RowFnB2X_E8dispatchB4t_Es4_0NCB7i_s5_0E0NCB65_s_0B87_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, !dbg !9509

panic.i.i.i.i:                                    ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_17.1.i.i.i.i, i64 noundef %_17.1.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d179419b0efea413e3bae0e1e9c82584) #19, !dbg !9509, !noalias !9478
  unreachable

_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4t_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5W_bKB5I_NCINvXs1_B4P_B4M_INtB6g_5RowFnB2X_E8dispatchB4t_Es4_0NCB7i_s5_0E0NCB65_s_0B87_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i: ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit
  %_0.sroa.0.0.i7.i = load i64, ptr %_0.sroa.0.0.in.i6.i, align 8, !dbg !9510, !noalias !9512, !noundef !24
  %_0.i1.i.i.i = add nuw i64 %_0.i1.i.i68.i, 1, !dbg !9513
  %12 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i4, i64 %_0.sroa.0.0.i7.i), !dbg !9516
  %_7.0.i.i.i.i.i.i = extractvalue { i64, i1 } %12, 0, !dbg !9516
  %_8.i.i.i.i.i.i = icmp sgt i64 %_7.0.i.i.i.i.i.i, 0, !dbg !9520
  %_7.1.i.i.i.i.i.i = extractvalue { i64, i1 } %12, 1, !dbg !9516
  %_9.i.i.i.i = getelementptr inbounds nuw i8, ptr %_18.0.i.i.i.i, i64 %_0.i1.i.i68.i, !dbg !9509
  %_21.i.i.i.i = zext i1 %_8.i.i.i.i.i.i to i8, !dbg !9521
  store i8 %_21.i.i.i.i, ptr %_9.i.i.i.i, align 1, !dbg !9524, !noalias !9478
  %13 = load i8, ptr %_19.i.i.i.i, align 1, !dbg !9525, !range !4560, !alias.scope !9527, !noalias !9478, !noundef !24
  %14 = trunc nuw i8 %13 to i1, !dbg !9525
  %15 = or i1 %_7.1.i.i.i.i.i.i, %14, !dbg !9525
  %16 = zext i1 %15 to i8, !dbg !9525
  store i8 %16, ptr %_19.i.i.i.i, align 1, !dbg !9525, !alias.scope !9527, !noalias !9478
  %17 = add i64 %9, 1, !dbg !9530
  store i64 %17, ptr %1, align 8, !dbg !9530, !alias.scope !9445, !noalias !9456
  %exitcond10.not.i = icmp eq i64 %_0.i1.i.i.i, %_7, !dbg !9447
  br i1 %exitcond10.not.i, label %bb6, label %bb3.i, !dbg !9455

bb2:                                              ; preds = %start
  %_15 = load ptr, ptr %2, align 8, !dbg !9532, !nonnull !24, !noundef !24
  %_10 = getelementptr inbounds nuw i8, ptr %_15, i64 16, !dbg !9540
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9543), !dbg !9546
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.i), !dbg !9547, !noalias !9551
  %_37.i = load ptr, ptr %_10, align 8, !dbg !9553, !alias.scope !9543, !noalias !9558, !nonnull !24, !noundef !24
  %18 = getelementptr inbounds nuw i8, ptr %_15, i64 24, !dbg !9559
  %_38.i = load i64, ptr %18, align 8, !dbg !9559, !alias.scope !9543, !noalias !9558, !noundef !24
  %19 = getelementptr inbounds nuw i8, ptr %_15, i64 48, !dbg !9560
  %_34.i = load i64, ptr %19, align 8, !dbg !9560, !alias.scope !9543, !noalias !9558, !noundef !24
  %20 = getelementptr inbounds nuw i8, ptr %_15, i64 56, !dbg !9561
  %_35.i = load i64, ptr %20, align 8, !dbg !9561, !alias.scope !9543, !noalias !9558, !noundef !24
; call <arrow_buffer::util::bit_chunk_iterator::BitChunks>::new
  call void @_RNvMs_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB4_9BitChunks3new(ptr noalias nofree noundef nonnull sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_6.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_37.i, i64 noundef %_38.i, i64 noundef %_34.i, i64 noundef %_35.i), !dbg !9562, !noalias !9551
  %_43.0.i = load ptr, ptr %_6.i, align 8, !dbg !9563, !noalias !9551, !nonnull !24, !noundef !24
  %21 = getelementptr inbounds nuw i8, ptr %_6.i, i64 16, !dbg !9568
  %_44.i = load i64, ptr %21, align 8, !dbg !9568, !noalias !9551, !noundef !24
  %22 = getelementptr inbounds nuw i8, ptr %_6.i, i64 24, !dbg !9569
  %_45.i = load i64, ptr %22, align 8, !dbg !9569, !noalias !9551, !noundef !24
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9570), !dbg !9573
  %23 = getelementptr inbounds nuw i8, ptr %_6.i, i64 32, !dbg !9574
  %bit_len.i.i = load i64, ptr %23, align 8, !dbg !9574, !alias.scope !9570, !noalias !9551, !noundef !24
  %24 = icmp eq i64 %bit_len.i.i, 0, !dbg !9576
  br i1 %24, label %start._RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit_crit_edge.i, label %bb2.i.i, !dbg !9576

start._RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit_crit_edge.i: ; preds = %bb2
  %.pre.i = and i64 %_44.i, 63
  br label %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i, !dbg !9576

bb2.i.i:                                          ; preds = %bb2
  %_5.i.i = add i64 %bit_len.i.i, %_44.i, !dbg !9577
  %_243.i.i = lshr i64 %_5.i.i, 3, !dbg !9578
  %_25.i.i = and i64 %_5.i.i, 7, !dbg !9581
  %_26.not.i.i = icmp ne i64 %_25.i.i, 0, !dbg !9582
  %25 = zext i1 %_26.not.i.i to i64, !dbg !9582
  %byte_len.sroa.0.0.i.i = add nuw nsw i64 %_243.i.i, %25, !dbg !9582
  %_8.i.i = shl i64 %_45.i, 3, !dbg !9583
  %base.i.i = getelementptr inbounds nuw i8, ptr %_43.0.i, i64 %_8.i.i, !dbg !9584
  %_12.i.i = load i8, ptr %base.i.i, align 1, !dbg !9586, !noalias !9588, !noundef !24
  %_11.i.i = zext i8 %_12.i.i to i64, !dbg !9589
  %26 = and i64 %_44.i, 63, !dbg !9589
  %27 = lshr i64 %_11.i.i, %26, !dbg !9589
  %_284.i.i = icmp samesign ugt i64 %byte_len.sroa.0.0.i.i, 1, !dbg !9590
  br i1 %_284.i.i, label %iter.check, label %bb9.i.i, !dbg !9594

iter.check:                                       ; preds = %bb2.i.i
  %28 = add nuw nsw i64 %_243.i.i, %25, !dbg !9594
  %29 = add nsw i64 %28, -1, !dbg !9594
  %min.iters.check = icmp ult i64 %29, 4, !dbg !9594
  br i1 %min.iters.check, label %bb8.i.i.preheader, label %vector.main.loop.iter.check, !dbg !9594

vector.main.loop.iter.check:                      ; preds = %iter.check
  %min.iters.check88 = icmp ult i64 %29, 16, !dbg !9594
  br i1 %min.iters.check88, label %vec.epilog.ph, label %vector.ph, !dbg !9594

vector.ph:                                        ; preds = %vector.main.loop.iter.check
  %n.mod.vf = and i64 %29, 12
  %n.vec = and i64 %29, -16
  %30 = or disjoint i64 %n.vec, 1
  %31 = insertelement <16 x i64> <i64 poison, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0>, i64 %27, i64 0
  %broadcast.splatinsert = insertelement <16 x i64> poison, i64 %_44.i, i64 0
  %broadcast.splat = shufflevector <16 x i64> %broadcast.splatinsert, <16 x i64> poison, <16 x i32> zeroinitializer
  br label %vector.body, !dbg !9594

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <16 x i64> [ %31, %vector.ph ], [ %39, %vector.body ]
  %vec.ind = phi <16 x i64> [ <i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7, i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15, i64 16>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %32 = getelementptr inbounds nuw i8, ptr %base.i.i, i64 %index, !dbg !9595
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 1, !dbg !9595
  %wide.load = load <16 x i8>, ptr %33, align 1, !dbg !9597, !noalias !9588
  %34 = zext <16 x i8> %wide.load to <16 x i64>, !dbg !9599
  %35 = shl nuw <16 x i64> %vec.ind, splat (i64 3), !dbg !9600
  %36 = sub <16 x i64> %35, %broadcast.splat, !dbg !9601
  %37 = and <16 x i64> %36, splat (i64 63), !dbg !9599
  %38 = shl <16 x i64> %34, %37, !dbg !9599
  %39 = or <16 x i64> %38, %vec.phi, !dbg !9602
  %index.next = add nuw i64 %index, 16
  %vec.ind.next = add nuw nsw <16 x i64> %vec.ind, splat (i64 16)
  %40 = icmp eq i64 %index.next, %n.vec, !dbg !9594
  br i1 %40, label %middle.block, label %vector.body, !dbg !9594, !llvm.loop !9603

middle.block:                                     ; preds = %vector.body
  %41 = tail call i64 @llvm.vector.reduce.or.v16i64(<16 x i64> %39), !dbg !9594
  %cmp.n = icmp eq i64 %29, %n.vec, !dbg !9594
  br i1 %cmp.n, label %bb9.i.i, label %vec.epilog.iter.check, !dbg !9594

vec.epilog.iter.check:                            ; preds = %middle.block
  %ind.end = or disjoint i64 %n.vec, 1
  %min.epilog.iters.check = icmp eq i64 %n.mod.vf, 0
  br i1 %min.epilog.iters.check, label %bb8.i.i.preheader, label %vec.epilog.ph, !prof !538

vec.epilog.ph:                                    ; preds = %vector.main.loop.iter.check, %vec.epilog.iter.check
  %vec.epilog.resume.val = phi i64 [ %n.vec, %vec.epilog.iter.check ], [ 0, %vector.main.loop.iter.check ]
  %bc.merge.rdx = phi i64 [ %41, %vec.epilog.iter.check ], [ %27, %vector.main.loop.iter.check ]
  %bc.resume.val = phi i64 [ %30, %vec.epilog.iter.check ], [ 1, %vector.main.loop.iter.check ]
  %n.vec90 = and i64 %29, -4
  %42 = or disjoint i64 %n.vec90, 1
  %43 = insertelement <4 x i64> <i64 poison, i64 0, i64 0, i64 0>, i64 %bc.merge.rdx, i64 0
  %broadcast.splatinsert91 = insertelement <4 x i64> poison, i64 %_44.i, i64 0
  %broadcast.splat92 = shufflevector <4 x i64> %broadcast.splatinsert91, <4 x i64> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert93 = insertelement <4 x i64> poison, i64 %bc.resume.val, i64 0
  %broadcast.splat94 = shufflevector <4 x i64> %broadcast.splatinsert93, <4 x i64> poison, <4 x i32> zeroinitializer
  %induction = add nuw nsw <4 x i64> %broadcast.splat94, <i64 0, i64 1, i64 2, i64 3>
  br label %vec.epilog.vector.body

vec.epilog.vector.body:                           ; preds = %vec.epilog.vector.body, %vec.epilog.ph
  %index95 = phi i64 [ %vec.epilog.resume.val, %vec.epilog.ph ], [ %index.next99, %vec.epilog.vector.body ]
  %vec.phi96 = phi <4 x i64> [ %43, %vec.epilog.ph ], [ %51, %vec.epilog.vector.body ]
  %vec.ind97 = phi <4 x i64> [ %induction, %vec.epilog.ph ], [ %vec.ind.next100, %vec.epilog.vector.body ]
  %44 = getelementptr inbounds nuw i8, ptr %base.i.i, i64 %index95, !dbg !9595
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 1, !dbg !9595
  %wide.load98 = load <4 x i8>, ptr %45, align 1, !dbg !9597, !noalias !9588
  %46 = zext <4 x i8> %wide.load98 to <4 x i64>, !dbg !9599
  %47 = shl nuw <4 x i64> %vec.ind97, splat (i64 3), !dbg !9600
  %48 = sub <4 x i64> %47, %broadcast.splat92, !dbg !9601
  %49 = and <4 x i64> %48, splat (i64 63), !dbg !9599
  %50 = shl <4 x i64> %46, %49, !dbg !9599
  %51 = or <4 x i64> %50, %vec.phi96, !dbg !9602
  %index.next99 = add nuw i64 %index95, 4
  %vec.ind.next100 = add nuw nsw <4 x i64> %vec.ind97, splat (i64 4)
  %52 = icmp eq i64 %index.next99, %n.vec90, !dbg !9594
  br i1 %52, label %vec.epilog.middle.block, label %vec.epilog.vector.body, !dbg !9594, !llvm.loop !9604

vec.epilog.middle.block:                          ; preds = %vec.epilog.vector.body
  %53 = tail call i64 @llvm.vector.reduce.or.v4i64(<4 x i64> %51), !dbg !9594
  %cmp.n101 = icmp eq i64 %29, %n.vec90, !dbg !9594
  br i1 %cmp.n101, label %bb9.i.i, label %bb8.i.i.preheader, !dbg !9594

bb8.i.i.preheader:                                ; preds = %iter.check, %vec.epilog.iter.check, %vec.epilog.middle.block
  %bits.sroa.0.06.i.i.ph = phi i64 [ %27, %iter.check ], [ %41, %vec.epilog.iter.check ], [ %53, %vec.epilog.middle.block ]
  %iter.sroa.0.05.i.i.ph = phi i64 [ 1, %iter.check ], [ %ind.end, %vec.epilog.iter.check ], [ %42, %vec.epilog.middle.block ]
  br label %bb8.i.i, !dbg !9594

bb9.i.i:                                          ; preds = %bb8.i.i, %middle.block, %vec.epilog.middle.block, %bb2.i.i
  %bits.sroa.0.0.lcssa.i.i = phi i64 [ %27, %bb2.i.i ], [ %53, %vec.epilog.middle.block ], [ %41, %middle.block ], [ %58, %bb8.i.i ], !dbg !9605
  %54 = and i64 %bit_len.i.i, 63, !dbg !9606
  %notmask.i.i = shl nsw i64 -1, %54, !dbg !9607
  %_21.i.i = xor i64 %notmask.i.i, -1, !dbg !9607
  %55 = and i64 %bits.sroa.0.0.lcssa.i.i, %_21.i.i, !dbg !9608
  br label %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i, !dbg !9609

bb8.i.i:                                          ; preds = %bb8.i.i.preheader, %bb8.i.i
  %bits.sroa.0.06.i.i = phi i64 [ %58, %bb8.i.i ], [ %bits.sroa.0.06.i.i.ph, %bb8.i.i.preheader ]
  %iter.sroa.0.05.i.i = phi i64 [ %56, %bb8.i.i ], [ %iter.sroa.0.05.i.i.ph, %bb8.i.i.preheader ]
  %56 = add nuw nsw i64 %iter.sroa.0.05.i.i, 1, !dbg !9610
  %_16.i.i = getelementptr inbounds nuw i8, ptr %base.i.i, i64 %iter.sroa.0.05.i.i, !dbg !9595
  %byte.i.i = load i8, ptr %_16.i.i, align 1, !dbg !9597, !noalias !9588, !noundef !24
  %_18.i.i = zext i8 %byte.i.i to i64, !dbg !9599
  %_20.i.i = shl nuw i64 %iter.sroa.0.05.i.i, 3, !dbg !9600
  %_19.i.i = sub i64 %_20.i.i, %_44.i, !dbg !9601
  %57 = and i64 %_19.i.i, 63, !dbg !9599
  %_17.i.i = shl i64 %_18.i.i, %57, !dbg !9599
  %58 = or i64 %_17.i.i, %bits.sroa.0.06.i.i, !dbg !9602
  %exitcond.not.i.i = icmp eq i64 %56, %byte_len.sroa.0.0.i.i, !dbg !9590
  br i1 %exitcond.not.i.i, label %bb9.i.i, label %bb8.i.i, !dbg !9594, !llvm.loop !9613

_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i: ; preds = %bb9.i.i, %start._RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit_crit_edge.i
  %.pre-phi.i = phi i64 [ %.pre.i, %start._RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit_crit_edge.i ], [ %26, %bb9.i.i ]
  %_0.sroa.0.0.i.i = phi i64 [ 0, %start._RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit_crit_edge.i ], [ %55, %bb9.i.i ], !dbg !9614
  %59 = icmp eq i64 %_44.i, 0
  %_15.i.i.i.i = sub i64 0, %_44.i
  %60 = and i64 %_15.i.i.i.i, 63
  %61 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %62 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %63 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %64 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %.promoted22 = load i64, ptr %1, align 8
  %_16.i.i.i.i3 = load ptr, ptr %61, align 8, !nonnull !24, !align !1357
  %_17.1.i.i.i.i4 = load i64, ptr %62, align 8
  %_18.0.i.i.i.i11 = load ptr, ptr %63, align 8, !nonnull !24
  %_19.i.i.i.i14 = load ptr, ptr %64, align 8, !nonnull !24
  %view.i.i7 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i3, i64 8
  %_6.i14 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i3, i64 24
  %view.i2.i16 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i3, i64 32
  %65 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i3, i64 16
  %66 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i3, i64 40
  br label %bb1.i, !dbg !9615

bb1.i:                                            ; preds = %bb13.i, %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i
  %.promoted2124 = phi i64 [ %.promoted22, %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i ], [ %.promoted2123, %bb13.i ]
  %iter.sroa.0.0.i = phi i1 [ true, %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i ], [ %iter.sroa.0.151.i, %bb13.i ], !dbg !9547
  %iter.sroa.7.0.i = phi ptr [ %_43.0.i, %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i ], [ %iter.sroa.7.13950.i, %bb13.i ], !dbg !9547
  %iter.sroa.12.0.i = phi i64 [ 0, %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i ], [ %iter.sroa.12.14149.i, %bb13.i ], !dbg !9547
  %base.sroa.0.0.i = phi i64 [ 0, %_RNvMs0_NtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iteratorNtB5_9BitChunks14remainder_bits.exit.i ], [ %79, %bb13.i ], !dbg !9617
  %.not.i.i = icmp ne ptr %iter.sroa.7.0.i, null, !dbg !9618
  %_3.not.i.i.i.i = icmp ult i64 %iter.sroa.12.0.i, %_45.i
  %or.cond.i = select i1 %.not.i.i, i1 %_3.not.i.i.i.i, i1 false, !dbg !9624
  br i1 %or.cond.i, label %bb2.i.i.i.i, label %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i, !dbg !9624

bb2.i.i.i.i:                                      ; preds = %bb1.i
  %_7.i.i.i.i = getelementptr inbounds nuw i64, ptr %iter.sroa.7.0.i, i64 %iter.sroa.12.0.i, !dbg !9625
  %_19.sroa.0.0.copyload.i.i.i.i = load i64, ptr %_7.i.i.i.i, align 1, !dbg !9629, !noalias !9632
  br i1 %59, label %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i, label %bb4.i.i.i.i, !dbg !9639

bb4.i.i.i.i:                                      ; preds = %bb2.i.i.i.i
  %_11.i.i.i.i = getelementptr i8, ptr %_7.i.i.i.i, i64 8, !dbg !9640
  %_21.sroa.0.0.copyload.i.i.i.i = load i8, ptr %_11.i.i.i.i, align 1, !dbg !9642, !noalias !9632
  %next.i.i.i.i = zext i8 %_21.sroa.0.0.copyload.i.i.i.i to i64, !dbg !9645
  %_13.i.i.i.i = lshr i64 %_19.sroa.0.0.copyload.i.i.i.i, %.pre-phi.i, !dbg !9646
  %_14.i.i.i.i = shl i64 %next.i.i.i.i, %60, !dbg !9647
  %67 = or i64 %_14.i.i.i.i, %_13.i.i.i.i, !dbg !9646
  br label %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i, !dbg !9648

_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i: ; preds = %bb4.i.i.i.i, %bb2.i.i.i.i
  %current.sroa.0.0.i.i.i.i = phi i64 [ %_19.sroa.0.0.copyload.i.i.i.i, %bb2.i.i.i.i ], [ %67, %bb4.i.i.i.i ], !dbg !9649
  %68 = add nuw i64 %iter.sroa.12.0.i, 1, !dbg !9650
  br label %bb3.i1, !dbg !9651

_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i: ; preds = %bb1.i
  br i1 %iter.sroa.0.0.i, label %bb3.i1, label %_RINvMs0_NtNtCs7x6tOKv5niH_13vortex_buffer3bit3bufNtB6_9BitBuffer22try_for_each_set_indexNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB2d_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachB1o_NCINvNtB3I_7execute13selected_rowsNtB2f_10VortexHostB1o_NCINvMNtB4D_5ownedINtB4D_7ExecuteB56_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB5K_INtNtB3I_7visitor10RowVisitorB56_E19visit_deferred_boolB7d_bKB6Z_NCINvXs1_B66_B63_INtB7x_5RowFnB56_E8dispatchB5K_Es4_0NCB8z_s5_0E0NCB7m_s_0B9o_Es_0Es_0E0ECskkDzpO6M0zw_10boundaries.exit, !dbg !9651

bb3.i1:                                           ; preds = %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i
  %self.1.pn.i52.i = phi i64 [ %current.sroa.0.0.i.i.i.i, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i ], [ %_0.sroa.0.0.i.i, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i ]
  %iter.sroa.0.151.i = phi i1 [ %iter.sroa.0.0.i, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i ], [ false, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i ]
  %iter.sroa.7.13950.i = phi ptr [ %iter.sroa.7.0.i, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i ], [ null, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i ]
  %iter.sroa.12.14149.i = phi i64 [ %68, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.thread.i ], [ %iter.sroa.12.0.i, %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i ]
  switch i64 %self.1.pn.i52.i, label %bb10.i [
    i64 -1, label %bb23.i
    i64 0, label %bb13.i
  ], !dbg !9652

bb23.i:                                           ; preds = %bb3.i1, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i
  %69 = phi i64 [ %77, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i ], [ %.promoted2124, %bb3.i1 ]
  %iter2.sroa.0.055.i = phi i64 [ %78, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i ], [ 0, %bb3.i1 ]
  %_17.i = or disjoint i64 %iter2.sroa.0.055.i, %base.sroa.0.0.i, !dbg !9654
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9657), !dbg !9660
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9665), !dbg !9668, !noalias !9670
  %70 = load ptr, ptr %_16.i.i.i.i3, align 8, !dbg !9673, !alias.scope !9675, !noalias !9670, !noundef !24
  %.not.i.i6 = icmp eq ptr %70, null, !dbg !9673
  br i1 %.not.i.i6, label %bb3.i.i27, label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i11, !dbg !9676

bb3.i.i27:                                        ; preds = %bb23.i
  %view.val.i.i28 = load ptr, ptr %view.i.i7, align 8, !dbg !9677, !alias.scope !9675, !noalias !9670, !nonnull !24, !align !1357, !noundef !24
  %view.val2.i.i29 = load i64, ptr %65, align 8, !dbg !9677, !alias.scope !9675, !noalias !9670, !noundef !24
  %_5.i3.i.i30 = icmp ult i64 %69, %view.val2.i.i29, !dbg !9678
  tail call void @llvm.assume(i1 %_5.i3.i.i30), !dbg !9682, !noalias !9670
  %_4.i.i.i31 = getelementptr inbounds nuw i64, ptr %view.val.i.i28, i64 %69, !dbg !9683
  br label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i11, !dbg !9684

_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i11: ; preds = %bb23.i, %bb3.i.i27
  %_0.sroa.0.0.in.i.i12 = phi ptr [ %_4.i.i.i31, %bb3.i.i27 ], [ %70, %bb23.i ]
  %_0.sroa.0.0.i.i13 = load i64, ptr %_0.sroa.0.0.in.i.i12, align 8, !dbg !9685, !noalias !9687, !noundef !24
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9688), !dbg !9668, !noalias !9670
  %71 = load ptr, ptr %_6.i14, align 8, !dbg !9691, !alias.scope !9693, !noalias !9670, !noundef !24
  %.not.i1.i15 = icmp eq ptr %71, null, !dbg !9691
  br i1 %.not.i1.i15, label %bb3.i8.i22, label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit32, !dbg !9694

bb3.i8.i22:                                       ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i11
  %view.val.i9.i23 = load ptr, ptr %view.i2.i16, align 8, !dbg !9695, !alias.scope !9693, !noalias !9670, !nonnull !24, !align !1357, !noundef !24
  %view.val2.i10.i24 = load i64, ptr %66, align 8, !dbg !9695, !alias.scope !9693, !noalias !9670, !noundef !24
  %_5.i3.i11.i25 = icmp ult i64 %69, %view.val2.i10.i24, !dbg !9696
  tail call void @llvm.assume(i1 %_5.i3.i11.i25), !dbg !9700, !noalias !9670
  %_4.i.i12.i26 = getelementptr inbounds nuw i64, ptr %view.val.i9.i23, i64 %69, !dbg !9701
  br label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit32, !dbg !9702

_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit32: ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i11, %bb3.i8.i22
  %_0.sroa.0.0.in.i6.i20 = phi ptr [ %_4.i.i12.i26, %bb3.i8.i22 ], [ %71, %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i11 ]
  %_11.i.i.i15.i = icmp ult i64 %_17.i, %_17.1.i.i.i.i4, !dbg !9703
  br i1 %_11.i.i.i15.i, label %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, label %panic.i.i.i.i5, !dbg !9703

panic.i.i.i.i5:                                   ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit32
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_17.i, i64 noundef %_17.1.i.i.i.i4, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d179419b0efea413e3bae0e1e9c82584) #19, !dbg !9703, !noalias !9670
  unreachable

_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i: ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit32
  %_0.sroa.0.0.i7.i21 = load i64, ptr %_0.sroa.0.0.in.i6.i20, align 8, !dbg !9704, !noalias !9706, !noundef !24
  %72 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i13, i64 %_0.sroa.0.0.i7.i21), !dbg !9707
  %_7.0.i.i.i.i.i.i8 = extractvalue { i64, i1 } %72, 0, !dbg !9707
  %_8.i.i.i.i.i.i9 = icmp sgt i64 %_7.0.i.i.i.i.i.i8, 0, !dbg !9711
  %_7.1.i.i.i.i.i.i10 = extractvalue { i64, i1 } %72, 1, !dbg !9707
  %_9.i.i.i.i12 = getelementptr inbounds nuw i8, ptr %_18.0.i.i.i.i11, i64 %_17.i, !dbg !9703
  %_21.i.i.i.i13 = zext i1 %_8.i.i.i.i.i.i9 to i8, !dbg !9712
  store i8 %_21.i.i.i.i13, ptr %_9.i.i.i.i12, align 1, !dbg !9715, !noalias !9670
  %73 = load i8, ptr %_19.i.i.i.i14, align 1, !dbg !9716, !range !4560, !alias.scope !9718, !noalias !9670, !noundef !24
  %74 = trunc nuw i8 %73 to i1, !dbg !9716
  %75 = or i1 %_7.1.i.i.i.i.i.i10, %74, !dbg !9716
  %76 = zext i1 %75 to i8, !dbg !9716
  store i8 %76, ptr %_19.i.i.i.i14, align 1, !dbg !9716, !alias.scope !9718, !noalias !9670
  %77 = add i64 %69, 1, !dbg !9721
  store i64 %77, ptr %1, align 8, !dbg !9721, !noalias !9551
  %78 = add nuw nsw i64 %iter2.sroa.0.055.i, 1, !dbg !9722
  %exitcond.not.i15 = icmp eq i64 %78, 64, !dbg !9733
  br i1 %exitcond.not.i15, label %bb13.i, label %bb23.i, !dbg !9736

bb13.i:                                           ; preds = %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit32.i, %bb3.i1
  %.promoted2123 = phi i64 [ %89, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit32.i ], [ %.promoted2124, %bb3.i1 ], [ %77, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i ]
  %79 = add i64 %base.sroa.0.0.i, 64, !dbg !9737
  br label %bb1.i, !dbg !9615

bb10.i:                                           ; preds = %bb3.i1, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit32.i
  %80 = phi i64 [ %89, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit32.i ], [ %.promoted2124, %bb3.i1 ]
  %word.sroa.0.054.i = phi i64 [ %90, %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit32.i ], [ %self.1.pn.i52.i, %bb3.i1 ]
  %81 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %word.sroa.0.054.i, i1 true), !dbg !9738
  %_25.i = or disjoint i64 %81, %base.sroa.0.0.i, !dbg !9742
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9743), !dbg !9746
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9750), !dbg !9753, !noalias !9755
  %82 = load ptr, ptr %_16.i.i.i.i3, align 8, !dbg !9758, !alias.scope !9760, !noalias !9755, !noundef !24
  %.not.i.i33 = icmp eq ptr %82, null, !dbg !9758
  br i1 %.not.i.i33, label %bb3.i.i54, label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i38, !dbg !9761

bb3.i.i54:                                        ; preds = %bb10.i
  %view.val.i.i55 = load ptr, ptr %view.i.i7, align 8, !dbg !9762, !alias.scope !9760, !noalias !9755, !nonnull !24, !align !1357, !noundef !24
  %view.val2.i.i56 = load i64, ptr %65, align 8, !dbg !9762, !alias.scope !9760, !noalias !9755, !noundef !24
  %_5.i3.i.i57 = icmp ult i64 %80, %view.val2.i.i56, !dbg !9763
  tail call void @llvm.assume(i1 %_5.i3.i.i57), !dbg !9767, !noalias !9755
  %_4.i.i.i58 = getelementptr inbounds nuw i64, ptr %view.val.i.i55, i64 %80, !dbg !9768
  br label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i38, !dbg !9769

_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i38: ; preds = %bb10.i, %bb3.i.i54
  %_0.sroa.0.0.in.i.i39 = phi ptr [ %_4.i.i.i58, %bb3.i.i54 ], [ %82, %bb10.i ]
  %_0.sroa.0.0.i.i40 = load i64, ptr %_0.sroa.0.0.in.i.i39, align 8, !dbg !9770, !noalias !9772, !noundef !24
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9773), !dbg !9753, !noalias !9755
  %83 = load ptr, ptr %_6.i14, align 8, !dbg !9776, !alias.scope !9778, !noalias !9755, !noundef !24
  %.not.i1.i42 = icmp eq ptr %83, null, !dbg !9776
  br i1 %.not.i1.i42, label %bb3.i8.i49, label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit59, !dbg !9779

bb3.i8.i49:                                       ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i38
  %view.val.i9.i50 = load ptr, ptr %view.i2.i16, align 8, !dbg !9780, !alias.scope !9778, !noalias !9755, !nonnull !24, !align !1357, !noundef !24
  %view.val2.i10.i51 = load i64, ptr %66, align 8, !dbg !9780, !alias.scope !9778, !noalias !9755, !noundef !24
  %_5.i3.i11.i52 = icmp ult i64 %80, %view.val2.i10.i51, !dbg !9781
  tail call void @llvm.assume(i1 %_5.i3.i11.i52), !dbg !9785, !noalias !9755
  %_4.i.i12.i53 = getelementptr inbounds nuw i64, ptr %view.val.i9.i50, i64 %80, !dbg !9786
  br label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit59, !dbg !9787

_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit59: ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i38, %bb3.i8.i49
  %_0.sroa.0.0.in.i6.i47 = phi ptr [ %_4.i.i12.i53, %bb3.i8.i49 ], [ %83, %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i38 ]
  %_11.i.i.i21.i = icmp ult i64 %_25.i, %_17.1.i.i.i.i4, !dbg !9788
  br i1 %_11.i.i.i21.i, label %_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit32.i, label %panic.i.i.i22.i, !dbg !9788

panic.i.i.i22.i:                                  ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit59
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_25.i, i64 noundef %_17.1.i.i.i.i4, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d179419b0efea413e3bae0e1e9c82584) #19, !dbg !9788, !noalias !9755
  unreachable

_RNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB7_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB1B_7execute13selected_rowsNtB9_10VortexHostB2n_NCINvMNtB39_5ownedINtB39_7ExecuteB3C_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4f_INtNtB1B_7visitor10RowVisitorB3C_E19visit_deferred_boolB5I_bKB5u_NCINvXs1_B4B_B4y_INtB62_5RowFnB3C_E8dispatchB4f_Es4_0NCB74_s5_0E0NCB5R_s_0B7T_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit32.i: ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit59
  %_0.sroa.0.0.i7.i48 = load i64, ptr %_0.sroa.0.0.in.i6.i47, align 8, !dbg !9789, !noalias !9791, !noundef !24
  %84 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i40, i64 %_0.sroa.0.0.i7.i48), !dbg !9792
  %_7.0.i.i.i.i.i25.i = extractvalue { i64, i1 } %84, 0, !dbg !9792
  %_8.i.i.i.i.i26.i = icmp sgt i64 %_7.0.i.i.i.i.i25.i, 0, !dbg !9796
  %_7.1.i.i.i.i.i27.i = extractvalue { i64, i1 } %84, 1, !dbg !9792
  %_9.i.i.i29.i = getelementptr inbounds nuw i8, ptr %_18.0.i.i.i.i11, i64 %_25.i, !dbg !9788
  %_21.i.i.i30.i = zext i1 %_8.i.i.i.i.i26.i to i8, !dbg !9797
  store i8 %_21.i.i.i30.i, ptr %_9.i.i.i29.i, align 1, !dbg !9800, !noalias !9755
  %85 = load i8, ptr %_19.i.i.i.i14, align 1, !dbg !9801, !range !4560, !alias.scope !9803, !noalias !9755, !noundef !24
  %86 = trunc nuw i8 %85 to i1, !dbg !9801
  %87 = or i1 %_7.1.i.i.i.i.i27.i, %86, !dbg !9801
  %88 = zext i1 %87 to i8, !dbg !9801
  store i8 %88, ptr %_19.i.i.i.i14, align 1, !dbg !9801, !alias.scope !9803, !noalias !9755
  %89 = add i64 %80, 1, !dbg !9806
  store i64 %89, ptr %1, align 8, !dbg !9806, !noalias !9551
  %_31.i = add i64 %word.sroa.0.054.i, -1, !dbg !9807
  %90 = and i64 %_31.i, %word.sroa.0.054.i, !dbg !9808
  %91 = icmp eq i64 %90, 0, !dbg !9809
  br i1 %91, label %bb13.i, label %bb10.i, !dbg !9809

_RINvMs0_NtNtCs7x6tOKv5niH_13vortex_buffer3bit3bufNtB6_9BitBuffer22try_for_each_set_indexNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB2d_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachB1o_NCINvNtB3I_7execute13selected_rowsNtB2f_10VortexHostB1o_NCINvMNtB4D_5ownedINtB4D_7ExecuteB56_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB5K_INtNtB3I_7visitor10RowVisitorB56_E19visit_deferred_boolB7d_bKB6Z_NCINvXs1_B66_B63_INtB7x_5RowFnB56_E8dispatchB5K_Es4_0NCB8z_s5_0E0NCB7m_s_0B9o_Es_0Es_0E0ECskkDzpO6M0zw_10boundaries.exit: ; preds = %_RINvMNtCslWxY2MhVcag_4core6optionINtB3_6OptionyE7or_elseNCNvXs_NtNtNtB5_4iter8adapters5chainINtBZ_5ChainNtNtNtCs6stDIWloaLs_12arrow_buffer4util18bit_chunk_iterator16BitChunkIteratorINtNtNtB13_7sources4once4OnceyEENtNtNtB13_6traits8iterator8Iterator4next0ECskkDzpO6M0zw_10boundaries.exit.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i), !dbg !9810, !noalias !9551
  br label %bb6, !dbg !9546

bb6:                                              ; preds = %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB4t_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5W_bKB5I_NCINvXs1_B4P_B4M_INtB6g_5RowFnB2X_E8dispatchB4t_Es4_0NCB7i_s5_0E0NCB65_s_0B87_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, %_RINvMs0_NtNtCs7x6tOKv5niH_13vortex_buffer3bit3bufNtB6_9BitBuffer22try_for_each_set_indexNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvXs_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl5batchNtB2d_15VortexSelectionNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachB1o_NCINvNtB3I_7execute13selected_rowsNtB2f_10VortexHostB1o_NCINvMNtB4D_5ownedINtB4D_7ExecuteB56_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB5K_INtNtB3I_7visitor10RowVisitorB56_E19visit_deferred_boolB7d_bKB6Z_NCINvXs1_B66_B63_INtB7x_5RowFnB56_E8dispatchB5K_Es4_0NCB8z_s5_0E0NCB7m_s_0B9o_Es_0Es_0E0ECskkDzpO6M0zw_10boundaries.exit, %bb4, %start
  ret void, !dbg !9811
}