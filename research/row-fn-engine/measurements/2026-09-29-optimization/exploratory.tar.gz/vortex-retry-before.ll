; target/release/deps/boundaries-3c3a77a76c6fcdfa.boundaries.ecd45eb892372cfc-cgu.00.rcgu.ll
; <rofl::execute::Execute<vortex_array::scalar_fn::unstable::rofl::VortexHost, rofl_examples::functions::PositiveSum<true>> as rofl::visitor::RowVisitor<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::visit_deferred_bool::<(i64, i64), bool, true, <rofl_examples::functions::PositiveSum<true> as rofl::visitor::RowFn<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::dispatch<rofl::execute::Execute<vortex_array::scalar_fn::unstable::rofl::VortexHost, rofl_examples::functions::PositiveSum<true>>>::{closure#6}, <rofl_examples::functions::PositiveSum<true> as rofl::visitor::RowFn<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::dispatch<rofl::execute::Execute<vortex_array::scalar_fn::unstable::rofl::VortexHost, rofl_examples::functions::PositiveSum<true>>>::{closure#7}>
define hidden void @_RINvYINtNtCshZi9mpuUhIi_4rofl7execute7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB8_7visitor10RowVisitorBH_E19visit_deferred_boolTxxEbKB2N_NCINvXs1_B1U_B1R_INtB2V_5RowFnBH_E8dispatchB3_Es4_0NCB3V_s5_0ECskkDzpO6M0zw_10boundaries(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([88 x i8]) align 8 captures(address) dereferenceable(88) %_0, ptr dead_on_return noalias nofree noundef align 8 captures(address) dereferenceable(104) %self) unnamed_addr #0 personality ptr @rust_eh_personality !dbg !41833 {
start:
  %prepared.i.i.i = alloca [0 x i8], align 1
  %_9.i.i.i = alloca [88 x i8], align 8
  %_9.i.i33.i.i = alloca [88 x i8], align 8
  %_61.i.i.i = alloca [80 x i8], align 8
  %_39.i.i.i = alloca [80 x i8], align 8
  %_35.i.i.i = alloca [80 x i8], align 8
  %values.i.i.i = alloca [16 x i8], align 8
  %state.i.i.i = alloca [64 x i8], align 8
  %_21.i.i.i = alloca [80 x i8], align 8
  %_20.sroa.6.i.i.i = alloca [56 x i8], align 8
  %_18.i.i.i = alloca [32 x i8], align 8
  %_9.sroa.13.i.i.i = alloca [23 x i8], align 1
  %_9.sroa.17.i.i.i = alloca [47 x i8], align 1
  %_8.sroa.5.sroa.0.sroa.8.i.i.i = alloca [23 x i8], align 1
  %_8.sroa.5.sroa.8.i.i.i = alloca [47 x i8], align 1
  %columns.i35.i.i = alloca [80 x i8], align 8
  %_9.i.i.i.i = alloca [88 x i8], align 8
  %_8.i.i.i.i.i = alloca [8 x i8], align 8
  %len.i.i.i.i.i = alloca [8 x i8], align 8
  %_9.i.i.i.i.i = alloca [88 x i8], align 8
  %_89.i.i.i.i = alloca [80 x i8], align 8
  %_74.i.i.i.i = alloca [88 x i8], align 8
  %_68.i.i.i.i = alloca [80 x i8], align 8
  %_44.i.i.i.i = alloca [80 x i8], align 8
  %_32.i.i.i.i = alloca [80 x i8], align 8
  %_22.i.i.i.i = alloca [88 x i8], align 8
  %_21.sroa.6.i.i.i.i = alloca [80 x i8], align 8
  %output.i.i.i.i = alloca [88 x i8], align 8
  %_18.i.i.i.i = alloca [32 x i8], align 8
  %_9.sroa.13.i.i.i.i = alloca [23 x i8], align 1
  %_9.sroa.17.i.i.i.i = alloca [47 x i8], align 1
  %_8.sroa.5.sroa.0.sroa.8.i.i.i.i = alloca [23 x i8], align 1
  %_8.sroa.5.sroa.8.i.i.i.i = alloca [47 x i8], align 1
  %columns.i.i.i.i = alloca [80 x i8], align 8
  %_73.i.i.i = alloca [88 x i8], align 8
  %_67.i.i.i = alloca [80 x i8], align 8
  %_60.i.i.i = alloca [48 x i8], align 8
  %_56.i.i.i = alloca [80 x i8], align 8
  %failure6.i.i.i = alloca [1 x i8], align 1
  %_47.i.i.i = alloca [56 x i8], align 8
  %_37.i.i.i = alloca [88 x i8], align 8
  %_36.sroa.6.i.i.i = alloca [80 x i8], align 8
  %output.i.i.i = alloca [88 x i8], align 8
  %_30.i.i.i = alloca [80 x i8], align 8
  %_29.sroa.6.i.i.i = alloca [56 x i8], align 8
  %source.i.i.i = alloca [56 x i8], align 8
  %_26.i.i.i = alloca [32 x i8], align 8
  %_18.sroa.13.i.i.i = alloca [23 x i8], align 1
  %_18.sroa.17.i.i.i = alloca [47 x i8], align 1
  %_17.sroa.6.sroa.0.sroa.9.i.i.i = alloca [23 x i8], align 1
  %_17.sroa.6.sroa.9.i.i.i = alloca [47 x i8], align 1
  %columns.i.i.i = alloca [80 x i8], align 8
  %_11.i.i.i = alloca [104 x i8], align 8
  %_8.i.i.i = alloca [24 x i8], align 8
  %_6.i.i.i = alloca [80 x i8], align 8
  %_80.i.i = alloca [80 x i8], align 8
  %_55.i.i = alloca [80 x i8], align 8
  %_50.i.i = alloca [80 x i8], align 8
  %values.i.i = alloca [16 x i8], align 8
  %collect.i.i = alloca [32 x i8], align 8
  %failure.i.i = alloca [1 x i8], align 1
  %_37.i.i = alloca [80 x i8], align 8
  %_36.sroa.6.i.i = alloca [56 x i8], align 8
  %source.i.i = alloca [56 x i8], align 8
  %_33.i.i = alloca [32 x i8], align 8
  %_24.sroa.13.i.i = alloca [23 x i8], align 1
  %_24.sroa.17.i.i = alloca [47 x i8], align 1
  %_23.sroa.5.sroa.0.sroa.8.i.i = alloca [23 x i8], align 1
  %_23.sroa.5.sroa.8.i.i = alloca [47 x i8], align 1
  %columns.i.i = alloca [80 x i8], align 8
  %_16.i.i = alloca [104 x i8], align 8
  %_13.i.i = alloca [24 x i8], align 8
  %_11.i.i = alloca [80 x i8], align 8
  %_6.i.i = alloca [104 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !41834), !dbg !41837
  tail call void @llvm.experimental.noalias.scope.decl(metadata !41838), !dbg !41837
  tail call void @llvm.experimental.noalias.scope.decl(metadata !41840), !dbg !41843
  tail call void @llvm.experimental.noalias.scope.decl(metadata !41846), !dbg !41843
  call void @llvm.lifetime.start.p0(ptr nonnull %_23.sroa.5.sroa.0.sroa.8.i.i), !dbg !41848
  call void @llvm.lifetime.start.p0(ptr nonnull %_23.sroa.5.sroa.8.i.i), !dbg !41848
  %_5.i.i = load i64, ptr %self, align 8, !dbg !41848, !range !5768, !alias.scope !41853, !noalias !41854, !noundef !37
  %switch.not.i.i = icmp samesign ult i64 %_5.i.i, 2, !dbg !41855
  br i1 %switch.not.i.i, label %bb4.i.i, label %bb2.i.i, !dbg !41855

bb2.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.i.i), !dbg !41856, !noalias !41857
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(104) %_6.i.i, ptr noundef nonnull align 8 dereferenceable(104) %self, i64 104, i1 false), !dbg !41856, !noalias !41854
  tail call void @llvm.experimental.noalias.scope.decl(metadata !41858), !dbg !41861
  tail call void @llvm.experimental.noalias.scope.decl(metadata !41862), !dbg !41861
  call void @llvm.lifetime.start.p0(ptr nonnull %_17.sroa.6.sroa.0.sroa.9.i.i.i), !dbg !41864
  call void @llvm.lifetime.start.p0(ptr nonnull %_17.sroa.6.sroa.9.i.i.i), !dbg !41864
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.i.i.i), !dbg !41864, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i.i), !dbg !41868, !noalias !41867
  %0 = getelementptr inbounds nuw i8, ptr %_8.i.i.i, i64 1, !dbg !41869
  store i8 0, ptr %0, align 1, !dbg !41869, !alias.scope !41872, !noalias !41867
  store i8 1, ptr %_8.i.i.i, align 8, !dbg !41869, !alias.scope !41872, !noalias !41867
; invoke <rofl::execute::Execute<vortex_array::scalar_fn::unstable::rofl::VortexHost, rofl_examples::functions::PositiveSum<true>>>::validate::<(i64, i64)>
  invoke fastcc void @_RINvMs_NtCshZi9mpuUhIi_4rofl7executeINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8validateTxxEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 captures(address) dereferenceable(80) %_6.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(104) %_6.i.i, ptr noalias nofree noundef align 8 captures(address) dereferenceable(24) %_8.i.i.i)
          to label %bb2.i.i.i unwind label %bb42.thread112.i.i.i, !dbg !41875

bb2.i.i.i:                                        ; preds = %bb2.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i.i), !dbg !41876, !noalias !41867
  %1 = load i64, ptr %_6.i.i.i, align 8, !dbg !41877, !range !1887, !noalias !41867, !noundef !37
  %.not.i.i.i = icmp eq i64 %1, -1, !dbg !41877
  br i1 %.not.i.i.i, label %bb62.i.i.i, label %bb61.i.i.i, !dbg !41880

bb61.i.i.i:                                       ; preds = %bb2.i.i.i
  %2 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !41881
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %2, ptr noundef nonnull align 8 dereferenceable(80) %_6.i.i.i, i64 80, i1 false), !dbg !41888, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i.i.i), !dbg !41890, !noalias !41867
  store i64 1, ptr %_0, align 8, !dbg !41881, !alias.scope !41891, !noalias !41889
  br label %bb49.critedge.i.i.i, !dbg !41892

bb62.i.i.i:                                       ; preds = %bb2.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i.i.i), !dbg !41890, !noalias !41867
  %_10.i.i.i = load i64, ptr %_6.i.i, align 8, !dbg !41894, !range !5768, !alias.scope !41862, !noalias !41897, !noundef !37
  %3 = icmp eq i64 %_10.i.i.i, 1, !dbg !41898
  br i1 %3, label %bb4.i.i.i, label %bb6.i.i.i, !dbg !41898

bb4.i.i.i:                                        ; preds = %bb62.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_11.i.i.i), !dbg !41899, !noalias !41867
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(104) %_11.i.i.i, ptr noundef nonnull align 8 dereferenceable(104) %_6.i.i, i64 104, i1 false), !dbg !41899, !noalias !41897
  call void @llvm.experimental.noalias.scope.decl(metadata !41900), !dbg !41903
  call void @llvm.experimental.noalias.scope.decl(metadata !41904), !dbg !41903
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.5.sroa.0.sroa.8.i.i.i.i), !dbg !41906
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.5.sroa.8.i.i.i.i), !dbg !41906
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i.i.i.i), !dbg !41906, !noalias !41909
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.sroa.13.i.i.i.i), !dbg !41910
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.sroa.17.i.i.i.i), !dbg !41910
  call void @llvm.experimental.noalias.scope.decl(metadata !41911), !dbg !41914
  %_3.i.i.i.i.i = load i64, ptr %_11.i.i.i, align 8, !dbg !41915, !range !5768, !alias.scope !41920, !noalias !41921, !noundef !37
  %tolerant.i.i.i.i.i = icmp eq i64 %_3.i.i.i.i.i, 2, !dbg !41923
  br i1 %tolerant.i.i.i.i.i, label %bb1.i.i.i.i.i, label %start.bb4_crit_edge.i.i.i.i.i, !dbg !41924

start.bb4_crit_edge.i.i.i.i.i:                    ; preds = %bb4.i.i.i
  %.phi.trans.insert.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 40
  %_11.0.pre.i.i.i.i.i = load ptr, ptr %.phi.trans.insert.i.i.i.i.i, align 8, !dbg !41926, !alias.scope !41920, !noalias !41921
  %.phi.trans.insert4.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 48
  %_11.1.pre.i.i.i.i.i = load i64, ptr %.phi.trans.insert4.i.i.i.i.i, align 8, !dbg !41926, !alias.scope !41920, !noalias !41921
  br label %bb4.i.i.i.i.i, !dbg !41924

bb4.i.i.i.i.i:                                    ; preds = %bb11.i.i.i.i.i, %start.bb4_crit_edge.i.i.i.i.i
  %_11.1.i.i.i.i.i = phi i64 [ %_11.1.pre.i.i.i.i.i, %start.bb4_crit_edge.i.i.i.i.i ], [ %_10.1.i.i.i.i.i, %bb11.i.i.i.i.i ], !dbg !41926
  %_11.0.i.i.i.i.i = phi ptr [ %_11.0.pre.i.i.i.i.i, %start.bb4_crit_edge.i.i.i.i.i ], [ %_10.0.i.i.i.i.i, %bb11.i.i.i.i.i ], !dbg !41926
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i.i.i), !dbg !41927, !noalias !41928
  %4 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 80, !dbg !41929
  %_12.i.i.i.i.i = load ptr, ptr %4, align 8, !dbg !41929, !alias.scope !41920, !noalias !41921, !nonnull !37, !align !40, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([88 x i8]) align 8 captures(none) dereferenceable(88) %_9.i.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i.i.i.i, i64 noundef %_11.1.i.i.i.i.i, i1 noundef zeroext %tolerant.i.i.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i.i.i.i)
          to label %.noexc.i.i.i.i unwind label %cleanup.i.i.i.i, !dbg !41927, !noalias !41930

.noexc.i.i.i.i:                                   ; preds = %bb4.i.i.i.i.i
  %_20.i.i.i.i.i = load i64, ptr %_9.i.i.i.i.i, align 8, !dbg !41931, !range !4730, !noalias !41928, !noundef !37
  %5 = trunc nuw i64 %_20.i.i.i.i.i to i1, !dbg !41934
  %6 = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 8, !dbg !41935
  %_9.sroa.7.8.copyload74.i.i.i.i = load i64, ptr %6, align 8, !dbg !41935, !noalias !41936
  %_9.sroa.12.8..sroa_idx77.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 16, !dbg !41935
  %_9.sroa.12.8.copyload78.i.i.i.i = load i8, ptr %_9.sroa.12.8..sroa_idx77.i.i.i.i, align 8, !dbg !41935, !noalias !41936
  %_9.sroa.13.8..sroa_idx81.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 17, !dbg !41935
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.13.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.13.8..sroa_idx81.i.i.i.i, i64 23, i1 false), !dbg !41935, !noalias !41936
  %_9.sroa.14.8..sroa_idx82.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 40, !dbg !41935
  %_9.sroa.14.8.copyload83.i.i.i.i = load i8, ptr %_9.sroa.14.8..sroa_idx82.i.i.i.i, align 8, !dbg !41935, !noalias !41936
  %_9.sroa.17.8..sroa_idx84.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 41, !dbg !41935
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_9.sroa.17.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_9.sroa.17.8..sroa_idx84.i.i.i.i, i64 47, i1 false), !dbg !41935, !noalias !41936
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i.i), !dbg !41937, !noalias !41928
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.5.sroa.0.sroa.8.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.13.i.i.i.i, i64 23, i1 false), !dbg !41938, !noalias !41909
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_8.sroa.5.sroa.8.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_9.sroa.17.i.i.i.i, i64 47, i1 false), !dbg !41938, !noalias !41909
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.13.i.i.i.i), !dbg !41941
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.17.i.i.i.i), !dbg !41941
  br i1 %5, label %bb55.i.i.i.i, label %bb56.i.i.i.i, !dbg !41934

bb1.i.i.i.i.i:                                    ; preds = %bb4.i.i.i
  %7 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 48, !dbg !41942
  %_10.1.i.i.i.i.i = load i64, ptr %7, align 8, !dbg !41942, !alias.scope !41920, !noalias !41921, !noundef !37
  %switch = icmp ult i64 %_10.1.i.i.i.i.i, 2, !dbg !41943
  br i1 %switch, label %panic3.i.invoke, label %bb11.i.i.i.i.i, !dbg !41943

panic3.i.invoke:                                  ; preds = %bb1.i.i.i.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i.i.i.i, i64 noundef %_10.1.i.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i.cont unwind label %cleanup.i.i.i.i, !dbg !41943

panic3.i.cont:                                    ; preds = %panic3.i.invoke
  unreachable

bb11.i.i.i.i.i:                                   ; preds = %bb1.i.i.i.i.i
  %8 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 40, !dbg !41942
  %_10.0.i.i.i.i.i = load ptr, ptr %8, align 8, !dbg !41942, !alias.scope !41920, !noalias !41921, !nonnull !37, !align !40, !noundef !37
  br label %bb4.i.i.i.i.i, !dbg !41946

bb52.i.i.i.i:                                     ; preds = %bb40.i.i.i.i, %bb2.i.i.i.i.i3.i66.i.i.i.i, %bb2.i.i.i1.i63.i.i.i.i, %cleanup.i62.i.i.i.i, %bb2.i.i.i.i.i3.i.i.i.i.i, %bb2.i.i.i1.i.i.i.i.i, %cleanup.i.i.i.i.i, %cleanup.i.i.i.i
  %.pn39.i.i.i.i = phi { ptr, i32 } [ %.pn37.i.i.i.i, %bb40.i.i.i.i ], [ %100, %cleanup.i.i.i.i.i ], [ %12, %cleanup.i.i.i.i ], [ %100, %bb2.i.i.i.i.i3.i.i.i.i.i ], [ %100, %bb2.i.i.i1.i.i.i.i.i ], [ %117, %bb2.i.i.i.i.i3.i66.i.i.i.i ], [ %117, %bb2.i.i.i1.i63.i.i.i.i ], [ %117, %cleanup.i62.i.i.i.i ]
  %9 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 16, !dbg !41947
  %10 = load i8, ptr %9, align 8, !dbg !41949, !range !1916, !alias.scope !41951, !noalias !41956, !noundef !37
  %11 = icmp eq i8 %10, -1, !dbg !41949
  br i1 %11, label %bb36.i.i, label %bb2.i.i.i.i.i.i, !dbg !41949

bb2.i.i.i.i.i.i:                                  ; preds = %bb52.i.i.i.i
; invoke core::ptr::drop_glue::<vortex_array::dtype::DType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %9)
          to label %bb36.i.i unwind label %terminate.i.i.i.i, !dbg !41949, !noalias !41957

cleanup.i.i.i.i:                                  ; preds = %panic3.i.invoke, %bb2.i.i.i.i.i8.i60.i.i.i.i, %bb2.i.i.i.i.i8.i.i.i.i.i, %bb57.i.i.i.i, %bb4.i.i.i.i.i
  %12 = landingpad { ptr, i32 }
          cleanup
  br label %bb52.i.i.i.i

bb55.i.i.i.i:                                     ; preds = %.noexc.i.i.i.i
  %_91.sroa.0.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !41958
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_91.sroa.0.sroa.5.0..sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.5.sroa.0.sroa.8.i.i.i.i, i64 23, i1 false), !dbg !41941, !noalias !41965
  %_91.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 41, !dbg !41958
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_91.sroa.5.0..sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_8.sroa.5.sroa.8.i.i.i.i, i64 47, i1 false), !dbg !41941, !noalias !41965
  br label %bb33.i.i.i.i, !dbg !41966

bb56.i.i.i.i:                                     ; preds = %.noexc.i.i.i.i
  %.not.i.i.i.i = icmp eq i8 %_9.sroa.14.8.copyload83.i.i.i.i, 2, !dbg !41968
  br i1 %.not.i.i.i.i, label %bb57.i.i.i.i, label %bb58.i.i.i.i, !dbg !41971

bb58.i.i.i.i:                                     ; preds = %bb56.i.i.i.i
  %val2.sroa.0.sroa.5.0.columns.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 9, !dbg !41972
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val2.sroa.0.sroa.5.0.columns.sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.5.sroa.0.sroa.8.i.i.i.i, i64 23, i1 false), !dbg !41910, !noalias !41909
  %val2.sroa.5.0.columns.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 33, !dbg !41972
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %val2.sroa.5.0.columns.sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_8.sroa.5.sroa.8.i.i.i.i, i64 47, i1 false), !dbg !41910, !noalias !41909
  store i64 %_9.sroa.7.8.copyload74.i.i.i.i, ptr %columns.i.i.i.i, align 8, !dbg !41972, !noalias !41909
  %val2.sroa.0.sroa.4.0.columns.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 8, !dbg !41972
  store i8 %_9.sroa.12.8.copyload78.i.i.i.i, ptr %val2.sroa.0.sroa.4.0.columns.sroa_idx.i.i.i.i, align 8, !dbg !41972, !noalias !41909
  %val2.sroa.4.0.columns.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 32, !dbg !41972
  store i8 %_9.sroa.14.8.copyload83.i.i.i.i, ptr %val2.sroa.4.0.columns.sroa_idx.i.i.i.i, align 8, !dbg !41972, !noalias !41909
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.i.i.i.i), !dbg !41975, !noalias !41909
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_18.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i.i.i.i)
          to label %bb4.i.i.i.i unwind label %cleanup11.i.i.i.i, !dbg !41975, !noalias !41930

bb57.i.i.i.i:                                     ; preds = %bb56.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_89.i.i.i.i), !dbg !41977, !noalias !41909
; invoke <vortex_array::scalar_fn::unstable::rofl::VortexHost as rofl::host::Host>::error
  invoke void @_RNvXNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4roflNtB2_10VortexHostNtNtCshZi9mpuUhIi_4rofl4host4Host5error(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(address) dereferenceable(80) %_89.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_90e3c4e2332b77b0fece2c0e180e7e89, i64 noundef 27)
          to label %bb59.i.i.i.i unwind label %cleanup.i.i.i.i, !dbg !41978, !noalias !41930

bb59.i.i.i.i:                                     ; preds = %bb57.i.i.i.i
  %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.i.i = load i64, ptr %_89.i.i.i.i, align 8, !dbg !41981, !noalias !41909
  %_7.sroa.6.sroa.0.sroa.8.0._89.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_89.i.i.i.i, i64 8, !dbg !41981
  %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.i.i = load i8, ptr %_7.sroa.6.sroa.0.sroa.8.0._89.sroa_idx.i.i.i.i, align 8, !dbg !41981, !noalias !41909
  %_7.sroa.6.sroa.0.sroa.9.0._89.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_89.i.i.i.i, i64 9, !dbg !41981
  %_97.sroa.0.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !41982
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_97.sroa.0.sroa.5.0..sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_7.sroa.6.sroa.0.sroa.9.0._89.sroa_idx.i.i.i.i, i64 23, i1 false), !dbg !41981, !noalias !41965
  %_7.sroa.6.sroa.8.0._89.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_89.i.i.i.i, i64 32, !dbg !41981
  %_7.sroa.6.sroa.8.0.copyload.i.i.i.i = load i8, ptr %_7.sroa.6.sroa.8.0._89.sroa_idx.i.i.i.i, align 8, !dbg !41981, !noalias !41909
  %_7.sroa.6.sroa.9.0._89.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_89.i.i.i.i, i64 33, !dbg !41981
  %_97.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 41, !dbg !41982
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_97.sroa.5.0..sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_7.sroa.6.sroa.9.0._89.sroa_idx.i.i.i.i, i64 47, i1 false), !dbg !41981, !noalias !41965
  call void @llvm.lifetime.end.p0(ptr nonnull %_89.i.i.i.i), !dbg !41988, !noalias !41909
  br label %bb33.i.i.i.i, !dbg !41989

bb33.i.i.i.i:                                     ; preds = %bb59.i.i.i.i, %bb55.i.i.i.i
  %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.sink.i.i = phi i64 [ %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.i.i, %bb59.i.i.i.i ], [ %_9.sroa.7.8.copyload74.i.i.i.i, %bb55.i.i.i.i ]
  %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.sink.i.i = phi i8 [ %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.i.i, %bb59.i.i.i.i ], [ %_9.sroa.12.8.copyload78.i.i.i.i, %bb55.i.i.i.i ]
  %_7.sroa.6.sroa.8.0.copyload.i.i.sink.i.i = phi i8 [ %_7.sroa.6.sroa.8.0.copyload.i.i.i.i, %bb59.i.i.i.i ], [ %_9.sroa.14.8.copyload83.i.i.i.i, %bb55.i.i.i.i ]
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !41990
  store i64 %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.sink.i.i, ptr %13, align 8, !dbg !41990, !alias.scope !41992, !noalias !41965
  %_97.sroa.0.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !41990
  store i8 %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.sink.i.i, ptr %_97.sroa.0.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !41990, !alias.scope !41992, !noalias !41965
  %_97.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !41990
  store i8 %_7.sroa.6.sroa.8.0.copyload.i.i.sink.i.i, ptr %_97.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !41990, !alias.scope !41992, !noalias !41965
  store i64 1, ptr %_0, align 8, !dbg !41993, !alias.scope !41992, !noalias !41965
  br label %bb34.i.i.i.i, !dbg !41966

cleanup11.i.i.i.i:                                ; preds = %bb58.i.i.i.i
  %14 = landingpad { ptr, i32 }
          cleanup
  br label %bb40.i.i.i.i, !dbg !41995

bb4.i.i.i.i:                                      ; preds = %bb58.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.i.i.i.i), !dbg !41995, !noalias !41909
  call void @llvm.lifetime.start.p0(ptr nonnull %output.i.i.i.i), !dbg !41996, !noalias !41909
  call void @llvm.lifetime.start.p0(ptr nonnull %_21.sroa.6.i.i.i.i), !dbg !41998
  call void @llvm.lifetime.start.p0(ptr nonnull %_22.i.i.i.i), !dbg !41998, !noalias !41909
  %15 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 96, !dbg !41999
  %_23.i.i.i.i = load i64, ptr %15, align 8, !dbg !41999, !alias.scope !41904, !noalias !41956, !noundef !37
; invoke <vortex_array::scalar_fn::unstable::rofl::VortexHost as rofl::output::OutputBinding<bool>>::allocate
  invoke void @_RNvXs0_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6outputNtB7_10VortexHostINtNtCshZi9mpuUhIi_4rofl6output13OutputBindingbE8allocate(ptr noalias nofree noundef nonnull sret([88 x i8]) align 8 captures(none) dereferenceable(88) %_22.i.i.i.i, i64 noundef %_23.i.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i.i.i.i)
          to label %bb5.i.i.i.i unwind label %cleanup12.i.i.i.i, !dbg !41998, !noalias !41930

cleanup12.i.i.i.i:                                ; preds = %bb30.i.i.i.i, %bb23.i.i.i.i, %bb4.i.i.i.i
  %16 = landingpad { ptr, i32 }
          cleanup
  br label %bb40.i.i.i.i

bb5.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %17 = load i64, ptr %_22.i.i.i.i, align 8, !dbg !42000, !range !26899, !noalias !41909, !noundef !37
  %18 = icmp eq i64 %17, 0, !dbg !42000
  %19 = getelementptr inbounds nuw i8, ptr %_22.i.i.i.i, i64 8, !dbg !42003
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %_21.sroa.6.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(80) %19, i64 80, i1 false), !dbg !42003, !noalias !41909
  call void @llvm.lifetime.end.p0(ptr nonnull %_22.i.i.i.i), !dbg !42004, !noalias !41909
  br i1 %18, label %bb60.i.i.i.i, label %bb61.i.i.i.i, !dbg !42005

bb60.i.i.i.i:                                     ; preds = %bb5.i.i.i.i
  %20 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42006
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %20, ptr noundef nonnull align 8 dereferenceable(80) %_21.sroa.6.i.i.i.i, i64 80, i1 false), !dbg !42004, !noalias !41965
  store i64 1, ptr %_0, align 8, !dbg !42006, !alias.scope !41992, !noalias !41965
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.sroa.6.i.i.i.i), !dbg !42012
  br label %bb31.i.i.i.i, !dbg !42013

bb61.i.i.i.i:                                     ; preds = %bb5.i.i.i.i
  %val4.sroa.4.0.output.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %output.i.i.i.i, i64 8, !dbg !42015
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %val4.sroa.4.0.output.sroa_idx.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(80) %_21.sroa.6.i.i.i.i, i64 80, i1 false), !dbg !41998, !noalias !41909
  store i64 %17, ptr %output.i.i.i.i, align 8, !dbg !42015, !noalias !41909
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.sroa.6.i.i.i.i), !dbg !42012
  %21 = getelementptr inbounds nuw i8, ptr %output.i.i.i.i, i64 48, !dbg !42018
  store i64 0, ptr %21, align 8, !dbg !42018, !alias.scope !42023, !noalias !41930
  %22 = getelementptr inbounds nuw i8, ptr %output.i.i.i.i, i64 40, !dbg !42028
  %_8.i.i = load ptr, ptr %22, align 8, !dbg !42028, !alias.scope !42023, !noalias !41930, !nonnull !37, !noundef !37
  %23 = getelementptr inbounds nuw i8, ptr %output.i.i.i.i, i64 56, !dbg !42031
  %_6.i.i33 = load i64, ptr %23, align 8, !dbg !42031, !alias.scope !42023, !noalias !41930, !noundef !37
  %_106.not.i.i.i.i = icmp ugt i64 %_23.i.i.i.i, %_6.i.i33
  br i1 %_106.not.i.i.i.i, label %bb64.i.i.i.i, label %bb62.i.i.i.i, !dbg !42033, !prof !11657

bb48.thread121.loopexit.split-lp.i.i.i.i:         ; preds = %bb1.i47.i.i.i.i, %bb8.i.i.i.i, %bb3.i.i.i.i.i, %bb64.i.i.i.i, %bb62.i.i.i.i
  %lpad.loopexit.split-lp.i.i.i.i = landingpad { ptr, i32 }
          cleanup
; invoke core::ptr::drop_glue::<vortex_array::scalar_fn::unstable::rofl::output::VortexBuffer<i8>>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6output12VortexBufferaEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(88) %output.i.i.i.i) #21
          to label %bb40.i.i.i.i unwind label %terminate.i.i.i.i, !dbg !42042, !noalias !41930

bb48.i.i.i.i:                                     ; preds = %bb24.i.i.i.i
  %lpad.thr_comm.split-lp.i.i.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb40.i.i.i.i, !dbg !42042

bb62.i.i.i.i:                                     ; preds = %bb61.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_32.i.i.i.i), !dbg !42043, !noalias !41909
  %24 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 88, !dbg !42046
  %_34.i.i.i.i = load i64, ptr %24, align 8, !dbg !42046, !alias.scope !41904, !noalias !41956, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::rows_source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE11rows_sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(none) dereferenceable(80) %_32.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i.i.i.i, i64 noundef %_34.i.i.i.i)
          to label %bb7.i.i.i.i unwind label %bb48.thread121.loopexit.split-lp.i.i.i.i, !dbg !42043, !noalias !41930

bb64.i.i.i.i:                                     ; preds = %bb61.i.i.i.i
; invoke core::slice::index::slice_index_fail
  invoke void @_RNvNtNtCslWxY2MhVcag_4core5slice5index16slice_index_fail(i64 noundef 0, i64 noundef %_23.i.i.i.i, i64 noundef %_6.i.i33, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_252cd9d951382406ba1527cf23875b08) #22
          to label %unreachable.i.i.i.i unwind label %bb48.thread121.loopexit.split-lp.i.i.i.i, !dbg !42047, !noalias !41930

bb7.i.i.i.i:                                      ; preds = %bb62.i.i.i.i
  %25 = load i64, ptr %_32.i.i.i.i, align 8, !dbg !42048, !range !1887, !noalias !41909, !noundef !37
  %.not30.i.i.i.i = icmp eq i64 %25, -1, !dbg !42048
  %26 = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 8, !dbg !42051
  %_115.sroa.0.0.copyload.i.i.i.i = load ptr, ptr %26, align 8, !dbg !42051, !noalias !41909
  %_115.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 16, !dbg !42051
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.0.0.copyload = load i64, ptr %_115.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !42051, !noalias !41909
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0._115.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 24, !dbg !42051
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload = load ptr, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0._115.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42051, !noalias !41909
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0._115.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 32, !dbg !42051
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0.copyload = load i64, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0._115.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42051, !noalias !41909
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0._115.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 40, !dbg !42051
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0.copyload = load i64, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0._115.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42051, !noalias !41909
  br i1 %.not30.i.i.i.i, label %bb68.i.i.i.i, label %bb67.i.i.i.i, !dbg !42052

bb67.i.i.i.i:                                     ; preds = %bb7.i.i.i.i
  %_116.sroa.6.0._32.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 48, !dbg !42053
  %_119.sroa.6.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 56, !dbg !42054
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_119.sroa.6.0..sroa_idx.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %_116.sroa.6.0._32.sroa_idx.i.i.i.i, i64 32, i1 false), !dbg !42053, !noalias !41965
  call void @llvm.lifetime.end.p0(ptr nonnull %_32.i.i.i.i), !dbg !42060, !noalias !41909
  %_119.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !42054
  store i64 %_31.sroa.7.sroa.8.i.i.i.i.sroa.0.0.copyload, ptr %_119.sroa.5.0..sroa_idx.i.i.i.i, align 8, !dbg !42060, !noalias !41965
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0._119.sroa.5.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !42060
  store ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0._119.sroa.5.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42060, !noalias !41965
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0._119.sroa.5.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !42060
  store i64 %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0.copyload, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0._119.sroa.5.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42060, !noalias !41965
  %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0._119.sroa.5.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 48, !dbg !42060
  store i64 %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0.copyload, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0._119.sroa.5.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42060, !noalias !41965
  %27 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42054
  store i64 %25, ptr %27, align 8, !dbg !42054, !alias.scope !41992, !noalias !41965
  %_119.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42054
  store ptr %_115.sroa.0.0.copyload.i.i.i.i, ptr %_119.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !42054, !alias.scope !41992, !noalias !41965
  br label %bb30.i.i.i.i, !dbg !42061

bb68.i.i.i.i:                                     ; preds = %bb7.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_32.i.i.i.i), !dbg !42060, !noalias !41909
  %.not31.i.i.i.i = icmp eq ptr %_115.sroa.0.0.copyload.i.i.i.i, null, !dbg !42043
  br i1 %.not31.i.i.i.i, label %bb8.i.i.i.i, label %bb9.i.i.i.i, !dbg !42063

bb9.i.i.i.i:                                      ; preds = %bb68.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !42064), !dbg !42067
  call void @llvm.lifetime.start.p0(ptr nonnull %len.i.i.i.i.i), !dbg !42068, !noalias !42072
  store i64 %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0.copyload, ptr %len.i.i.i.i.i, align 8, !dbg !42074, !noalias !42072
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i.i.i.i), !dbg !42075, !noalias !42072
  store i64 %_23.i.i.i.i, ptr %_8.i.i.i.i.i, align 8, !dbg !42075, !noalias !42072
  %_10.i.i.i.i.i = icmp eq i64 %_23.i.i.i.i, %_31.sroa.7.sroa.8.i.i.i.i.sroa.7.0.copyload, !dbg !42077
  br i1 %_10.i.i.i.i.i, label %bb2.i.i.i.i.i, label %bb3.i.i.i.i.i, !dbg !42077, !prof !10472

bb3.i.i.i.i.i:                                    ; preds = %bb9.i.i.i.i
; invoke core::panicking::assert_failed::<usize, usize>
  invoke void @_RINvNtCslWxY2MhVcag_4core9panicking13assert_failedjjEB4_(i8 noundef 0, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_8.i.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %len.i.i.i.i.i, ptr noundef nonnull @alloc_f0da620865384e74e3a64c84279d94d6, ptr nonnull inttoptr (i64 79 to ptr), ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_663aae77909ce95fdbc532a547f60383) #22
          to label %.noexc43.i.i.i.i unwind label %bb48.thread121.loopexit.split-lp.i.i.i.i, !dbg !42080, !noalias !41930

.noexc43.i.i.i.i:                                 ; preds = %bb3.i.i.i.i.i
  unreachable

bb2.i.i.i.i.i:                                    ; preds = %bb9.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i.i.i.i), !dbg !42083, !noalias !42072
  %_365.not.i.i.i.i.i = icmp eq i64 %_23.i.i.i.i, 0, !dbg !42084
  br i1 %_365.not.i.i.i.i.i, label %bb10.thread.i.i.i.i, label %bb15.i.i.i.i.i.preheader, !dbg !42094

bb15.i.i.i.i.i.preheader:                         ; preds = %bb2.i.i.i.i.i
  %28 = icmp ne ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %28)
  %xtraiter = and i64 %_23.i.i.i.i, 3, !dbg !42094
  %29 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !42094
  br i1 %29, label %bb15.i.i.i.i.i.epil.preheader, label %bb15.i.i.i.i.i.preheader.new, !dbg !42094

bb15.i.i.i.i.i.preheader.new:                     ; preds = %bb15.i.i.i.i.i.preheader
  %unroll_iter = and i64 %_23.i.i.i.i, -4, !dbg !42094
  br label %bb15.i.i.i.i.i, !dbg !42094

bb10.thread.i.i.i.i:                              ; preds = %bb2.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %len.i.i.i.i.i), !dbg !42095, !noalias !42072
  br label %bb22.thread.sink.split.i.i.i.i, !dbg !42096

bb15.i.i.i.i.i:                                   ; preds = %bb15.i.i.i.i.i, %bb15.i.i.i.i.i.preheader.new
  %iter.sroa.0.07.i.i.i.i.i = phi i64 [ 0, %bb15.i.i.i.i.i.preheader.new ], [ %39, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i.1 = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %35, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i.2 = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %38, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i.3 = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %41, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %32, %bb15.i.i.i.i.i ]
  %niter = phi i64 [ 0, %bb15.i.i.i.i.i.preheader.new ], [ %niter.next.3, %bb15.i.i.i.i.i ]
  %_5.i.i.i34 = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i, %_31.sroa.7.sroa.8.i.i.i.i.sroa.0.0.copyload, !dbg !42100
  call void @llvm.assume(i1 %_5.i.i.i34), !dbg !42109, !noalias !41930
  %_4.i.i.i = getelementptr inbounds nuw i64, ptr %_115.sroa.0.0.copyload.i.i.i.i, i64 %iter.sroa.0.07.i.i.i.i.i, !dbg !42110
  %_0.i.i.i = load i64, ptr %_4.i.i.i, align 8, !dbg !42111, !noalias !42112, !noundef !37
  %_5.i.i3.i = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i, %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0.copyload, !dbg !42115
  call void @llvm.assume(i1 %_5.i.i3.i), !dbg !42120, !noalias !41930
  %_4.i.i4.i = getelementptr inbounds nuw i64, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload, i64 %iter.sroa.0.07.i.i.i.i.i, !dbg !42121
  %_0.i.i5.i = load i64, ptr %_4.i.i4.i, align 8, !dbg !42122, !noalias !42112, !noundef !37
  %30 = or disjoint i64 %iter.sroa.0.07.i.i.i.i.i, 1, !dbg !42123
  %31 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i, i64 %_0.i.i5.i), !dbg !42129
  %_7.0.i.i.i.i.i.i.i.i = extractvalue { i64, i1 } %31, 0, !dbg !42129
  %_7.1.i.i.i.i.i.i.i.i = extractvalue { i64, i1 } %31, 1, !dbg !42129
  %_8.i.i.i.i.i.i.i.i = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i, 0, !dbg !42140
  %32 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i, %_7.1.i.i.i.i.i.i.i.i, !dbg !42142
  %_40.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 %iter.sroa.0.07.i.i.i.i.i, !dbg !42145
  %_41.i.i.i.i.i = zext i1 %_8.i.i.i.i.i.i.i.i to i8, !dbg !42150
  store i8 %_41.i.i.i.i.i, ptr %_40.i.i.i.i.i, align 1, !dbg !42155, !alias.scope !42064, !noalias !42156
  %_5.i.i.i34.1 = icmp ult i64 %30, %_31.sroa.7.sroa.8.i.i.i.i.sroa.0.0.copyload, !dbg !42100
  call void @llvm.assume(i1 %_5.i.i.i34.1), !dbg !42109, !noalias !41930
  %_4.i.i.i.1 = getelementptr inbounds nuw i64, ptr %_115.sroa.0.0.copyload.i.i.i.i, i64 %30, !dbg !42110
  %_0.i.i.i.1 = load i64, ptr %_4.i.i.i.1, align 8, !dbg !42111, !noalias !42112, !noundef !37
  %_5.i.i3.i.1 = icmp ult i64 %30, %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0.copyload, !dbg !42115
  call void @llvm.assume(i1 %_5.i.i3.i.1), !dbg !42120, !noalias !41930
  %_4.i.i4.i.1 = getelementptr inbounds nuw i64, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload, i64 %30, !dbg !42121
  %_0.i.i5.i.1 = load i64, ptr %_4.i.i4.i.1, align 8, !dbg !42122, !noalias !42112, !noundef !37
  %33 = or disjoint i64 %iter.sroa.0.07.i.i.i.i.i, 2, !dbg !42123
  %34 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.1, i64 %_0.i.i5.i.1), !dbg !42129
  %_7.0.i.i.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %34, 0, !dbg !42129
  %_7.1.i.i.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %34, 1, !dbg !42129
  %_8.i.i.i.i.i.i.i.i.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.1, 0, !dbg !42140
  %35 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.1, %_7.1.i.i.i.i.i.i.i.i.1, !dbg !42142
  %_40.i.i.i.i.i.1 = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 %30, !dbg !42145
  %_41.i.i.i.i.i.1 = zext i1 %_8.i.i.i.i.i.i.i.i.1 to i8, !dbg !42150
  store i8 %_41.i.i.i.i.i.1, ptr %_40.i.i.i.i.i.1, align 1, !dbg !42155, !alias.scope !42064, !noalias !42156
  %_5.i.i.i34.2 = icmp ult i64 %33, %_31.sroa.7.sroa.8.i.i.i.i.sroa.0.0.copyload, !dbg !42100
  call void @llvm.assume(i1 %_5.i.i.i34.2), !dbg !42109, !noalias !41930
  %_4.i.i.i.2 = getelementptr inbounds nuw i64, ptr %_115.sroa.0.0.copyload.i.i.i.i, i64 %33, !dbg !42110
  %_0.i.i.i.2 = load i64, ptr %_4.i.i.i.2, align 8, !dbg !42111, !noalias !42112, !noundef !37
  %_5.i.i3.i.2 = icmp ult i64 %33, %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0.copyload, !dbg !42115
  call void @llvm.assume(i1 %_5.i.i3.i.2), !dbg !42120, !noalias !41930
  %_4.i.i4.i.2 = getelementptr inbounds nuw i64, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload, i64 %33, !dbg !42121
  %_0.i.i5.i.2 = load i64, ptr %_4.i.i4.i.2, align 8, !dbg !42122, !noalias !42112, !noundef !37
  %36 = or disjoint i64 %iter.sroa.0.07.i.i.i.i.i, 3, !dbg !42123
  %37 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.2, i64 %_0.i.i5.i.2), !dbg !42129
  %_7.0.i.i.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %37, 0, !dbg !42129
  %_7.1.i.i.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %37, 1, !dbg !42129
  %_8.i.i.i.i.i.i.i.i.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.2, 0, !dbg !42140
  %38 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.2, %_7.1.i.i.i.i.i.i.i.i.2, !dbg !42142
  %_40.i.i.i.i.i.2 = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 %33, !dbg !42145
  %_41.i.i.i.i.i.2 = zext i1 %_8.i.i.i.i.i.i.i.i.2 to i8, !dbg !42150
  store i8 %_41.i.i.i.i.i.2, ptr %_40.i.i.i.i.i.2, align 1, !dbg !42155, !alias.scope !42064, !noalias !42156
  %_5.i.i.i34.3 = icmp ult i64 %36, %_31.sroa.7.sroa.8.i.i.i.i.sroa.0.0.copyload, !dbg !42100
  call void @llvm.assume(i1 %_5.i.i.i34.3), !dbg !42109, !noalias !41930
  %_4.i.i.i.3 = getelementptr inbounds nuw i64, ptr %_115.sroa.0.0.copyload.i.i.i.i, i64 %36, !dbg !42110
  %_0.i.i.i.3 = load i64, ptr %_4.i.i.i.3, align 8, !dbg !42111, !noalias !42112, !noundef !37
  %_5.i.i3.i.3 = icmp ult i64 %36, %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0.copyload, !dbg !42115
  call void @llvm.assume(i1 %_5.i.i3.i.3), !dbg !42120, !noalias !41930
  %_4.i.i4.i.3 = getelementptr inbounds nuw i64, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload, i64 %36, !dbg !42121
  %_0.i.i5.i.3 = load i64, ptr %_4.i.i4.i.3, align 8, !dbg !42122, !noalias !42112, !noundef !37
  %39 = add nuw i64 %iter.sroa.0.07.i.i.i.i.i, 4, !dbg !42123
  %40 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.3, i64 %_0.i.i5.i.3), !dbg !42129
  %_7.0.i.i.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %40, 0, !dbg !42129
  %_7.1.i.i.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %40, 1, !dbg !42129
  %_8.i.i.i.i.i.i.i.i.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.3, 0, !dbg !42140
  %41 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.3, %_7.1.i.i.i.i.i.i.i.i.3, !dbg !42142
  %_40.i.i.i.i.i.3 = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 %36, !dbg !42145
  %_41.i.i.i.i.i.3 = zext i1 %_8.i.i.i.i.i.i.i.i.3 to i8, !dbg !42150
  store i8 %_41.i.i.i.i.i.3, ptr %_40.i.i.i.i.i.3, align 1, !dbg !42155, !alias.scope !42064, !noalias !42156
  %niter.next.3 = add i64 %niter, 4, !dbg !42094
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter, !dbg !42094
  br i1 %niter.ncmp.3, label %bb10.i.i.i.i.unr-lcssa, label %bb15.i.i.i.i.i, !dbg !42094

bb8.i.i.i.i:                                      ; preds = %bb68.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_44.i.i.i.i), !dbg !42157, !noalias !41909
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(none) dereferenceable(80) %_44.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i.i.i.i, i64 noundef %_34.i.i.i.i)
          to label %bb11.i.i.i.i unwind label %bb48.thread121.loopexit.split-lp.i.i.i.i, !dbg !42157, !noalias !41930

bb10.i.i.i.i.unr-lcssa:                           ; preds = %bb15.i.i.i.i.i
  %bin.rdx = or i1 %35, %32, !dbg !42094
  %bin.rdx150 = or i1 %38, %bin.rdx, !dbg !42094
  %bin.rdx151 = or i1 %41, %bin.rdx150, !dbg !42094
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !42094
  br i1 %lcmp.mod.not, label %bb10.i.i.i.i, label %bb15.i.i.i.i.i.epil.preheader, !dbg !42094

bb15.i.i.i.i.i.epil.preheader:                    ; preds = %bb10.i.i.i.i.unr-lcssa, %bb15.i.i.i.i.i.preheader
  %iter.sroa.0.07.i.i.i.i.i.epil.init = phi i64 [ 0, %bb15.i.i.i.i.i.preheader ], [ %39, %bb10.i.i.i.i.unr-lcssa ]
  %failed.sroa.0.0.off06.i.i.i.i.i.epil.init = phi i1 [ false, %bb15.i.i.i.i.i.preheader ], [ %bin.rdx151, %bb10.i.i.i.i.unr-lcssa ]
  %lcmp.mod149 = icmp ne i64 %xtraiter, 0, !dbg !42094
  call void @llvm.assume(i1 %lcmp.mod149), !dbg !42094
  br label %bb15.i.i.i.i.i.epil, !dbg !42094

bb15.i.i.i.i.i.epil:                              ; preds = %bb15.i.i.i.i.i.epil, %bb15.i.i.i.i.i.epil.preheader
  %iter.sroa.0.07.i.i.i.i.i.epil = phi i64 [ %42, %bb15.i.i.i.i.i.epil ], [ %iter.sroa.0.07.i.i.i.i.i.epil.init, %bb15.i.i.i.i.i.epil.preheader ]
  %failed.sroa.0.0.off06.i.i.i.i.i.epil = phi i1 [ %44, %bb15.i.i.i.i.i.epil ], [ %failed.sroa.0.0.off06.i.i.i.i.i.epil.init, %bb15.i.i.i.i.i.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %bb15.i.i.i.i.i.epil ], [ 0, %bb15.i.i.i.i.i.epil.preheader ]
  %_5.i.i.i34.epil = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i.epil, %_31.sroa.7.sroa.8.i.i.i.i.sroa.0.0.copyload, !dbg !42100
  call void @llvm.assume(i1 %_5.i.i.i34.epil), !dbg !42109, !noalias !41930
  %_4.i.i.i.epil = getelementptr inbounds nuw i64, ptr %_115.sroa.0.0.copyload.i.i.i.i, i64 %iter.sroa.0.07.i.i.i.i.i.epil, !dbg !42110
  %_0.i.i.i.epil = load i64, ptr %_4.i.i.i.epil, align 8, !dbg !42111, !noalias !42112, !noundef !37
  %_5.i.i3.i.epil = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i.epil, %_31.sroa.7.sroa.8.i.i.i.i.sroa.6.0.copyload, !dbg !42115
  call void @llvm.assume(i1 %_5.i.i3.i.epil), !dbg !42120, !noalias !41930
  %_4.i.i4.i.epil = getelementptr inbounds nuw i64, ptr %_31.sroa.7.sroa.8.i.i.i.i.sroa.5.0.copyload, i64 %iter.sroa.0.07.i.i.i.i.i.epil, !dbg !42121
  %_0.i.i5.i.epil = load i64, ptr %_4.i.i4.i.epil, align 8, !dbg !42122, !noalias !42112, !noundef !37
  %42 = add nuw i64 %iter.sroa.0.07.i.i.i.i.i.epil, 1, !dbg !42123
  %43 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.epil, i64 %_0.i.i5.i.epil), !dbg !42129
  %_7.0.i.i.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %43, 0, !dbg !42129
  %_7.1.i.i.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %43, 1, !dbg !42129
  %_8.i.i.i.i.i.i.i.i.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.epil, 0, !dbg !42140
  %44 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.epil, %_7.1.i.i.i.i.i.i.i.i.epil, !dbg !42142
  %_40.i.i.i.i.i.epil = getelementptr inbounds nuw i8, ptr %_8.i.i, i64 %iter.sroa.0.07.i.i.i.i.i.epil, !dbg !42145
  %_41.i.i.i.i.i.epil = zext i1 %_8.i.i.i.i.i.i.i.i.epil to i8, !dbg !42150
  store i8 %_41.i.i.i.i.i.epil, ptr %_40.i.i.i.i.i.epil, align 1, !dbg !42155, !alias.scope !42064, !noalias !42156
  %epil.iter.next = add i64 %epil.iter, 1, !dbg !42094
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter, !dbg !42094
  br i1 %epil.iter.cmp.not, label %bb10.i.i.i.i, label %bb15.i.i.i.i.i.epil, !dbg !42094, !llvm.loop !42158

bb10.i.i.i.i:                                     ; preds = %bb15.i.i.i.i.i.epil, %bb10.i.i.i.i.unr-lcssa
  %.lcssa147 = phi i1 [ %bin.rdx151, %bb10.i.i.i.i.unr-lcssa ], [ %44, %bb15.i.i.i.i.i.epil ], !dbg !42142
  call void @llvm.lifetime.end.p0(ptr nonnull %len.i.i.i.i.i), !dbg !42095, !noalias !42072
  call void @llvm.lifetime.start.p0(ptr nonnull %_68.i.i.i.i), !dbg !42159, !noalias !41909
  br i1 %.lcssa147, label %bb1.i47.i.i.i.i, label %bb24.i.i.i.i, !dbg !42096, !prof !32122

bb21.i.i.i.i.loopexit.unr-lcssa:                  ; preds = %bb14.i.i.i.i.us.us
  %bin.rdx189 = or i1 %62, %60, !dbg !42160
  %bin.rdx190 = or i1 %64, %bin.rdx189, !dbg !42160
  %bin.rdx191 = or i1 %66, %bin.rdx190, !dbg !42160
  %lcmp.mod184.not = icmp eq i64 %xtraiter182, 0, !dbg !42160
  br i1 %lcmp.mod184.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.us.us.epil.preheader, !dbg !42160

bb14.i.i.i.i.us.us.epil.preheader:                ; preds = %bb21.i.i.i.i.loopexit.unr-lcssa, %bb14.i.i.i.i.us.us.preheader
  %failure10.sroa.0.0.off0135.i.i.i.i.us.us.epil.init = phi i1 [ false, %bb14.i.i.i.i.us.us.preheader ], [ %bin.rdx191, %bb21.i.i.i.i.loopexit.unr-lcssa ]
  %iter.sroa.0.0134.i.i.i.i.us.us.epil.init = phi ptr [ %_8.i.i, %bb14.i.i.i.i.us.us.preheader ], [ %_17.i.i.i.i.i.i.us.us.3, %bb21.i.i.i.i.loopexit.unr-lcssa ]
  %iter.sroa.7.0133.i.i.i.i.us.us.epil.init = phi i64 [ 0, %bb14.i.i.i.i.us.us.preheader ], [ %_9.0.i.i.i.i.i.us.us.3, %bb21.i.i.i.i.loopexit.unr-lcssa ]
  %lcmp.mod186 = icmp ne i64 %xtraiter182, 0, !dbg !42160
  call void @llvm.assume(i1 %lcmp.mod186), !dbg !42160
  br label %bb14.i.i.i.i.us.us.epil, !dbg !42160

bb14.i.i.i.i.us.us.epil:                          ; preds = %bb14.i.i.i.i.us.us.epil, %bb14.i.i.i.i.us.us.epil.preheader
  %failure10.sroa.0.0.off0135.i.i.i.i.us.us.epil = phi i1 [ %46, %bb14.i.i.i.i.us.us.epil ], [ %failure10.sroa.0.0.off0135.i.i.i.i.us.us.epil.init, %bb14.i.i.i.i.us.us.epil.preheader ]
  %iter.sroa.0.0134.i.i.i.i.us.us.epil = phi ptr [ %_17.i.i.i.i.i.i.us.us.epil, %bb14.i.i.i.i.us.us.epil ], [ %iter.sroa.0.0134.i.i.i.i.us.us.epil.init, %bb14.i.i.i.i.us.us.epil.preheader ]
  %iter.sroa.7.0133.i.i.i.i.us.us.epil = phi i64 [ %_9.0.i.i.i.i.i.us.us.epil, %bb14.i.i.i.i.us.us.epil ], [ %iter.sroa.7.0133.i.i.i.i.us.us.epil.init, %bb14.i.i.i.i.us.us.epil.preheader ]
  %epil.iter183 = phi i64 [ %epil.iter183.next, %bb14.i.i.i.i.us.us.epil ], [ 0, %bb14.i.i.i.i.us.us.epil.preheader ]
  %_5.i3.i.i.us.us.epil = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us.us.epil, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.epil), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.us.epil = getelementptr inbounds nuw i64, ptr %56, i64 %iter.sroa.7.0133.i.i.i.i.us.us.epil, !dbg !42177
  %_0.sroa.0.0.i.i.us.us.epil = load i64, ptr %_4.i.i.i40.us.us.epil, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us.us.epil = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us.us.epil, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.epil), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us.us.epil = getelementptr inbounds nuw i64, ptr %57, i64 %iter.sroa.7.0133.i.i.i.i.us.us.epil, !dbg !42191
  %_0.sroa.0.0.i7.i.us.us.epil = load i64, ptr %_4.i.i12.i.us.us.epil, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.us.epil = add nuw i64 %iter.sroa.7.0133.i.i.i.i.us.us.epil, 1, !dbg !42197
  %_17.i.i.i.i.i.i.us.us.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us.us.epil, i64 1, !dbg !42198
  %45 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.epil, i64 %_0.sroa.0.0.i7.i.us.us.epil), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.us.epil = extractvalue { i64, i1 } %45, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.us.epil = extractvalue { i64, i1 } %45, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.us.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.epil, 0, !dbg !42204
  %_135.i.i.i.i.us.us.epil = zext i1 %_8.i.i.i.i.i.i.us.us.epil to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.us.epil, ptr %iter.sroa.0.0134.i.i.i.i.us.us.epil, align 1, !dbg !42211, !noalias !41930
  %46 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.us.epil, %_7.1.i.i.i.i.i.i.us.us.epil, !dbg !42212
  %epil.iter183.next = add i64 %epil.iter183, 1, !dbg !42160
  %epil.iter183.cmp.not = icmp eq i64 %epil.iter183.next, %xtraiter182, !dbg !42160
  br i1 %epil.iter183.cmp.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.us.us.epil, !dbg !42160, !llvm.loop !42214

bb21.i.i.i.i.loopexit141.unr-lcssa:               ; preds = %bb14.i.i.i.i.us
  %bin.rdx179 = or i1 %71, %69, !dbg !42160
  %bin.rdx180 = or i1 %73, %bin.rdx179, !dbg !42160
  %bin.rdx181 = or i1 %75, %bin.rdx180, !dbg !42160
  %lcmp.mod174.not = icmp eq i64 %xtraiter172, 0, !dbg !42160
  br i1 %lcmp.mod174.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.us.epil.preheader, !dbg !42160

bb14.i.i.i.i.us.epil.preheader:                   ; preds = %bb21.i.i.i.i.loopexit141.unr-lcssa, %bb14.i.i.i.i.preheader.split.us.split
  %failure10.sroa.0.0.off0135.i.i.i.i.us.epil.init = phi i1 [ false, %bb14.i.i.i.i.preheader.split.us.split ], [ %bin.rdx181, %bb21.i.i.i.i.loopexit141.unr-lcssa ]
  %iter.sroa.0.0134.i.i.i.i.us.epil.init = phi ptr [ %_8.i.i, %bb14.i.i.i.i.preheader.split.us.split ], [ %_17.i.i.i.i.i.i.us.3, %bb21.i.i.i.i.loopexit141.unr-lcssa ]
  %iter.sroa.7.0133.i.i.i.i.us.epil.init = phi i64 [ 0, %bb14.i.i.i.i.preheader.split.us.split ], [ %_9.0.i.i.i.i.i.us.3, %bb21.i.i.i.i.loopexit141.unr-lcssa ]
  %lcmp.mod176 = icmp ne i64 %xtraiter172, 0, !dbg !42160
  call void @llvm.assume(i1 %lcmp.mod176), !dbg !42160
  br label %bb14.i.i.i.i.us.epil, !dbg !42160

bb14.i.i.i.i.us.epil:                             ; preds = %bb14.i.i.i.i.us.epil, %bb14.i.i.i.i.us.epil.preheader
  %failure10.sroa.0.0.off0135.i.i.i.i.us.epil = phi i1 [ %48, %bb14.i.i.i.i.us.epil ], [ %failure10.sroa.0.0.off0135.i.i.i.i.us.epil.init, %bb14.i.i.i.i.us.epil.preheader ]
  %iter.sroa.0.0134.i.i.i.i.us.epil = phi ptr [ %_17.i.i.i.i.i.i.us.epil, %bb14.i.i.i.i.us.epil ], [ %iter.sroa.0.0134.i.i.i.i.us.epil.init, %bb14.i.i.i.i.us.epil.preheader ]
  %iter.sroa.7.0133.i.i.i.i.us.epil = phi i64 [ %_9.0.i.i.i.i.i.us.epil, %bb14.i.i.i.i.us.epil ], [ %iter.sroa.7.0133.i.i.i.i.us.epil.init, %bb14.i.i.i.i.us.epil.preheader ]
  %epil.iter173 = phi i64 [ %epil.iter173.next, %bb14.i.i.i.i.us.epil ], [ 0, %bb14.i.i.i.i.us.epil.preheader ]
  %_5.i3.i.i.us.epil = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us.epil, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.epil), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.epil = getelementptr inbounds nuw i64, ptr %56, i64 %iter.sroa.7.0133.i.i.i.i.us.epil, !dbg !42177
  %_0.sroa.0.0.i.i.us.epil = load i64, ptr %_4.i.i.i40.us.epil, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.us.epil = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.epil = add nuw i64 %iter.sroa.7.0133.i.i.i.i.us.epil, 1, !dbg !42197
  %_17.i.i.i.i.i.i.us.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us.epil, i64 1, !dbg !42198
  %47 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.epil, i64 %_0.sroa.0.0.i7.i.us.epil), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.epil = extractvalue { i64, i1 } %47, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.epil = extractvalue { i64, i1 } %47, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.epil, 0, !dbg !42204
  %_135.i.i.i.i.us.epil = zext i1 %_8.i.i.i.i.i.i.us.epil to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.epil, ptr %iter.sroa.0.0134.i.i.i.i.us.epil, align 1, !dbg !42211, !noalias !41930
  %48 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.epil, %_7.1.i.i.i.i.i.i.us.epil, !dbg !42212
  %epil.iter173.next = add i64 %epil.iter173, 1, !dbg !42160
  %epil.iter173.cmp.not = icmp eq i64 %epil.iter173.next, %xtraiter172, !dbg !42160
  br i1 %epil.iter173.cmp.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.us.epil, !dbg !42160, !llvm.loop !42215

bb21.i.i.i.i.loopexit143.unr-lcssa:               ; preds = %bb14.i.i.i.i.us70
  %bin.rdx169 = or i1 %80, %78, !dbg !42160
  %bin.rdx170 = or i1 %82, %bin.rdx169, !dbg !42160
  %bin.rdx171 = or i1 %84, %bin.rdx170, !dbg !42160
  %lcmp.mod164.not = icmp eq i64 %xtraiter162, 0, !dbg !42160
  br i1 %lcmp.mod164.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.us70.epil.preheader, !dbg !42160

bb14.i.i.i.i.us70.epil.preheader:                 ; preds = %bb21.i.i.i.i.loopexit143.unr-lcssa, %bb14.i.i.i.i.us70.preheader
  %failure10.sroa.0.0.off0135.i.i.i.i.us71.epil.init = phi i1 [ false, %bb14.i.i.i.i.us70.preheader ], [ %bin.rdx171, %bb21.i.i.i.i.loopexit143.unr-lcssa ]
  %iter.sroa.0.0134.i.i.i.i.us72.epil.init = phi ptr [ %_8.i.i, %bb14.i.i.i.i.us70.preheader ], [ %_17.i.i.i.i.i.i.us82.3, %bb21.i.i.i.i.loopexit143.unr-lcssa ]
  %iter.sroa.7.0133.i.i.i.i.us73.epil.init = phi i64 [ 0, %bb14.i.i.i.i.us70.preheader ], [ %_9.0.i.i.i.i.i.us81.3, %bb21.i.i.i.i.loopexit143.unr-lcssa ]
  %lcmp.mod166 = icmp ne i64 %xtraiter162, 0, !dbg !42160
  call void @llvm.assume(i1 %lcmp.mod166), !dbg !42160
  br label %bb14.i.i.i.i.us70.epil, !dbg !42160

bb14.i.i.i.i.us70.epil:                           ; preds = %bb14.i.i.i.i.us70.epil, %bb14.i.i.i.i.us70.epil.preheader
  %failure10.sroa.0.0.off0135.i.i.i.i.us71.epil = phi i1 [ %50, %bb14.i.i.i.i.us70.epil ], [ %failure10.sroa.0.0.off0135.i.i.i.i.us71.epil.init, %bb14.i.i.i.i.us70.epil.preheader ]
  %iter.sroa.0.0134.i.i.i.i.us72.epil = phi ptr [ %_17.i.i.i.i.i.i.us82.epil, %bb14.i.i.i.i.us70.epil ], [ %iter.sroa.0.0134.i.i.i.i.us72.epil.init, %bb14.i.i.i.i.us70.epil.preheader ]
  %iter.sroa.7.0133.i.i.i.i.us73.epil = phi i64 [ %_9.0.i.i.i.i.i.us81.epil, %bb14.i.i.i.i.us70.epil ], [ %iter.sroa.7.0133.i.i.i.i.us73.epil.init, %bb14.i.i.i.i.us70.epil.preheader ]
  %epil.iter163 = phi i64 [ %epil.iter163.next, %bb14.i.i.i.i.us70.epil ], [ 0, %bb14.i.i.i.i.us70.epil.preheader ]
  %_0.sroa.0.0.i.i.us74.epil = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us76.epil = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us73.epil, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us76.epil), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us77.epil = getelementptr inbounds nuw i64, ptr %57, i64 %iter.sroa.7.0133.i.i.i.i.us73.epil, !dbg !42191
  %_0.sroa.0.0.i7.i.us80.epil = load i64, ptr %_4.i.i12.i.us77.epil, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us81.epil = add nuw i64 %iter.sroa.7.0133.i.i.i.i.us73.epil, 1, !dbg !42197
  %_17.i.i.i.i.i.i.us82.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us72.epil, i64 1, !dbg !42198
  %49 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us74.epil, i64 %_0.sroa.0.0.i7.i.us80.epil), !dbg !42200
  %_7.0.i.i.i.i.i.i.us83.epil = extractvalue { i64, i1 } %49, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us84.epil = extractvalue { i64, i1 } %49, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us85.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.us83.epil, 0, !dbg !42204
  %_135.i.i.i.i.us86.epil = zext i1 %_8.i.i.i.i.i.i.us85.epil to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us86.epil, ptr %iter.sroa.0.0134.i.i.i.i.us72.epil, align 1, !dbg !42211, !noalias !41930
  %50 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us71.epil, %_7.1.i.i.i.i.i.i.us84.epil, !dbg !42212
  %epil.iter163.next = add i64 %epil.iter163, 1, !dbg !42160
  %epil.iter163.cmp.not = icmp eq i64 %epil.iter163.next, %xtraiter162, !dbg !42160
  br i1 %epil.iter163.cmp.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.us70.epil, !dbg !42160, !llvm.loop !42216

bb21.i.i.i.i.loopexit145.unr-lcssa:               ; preds = %bb14.i.i.i.i
  %bin.rdx159 = or i1 %89, %87, !dbg !42160
  %bin.rdx160 = or i1 %91, %bin.rdx159, !dbg !42160
  %bin.rdx161 = or i1 %93, %bin.rdx160, !dbg !42160
  %lcmp.mod154.not = icmp eq i64 %xtraiter152, 0, !dbg !42160
  br i1 %lcmp.mod154.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.epil.preheader, !dbg !42160

bb14.i.i.i.i.epil.preheader:                      ; preds = %bb21.i.i.i.i.loopexit145.unr-lcssa, %bb14.i.i.i.i.preheader.split.split
  %failure10.sroa.0.0.off0135.i.i.i.i.epil.init = phi i1 [ false, %bb14.i.i.i.i.preheader.split.split ], [ %bin.rdx161, %bb21.i.i.i.i.loopexit145.unr-lcssa ]
  %iter.sroa.0.0134.i.i.i.i.epil.init = phi ptr [ %_8.i.i, %bb14.i.i.i.i.preheader.split.split ], [ %_17.i.i.i.i.i.i.3, %bb21.i.i.i.i.loopexit145.unr-lcssa ]
  %lcmp.mod156 = icmp ne i64 %xtraiter152, 0, !dbg !42160
  call void @llvm.assume(i1 %lcmp.mod156), !dbg !42160
  br label %bb14.i.i.i.i.epil, !dbg !42160

bb14.i.i.i.i.epil:                                ; preds = %bb14.i.i.i.i.epil, %bb14.i.i.i.i.epil.preheader
  %failure10.sroa.0.0.off0135.i.i.i.i.epil = phi i1 [ %52, %bb14.i.i.i.i.epil ], [ %failure10.sroa.0.0.off0135.i.i.i.i.epil.init, %bb14.i.i.i.i.epil.preheader ]
  %iter.sroa.0.0134.i.i.i.i.epil = phi ptr [ %_17.i.i.i.i.i.i.epil, %bb14.i.i.i.i.epil ], [ %iter.sroa.0.0134.i.i.i.i.epil.init, %bb14.i.i.i.i.epil.preheader ]
  %epil.iter153 = phi i64 [ %epil.iter153.next, %bb14.i.i.i.i.epil ], [ 0, %bb14.i.i.i.i.epil.preheader ]
  %_0.sroa.0.0.i.i.epil = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.epil = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_17.i.i.i.i.i.i.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.epil, i64 1, !dbg !42198
  %51 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.epil, i64 %_0.sroa.0.0.i7.i.epil), !dbg !42200
  %_7.0.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %51, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %51, 1, !dbg !42200
  %_8.i.i.i.i.i.i.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.epil, 0, !dbg !42204
  %_135.i.i.i.i.epil = zext i1 %_8.i.i.i.i.i.i.epil to i8, !dbg !42205
  store i8 %_135.i.i.i.i.epil, ptr %iter.sroa.0.0134.i.i.i.i.epil, align 1, !dbg !42211, !noalias !41930
  %52 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.epil, %_7.1.i.i.i.i.i.i.epil, !dbg !42212
  %epil.iter153.next = add i64 %epil.iter153, 1, !dbg !42160
  %epil.iter153.cmp.not = icmp eq i64 %epil.iter153.next, %xtraiter152, !dbg !42160
  br i1 %epil.iter153.cmp.not, label %bb21.i.i.i.i, label %bb14.i.i.i.i.epil, !dbg !42160, !llvm.loop !42217

bb21.i.i.i.i:                                     ; preds = %bb21.i.i.i.i.loopexit145.unr-lcssa, %bb14.i.i.i.i.epil, %bb21.i.i.i.i.loopexit143.unr-lcssa, %bb14.i.i.i.i.us70.epil, %bb21.i.i.i.i.loopexit141.unr-lcssa, %bb14.i.i.i.i.us.epil, %bb21.i.i.i.i.loopexit.unr-lcssa, %bb14.i.i.i.i.us.us.epil
  %.us-phi = phi i1 [ %48, %bb14.i.i.i.i.us.epil ], [ %50, %bb14.i.i.i.i.us70.epil ], [ %46, %bb14.i.i.i.i.us.us.epil ], [ %bin.rdx191, %bb21.i.i.i.i.loopexit.unr-lcssa ], [ %bin.rdx181, %bb21.i.i.i.i.loopexit141.unr-lcssa ], [ %bin.rdx171, %bb21.i.i.i.i.loopexit143.unr-lcssa ], [ %bin.rdx161, %bb21.i.i.i.i.loopexit145.unr-lcssa ], [ %52, %bb14.i.i.i.i.epil ], !dbg !42159
  call void @llvm.lifetime.start.p0(ptr nonnull %_68.i.i.i.i), !dbg !42159, !noalias !41909
  br i1 %.us-phi, label %bb1.i47.i.i.i.i, label %bb24.i.i.i.i, !dbg !42096, !prof !11822

bb22.thread.sink.split.i.i.i.i:                   ; preds = %bb12.i.i.i.i, %bb10.thread.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_68.i.i.i.i), !dbg !42159, !noalias !41909
  br label %bb24.i.i.i.i, !dbg !42218

bb1.i47.i.i.i.i:                                  ; preds = %bb21.i.i.i.i, %bb10.i.i.i.i
; invoke rofl_examples::functions::row_error::<vortex_array::scalar_fn::unstable::rofl::VortexHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(address) dereferenceable(80) %_68.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb22.i.i.i.i unwind label %bb48.thread121.loopexit.split-lp.i.i.i.i, !dbg !42219, !noalias !41930

bb11.i.i.i.i:                                     ; preds = %bb8.i.i.i.i
  %53 = load i64, ptr %_44.i.i.i.i, align 8, !dbg !42220, !range !1887, !noalias !41909, !noundef !37
  %.not32.i.i.i.i = icmp eq i64 %53, -1, !dbg !42220
  %54 = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 8, !dbg !42223
  %_43.sroa.6.i.i.i.i.sroa.0.0.copyload = load ptr, ptr %54, align 8, !dbg !42223, !noalias !41909
  %_43.sroa.6.i.i.i.i.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 16, !dbg !42223
  %_43.sroa.6.i.i.i.i.sroa.6.0.copyload = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.6.0..sroa_idx, align 8, !dbg !42223, !noalias !41909
  %_43.sroa.6.i.i.i.i.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 24, !dbg !42223
  %_43.sroa.6.i.i.i.i.sroa.7.0.copyload = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.7.0..sroa_idx, align 8, !dbg !42223, !noalias !41909
  %_43.sroa.6.i.i.i.i.sroa.8.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 32, !dbg !42223
  %_43.sroa.6.i.i.i.i.sroa.8.0.copyload = load ptr, ptr %_43.sroa.6.i.i.i.i.sroa.8.0..sroa_idx, align 8, !dbg !42223, !noalias !41909
  %_43.sroa.6.i.i.i.i.sroa.9.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 40, !dbg !42223
  %_43.sroa.6.i.i.i.i.sroa.9.0.copyload = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.9.0..sroa_idx, align 8, !dbg !42223, !noalias !41909
  %_43.sroa.6.i.i.i.i.sroa.10.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 48, !dbg !42223
  %_43.sroa.6.i.i.i.i.sroa.10.0.copyload = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.10.0..sroa_idx, align 8, !dbg !42223, !noalias !41909
  br i1 %.not32.i.i.i.i, label %bb12.i.i.i.i, label %bb69.i.i.i.i, !dbg !42224

bb69.i.i.i.i:                                     ; preds = %bb11.i.i.i.i
  %_43.sroa.6.i.i.i.i.sroa.11.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 56, !dbg !42223
  %_43.sroa.6.i.i.i.i.sroa.11.0.copyload = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.11.0..sroa_idx, align 8, !dbg !42223, !noalias !41909
  %_123.sroa.5.0._44.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 64, !dbg !42225
  %_126.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 72, !dbg !42226
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %_126.sroa.5.0..sroa_idx.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(16) %_123.sroa.5.0._44.sroa_idx.i.i.i.i, i64 16, i1 false), !dbg !42225, !noalias !41965
  call void @llvm.lifetime.end.p0(ptr nonnull %_44.i.i.i.i), !dbg !42232, !noalias !41909
  %_126.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42226
  store ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, ptr %_126.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !42232, !noalias !41965
  %_43.sroa.6.i.i.i.i.sroa.6.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !42232
  store i64 %_43.sroa.6.i.i.i.i.sroa.6.0.copyload, ptr %_43.sroa.6.i.i.i.i.sroa.6.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42232, !noalias !41965
  %_43.sroa.6.i.i.i.i.sroa.7.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !42232
  store i64 %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, ptr %_43.sroa.6.i.i.i.i.sroa.7.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42232, !noalias !41965
  %_43.sroa.6.i.i.i.i.sroa.8.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !42232
  store ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, ptr %_43.sroa.6.i.i.i.i.sroa.8.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42232, !noalias !41965
  %_43.sroa.6.i.i.i.i.sroa.9.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 48, !dbg !42232
  store i64 %_43.sroa.6.i.i.i.i.sroa.9.0.copyload, ptr %_43.sroa.6.i.i.i.i.sroa.9.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42232, !noalias !41965
  %_43.sroa.6.i.i.i.i.sroa.10.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 56, !dbg !42232
  store i64 %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, ptr %_43.sroa.6.i.i.i.i.sroa.10.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42232, !noalias !41965
  %_43.sroa.6.i.i.i.i.sroa.11.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 64, !dbg !42232
  store i64 %_43.sroa.6.i.i.i.i.sroa.11.0.copyload, ptr %_43.sroa.6.i.i.i.i.sroa.11.0._126.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !42232, !noalias !41965
  %55 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42226
  store i64 %53, ptr %55, align 8, !dbg !42226, !alias.scope !41992, !noalias !41965
  br label %bb30.i.i.i.i, !dbg !42061

bb12.i.i.i.i:                                     ; preds = %bb11.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_44.i.i.i.i), !dbg !42232, !noalias !41909
  %_7.i.i132.i.i.i.i = icmp samesign eq i64 %_23.i.i.i.i, 0, !dbg !42233
  br i1 %_7.i.i132.i.i.i.i, label %bb22.thread.sink.split.i.i.i.i, label %bb14.i.i.i.i.preheader, !dbg !42160

bb14.i.i.i.i.preheader:                           ; preds = %bb12.i.i.i.i
  %.not.i.i35 = icmp eq ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, null
  %.not.i1.i = icmp eq ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, null
  %_5.i.i.i37 = icmp ne i64 %_43.sroa.6.i.i.i.i.sroa.6.0.copyload, 0
  %56 = inttoptr i64 %_43.sroa.6.i.i.i.i.sroa.6.0.copyload to ptr
  %_5.i.i5.i = icmp ne i64 %_43.sroa.6.i.i.i.i.sroa.9.0.copyload, 0
  %57 = inttoptr i64 %_43.sroa.6.i.i.i.i.sroa.9.0.copyload to ptr
  br i1 %.not.i.i35, label %bb14.i.i.i.i.preheader.split.us, label %bb14.i.i.i.i.preheader.split

bb14.i.i.i.i.preheader.split.us:                  ; preds = %bb14.i.i.i.i.preheader
  br i1 %.not.i1.i, label %bb14.i.i.i.i.us.us.preheader, label %bb14.i.i.i.i.preheader.split.us.split

bb14.i.i.i.i.us.us.preheader:                     ; preds = %bb14.i.i.i.i.preheader.split.us
  %xtraiter182 = and i64 %_23.i.i.i.i, 3, !dbg !42160
  %58 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !42160
  br i1 %58, label %bb14.i.i.i.i.us.us.epil.preheader, label %bb14.i.i.i.i.us.us.preheader.new, !dbg !42160

bb14.i.i.i.i.us.us.preheader.new:                 ; preds = %bb14.i.i.i.i.us.us.preheader
  %unroll_iter187 = and i64 %_23.i.i.i.i, -4, !dbg !42160
  br label %bb14.i.i.i.i.us.us, !dbg !42160

bb14.i.i.i.i.us.us:                               ; preds = %bb14.i.i.i.i.us.us, %bb14.i.i.i.i.us.us.preheader.new
  %failure10.sroa.0.0.off0135.i.i.i.i.us.us.1 = phi i1 [ %62, %bb14.i.i.i.i.us.us ], [ false, %bb14.i.i.i.i.us.us.preheader.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us.us.2 = phi i1 [ %64, %bb14.i.i.i.i.us.us ], [ false, %bb14.i.i.i.i.us.us.preheader.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us.us.3 = phi i1 [ %66, %bb14.i.i.i.i.us.us ], [ false, %bb14.i.i.i.i.us.us.preheader.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us.us = phi i1 [ %60, %bb14.i.i.i.i.us.us ], [ false, %bb14.i.i.i.i.us.us.preheader.new ]
  %iter.sroa.0.0134.i.i.i.i.us.us = phi ptr [ %_17.i.i.i.i.i.i.us.us.3, %bb14.i.i.i.i.us.us ], [ %_8.i.i, %bb14.i.i.i.i.us.us.preheader.new ]
  %iter.sroa.7.0133.i.i.i.i.us.us = phi i64 [ %_9.0.i.i.i.i.i.us.us.3, %bb14.i.i.i.i.us.us ], [ 0, %bb14.i.i.i.i.us.us.preheader.new ]
  %niter188 = phi i64 [ %niter188.next.3, %bb14.i.i.i.i.us.us ], [ 0, %bb14.i.i.i.i.us.us.preheader.new ]
  %_5.i3.i.i.us.us = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us.us, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.us), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.us = getelementptr inbounds nuw i64, ptr %56, i64 %iter.sroa.7.0133.i.i.i.i.us.us, !dbg !42177
  %_0.sroa.0.0.i.i.us.us = load i64, ptr %_4.i.i.i40.us.us, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us.us = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us.us, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us.us = getelementptr inbounds nuw i64, ptr %57, i64 %iter.sroa.7.0133.i.i.i.i.us.us, !dbg !42191
  %_0.sroa.0.0.i7.i.us.us = load i64, ptr %_4.i.i12.i.us.us, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.us = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us.us, 1, !dbg !42197
  %_17.i.i.i.i.i.i.us.us = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us.us, i64 1, !dbg !42198
  %59 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us, i64 %_0.sroa.0.0.i7.i.us.us), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.us = extractvalue { i64, i1 } %59, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.us = extractvalue { i64, i1 } %59, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.us = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us, 0, !dbg !42204
  %_135.i.i.i.i.us.us = zext i1 %_8.i.i.i.i.i.i.us.us to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.us, ptr %iter.sroa.0.0134.i.i.i.i.us.us, align 1, !dbg !42211, !noalias !41930
  %60 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.us, %_7.1.i.i.i.i.i.i.us.us, !dbg !42212
  %_5.i3.i.i.us.us.1 = icmp ult i64 %_9.0.i.i.i.i.i.us.us, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.1), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.us.1 = getelementptr inbounds nuw i64, ptr %56, i64 %_9.0.i.i.i.i.i.us.us, !dbg !42177
  %_0.sroa.0.0.i.i.us.us.1 = load i64, ptr %_4.i.i.i40.us.us.1, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us.us.1 = icmp ult i64 %_9.0.i.i.i.i.i.us.us, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.1), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us.us.1 = getelementptr inbounds nuw i64, ptr %57, i64 %_9.0.i.i.i.i.i.us.us, !dbg !42191
  %_0.sroa.0.0.i7.i.us.us.1 = load i64, ptr %_4.i.i12.i.us.us.1, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.us.1 = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us.us, 2, !dbg !42197
  %_17.i.i.i.i.i.i.us.us.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us.us, i64 2, !dbg !42198
  %61 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.1, i64 %_0.sroa.0.0.i7.i.us.us.1), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.us.1 = extractvalue { i64, i1 } %61, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.us.1 = extractvalue { i64, i1 } %61, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.us.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.1, 0, !dbg !42204
  %_135.i.i.i.i.us.us.1 = zext i1 %_8.i.i.i.i.i.i.us.us.1 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.us.1, ptr %_17.i.i.i.i.i.i.us.us, align 1, !dbg !42211, !noalias !41930
  %62 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.us.1, %_7.1.i.i.i.i.i.i.us.us.1, !dbg !42212
  %_5.i3.i.i.us.us.2 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.1, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.2), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.us.2 = getelementptr inbounds nuw i64, ptr %56, i64 %_9.0.i.i.i.i.i.us.us.1, !dbg !42177
  %_0.sroa.0.0.i.i.us.us.2 = load i64, ptr %_4.i.i.i40.us.us.2, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us.us.2 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.1, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.2), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us.us.2 = getelementptr inbounds nuw i64, ptr %57, i64 %_9.0.i.i.i.i.i.us.us.1, !dbg !42191
  %_0.sroa.0.0.i7.i.us.us.2 = load i64, ptr %_4.i.i12.i.us.us.2, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.us.2 = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us.us, 3, !dbg !42197
  %_17.i.i.i.i.i.i.us.us.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us.us, i64 3, !dbg !42198
  %63 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.2, i64 %_0.sroa.0.0.i7.i.us.us.2), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.us.2 = extractvalue { i64, i1 } %63, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.us.2 = extractvalue { i64, i1 } %63, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.us.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.2, 0, !dbg !42204
  %_135.i.i.i.i.us.us.2 = zext i1 %_8.i.i.i.i.i.i.us.us.2 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.us.2, ptr %_17.i.i.i.i.i.i.us.us.1, align 1, !dbg !42211, !noalias !41930
  %64 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.us.2, %_7.1.i.i.i.i.i.i.us.us.2, !dbg !42212
  %_5.i3.i.i.us.us.3 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.2, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.3), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.us.3 = getelementptr inbounds nuw i64, ptr %56, i64 %_9.0.i.i.i.i.i.us.us.2, !dbg !42177
  %_0.sroa.0.0.i.i.us.us.3 = load i64, ptr %_4.i.i.i40.us.us.3, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us.us.3 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.2, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.3), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us.us.3 = getelementptr inbounds nuw i64, ptr %57, i64 %_9.0.i.i.i.i.i.us.us.2, !dbg !42191
  %_0.sroa.0.0.i7.i.us.us.3 = load i64, ptr %_4.i.i12.i.us.us.3, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.us.3 = add nuw i64 %iter.sroa.7.0133.i.i.i.i.us.us, 4, !dbg !42197
  %_17.i.i.i.i.i.i.us.us.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us.us, i64 4, !dbg !42198
  %65 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.3, i64 %_0.sroa.0.0.i7.i.us.us.3), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.us.3 = extractvalue { i64, i1 } %65, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.us.3 = extractvalue { i64, i1 } %65, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.us.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.3, 0, !dbg !42204
  %_135.i.i.i.i.us.us.3 = zext i1 %_8.i.i.i.i.i.i.us.us.3 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.us.3, ptr %_17.i.i.i.i.i.i.us.us.2, align 1, !dbg !42211, !noalias !41930
  %66 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.us.3, %_7.1.i.i.i.i.i.i.us.us.3, !dbg !42212
  %niter188.next.3 = add i64 %niter188, 4, !dbg !42160
  %niter188.ncmp.3 = icmp eq i64 %niter188.next.3, %unroll_iter187, !dbg !42160
  br i1 %niter188.ncmp.3, label %bb21.i.i.i.i.loopexit.unr-lcssa, label %bb14.i.i.i.i.us.us, !dbg !42160

bb14.i.i.i.i.preheader.split.us.split:            ; preds = %bb14.i.i.i.i.preheader.split.us
  call void @llvm.assume(i1 %_5.i.i5.i), !noalias !41930
  %xtraiter172 = and i64 %_23.i.i.i.i, 3, !dbg !42235
  %67 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !42235
  br i1 %67, label %bb14.i.i.i.i.us.epil.preheader, label %bb14.i.i.i.i.preheader.split.us.split.new, !dbg !42235

bb14.i.i.i.i.preheader.split.us.split.new:        ; preds = %bb14.i.i.i.i.preheader.split.us.split
  %unroll_iter177 = and i64 %_23.i.i.i.i, -4, !dbg !42235
  br label %bb14.i.i.i.i.us, !dbg !42235

bb14.i.i.i.i.us:                                  ; preds = %bb14.i.i.i.i.us, %bb14.i.i.i.i.preheader.split.us.split.new
  %failure10.sroa.0.0.off0135.i.i.i.i.us.1 = phi i1 [ %71, %bb14.i.i.i.i.us ], [ false, %bb14.i.i.i.i.preheader.split.us.split.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us.2 = phi i1 [ %73, %bb14.i.i.i.i.us ], [ false, %bb14.i.i.i.i.preheader.split.us.split.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us.3 = phi i1 [ %75, %bb14.i.i.i.i.us ], [ false, %bb14.i.i.i.i.preheader.split.us.split.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us = phi i1 [ %69, %bb14.i.i.i.i.us ], [ false, %bb14.i.i.i.i.preheader.split.us.split.new ]
  %iter.sroa.0.0134.i.i.i.i.us = phi ptr [ %_17.i.i.i.i.i.i.us.3, %bb14.i.i.i.i.us ], [ %_8.i.i, %bb14.i.i.i.i.preheader.split.us.split.new ]
  %iter.sroa.7.0133.i.i.i.i.us = phi i64 [ %_9.0.i.i.i.i.i.us.3, %bb14.i.i.i.i.us ], [ 0, %bb14.i.i.i.i.preheader.split.us.split.new ]
  %niter178 = phi i64 [ %niter178.next.3, %bb14.i.i.i.i.us ], [ 0, %bb14.i.i.i.i.preheader.split.us.split.new ]
  %_5.i3.i.i.us = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us = getelementptr inbounds nuw i64, ptr %56, i64 %iter.sroa.7.0133.i.i.i.i.us, !dbg !42177
  %_0.sroa.0.0.i.i.us = load i64, ptr %_4.i.i.i40.us, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.us = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us, 1, !dbg !42197
  %_17.i.i.i.i.i.i.us = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us, i64 1, !dbg !42198
  %68 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us, i64 %_0.sroa.0.0.i7.i.us), !dbg !42200
  %_7.0.i.i.i.i.i.i.us = extractvalue { i64, i1 } %68, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us = extractvalue { i64, i1 } %68, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us = icmp sgt i64 %_7.0.i.i.i.i.i.i.us, 0, !dbg !42204
  %_135.i.i.i.i.us = zext i1 %_8.i.i.i.i.i.i.us to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us, ptr %iter.sroa.0.0134.i.i.i.i.us, align 1, !dbg !42211, !noalias !41930
  %69 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us, %_7.1.i.i.i.i.i.i.us, !dbg !42212
  %_5.i3.i.i.us.1 = icmp ult i64 %_9.0.i.i.i.i.i.us, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.1), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.1 = getelementptr inbounds nuw i64, ptr %56, i64 %_9.0.i.i.i.i.i.us, !dbg !42177
  %_0.sroa.0.0.i.i.us.1 = load i64, ptr %_4.i.i.i40.us.1, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.us.1 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.1 = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us, 2, !dbg !42197
  %_17.i.i.i.i.i.i.us.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us, i64 2, !dbg !42198
  %70 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.1, i64 %_0.sroa.0.0.i7.i.us.1), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.1 = extractvalue { i64, i1 } %70, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.1 = extractvalue { i64, i1 } %70, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.1, 0, !dbg !42204
  %_135.i.i.i.i.us.1 = zext i1 %_8.i.i.i.i.i.i.us.1 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.1, ptr %_17.i.i.i.i.i.i.us, align 1, !dbg !42211, !noalias !41930
  %71 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.1, %_7.1.i.i.i.i.i.i.us.1, !dbg !42212
  %_5.i3.i.i.us.2 = icmp ult i64 %_9.0.i.i.i.i.i.us.1, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.2), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.2 = getelementptr inbounds nuw i64, ptr %56, i64 %_9.0.i.i.i.i.i.us.1, !dbg !42177
  %_0.sroa.0.0.i.i.us.2 = load i64, ptr %_4.i.i.i40.us.2, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.us.2 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.2 = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us, 3, !dbg !42197
  %_17.i.i.i.i.i.i.us.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us, i64 3, !dbg !42198
  %72 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.2, i64 %_0.sroa.0.0.i7.i.us.2), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.2 = extractvalue { i64, i1 } %72, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.2 = extractvalue { i64, i1 } %72, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.2, 0, !dbg !42204
  %_135.i.i.i.i.us.2 = zext i1 %_8.i.i.i.i.i.i.us.2 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.2, ptr %_17.i.i.i.i.i.i.us.1, align 1, !dbg !42211, !noalias !41930
  %73 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.2, %_7.1.i.i.i.i.i.i.us.2, !dbg !42212
  %_5.i3.i.i.us.3 = icmp ult i64 %_9.0.i.i.i.i.i.us.2, %_43.sroa.6.i.i.i.i.sroa.7.0.copyload, !dbg !42166
  call void @llvm.assume(i1 %_5.i3.i.i.us.3), !dbg !42176, !noalias !41930
  %_4.i.i.i40.us.3 = getelementptr inbounds nuw i64, ptr %56, i64 %_9.0.i.i.i.i.i.us.2, !dbg !42177
  %_0.sroa.0.0.i.i.us.3 = load i64, ptr %_4.i.i.i40.us.3, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.us.3 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us.3 = add nuw i64 %iter.sroa.7.0133.i.i.i.i.us, 4, !dbg !42197
  %_17.i.i.i.i.i.i.us.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us, i64 4, !dbg !42198
  %74 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.3, i64 %_0.sroa.0.0.i7.i.us.3), !dbg !42200
  %_7.0.i.i.i.i.i.i.us.3 = extractvalue { i64, i1 } %74, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us.3 = extractvalue { i64, i1 } %74, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.3, 0, !dbg !42204
  %_135.i.i.i.i.us.3 = zext i1 %_8.i.i.i.i.i.i.us.3 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us.3, ptr %_17.i.i.i.i.i.i.us.2, align 1, !dbg !42211, !noalias !41930
  %75 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us.3, %_7.1.i.i.i.i.i.i.us.3, !dbg !42212
  %niter178.next.3 = add i64 %niter178, 4, !dbg !42160
  %niter178.ncmp.3 = icmp eq i64 %niter178.next.3, %unroll_iter177, !dbg !42160
  br i1 %niter178.ncmp.3, label %bb21.i.i.i.i.loopexit141.unr-lcssa, label %bb14.i.i.i.i.us, !dbg !42160

bb14.i.i.i.i.preheader.split:                     ; preds = %bb14.i.i.i.i.preheader
  call void @llvm.assume(i1 %_5.i.i.i37), !noalias !41930
  br i1 %.not.i1.i, label %bb14.i.i.i.i.us70.preheader, label %bb14.i.i.i.i.preheader.split.split

bb14.i.i.i.i.us70.preheader:                      ; preds = %bb14.i.i.i.i.preheader.split
  %xtraiter162 = and i64 %_23.i.i.i.i, 3, !dbg !42160
  %76 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !42160
  br i1 %76, label %bb14.i.i.i.i.us70.epil.preheader, label %bb14.i.i.i.i.us70.preheader.new, !dbg !42160

bb14.i.i.i.i.us70.preheader.new:                  ; preds = %bb14.i.i.i.i.us70.preheader
  %unroll_iter167 = and i64 %_23.i.i.i.i, -4, !dbg !42160
  br label %bb14.i.i.i.i.us70, !dbg !42160

bb14.i.i.i.i.us70:                                ; preds = %bb14.i.i.i.i.us70, %bb14.i.i.i.i.us70.preheader.new
  %failure10.sroa.0.0.off0135.i.i.i.i.us71.1 = phi i1 [ %80, %bb14.i.i.i.i.us70 ], [ false, %bb14.i.i.i.i.us70.preheader.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us71.2 = phi i1 [ %82, %bb14.i.i.i.i.us70 ], [ false, %bb14.i.i.i.i.us70.preheader.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us71.3 = phi i1 [ %84, %bb14.i.i.i.i.us70 ], [ false, %bb14.i.i.i.i.us70.preheader.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.us71 = phi i1 [ %78, %bb14.i.i.i.i.us70 ], [ false, %bb14.i.i.i.i.us70.preheader.new ]
  %iter.sroa.0.0134.i.i.i.i.us72 = phi ptr [ %_17.i.i.i.i.i.i.us82.3, %bb14.i.i.i.i.us70 ], [ %_8.i.i, %bb14.i.i.i.i.us70.preheader.new ]
  %iter.sroa.7.0133.i.i.i.i.us73 = phi i64 [ %_9.0.i.i.i.i.i.us81.3, %bb14.i.i.i.i.us70 ], [ 0, %bb14.i.i.i.i.us70.preheader.new ]
  %niter168 = phi i64 [ %niter168.next.3, %bb14.i.i.i.i.us70 ], [ 0, %bb14.i.i.i.i.us70.preheader.new ]
  %_0.sroa.0.0.i.i.us74 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us76 = icmp ult i64 %iter.sroa.7.0133.i.i.i.i.us73, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us76), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us77 = getelementptr inbounds nuw i64, ptr %57, i64 %iter.sroa.7.0133.i.i.i.i.us73, !dbg !42191
  %_0.sroa.0.0.i7.i.us80 = load i64, ptr %_4.i.i12.i.us77, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us81 = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us73, 1, !dbg !42197
  %_17.i.i.i.i.i.i.us82 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us72, i64 1, !dbg !42198
  %77 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us74, i64 %_0.sroa.0.0.i7.i.us80), !dbg !42200
  %_7.0.i.i.i.i.i.i.us83 = extractvalue { i64, i1 } %77, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us84 = extractvalue { i64, i1 } %77, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us85 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us83, 0, !dbg !42204
  %_135.i.i.i.i.us86 = zext i1 %_8.i.i.i.i.i.i.us85 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us86, ptr %iter.sroa.0.0134.i.i.i.i.us72, align 1, !dbg !42211, !noalias !41930
  %78 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us71, %_7.1.i.i.i.i.i.i.us84, !dbg !42212
  %_0.sroa.0.0.i.i.us74.1 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us76.1 = icmp ult i64 %_9.0.i.i.i.i.i.us81, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us76.1), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us77.1 = getelementptr inbounds nuw i64, ptr %57, i64 %_9.0.i.i.i.i.i.us81, !dbg !42191
  %_0.sroa.0.0.i7.i.us80.1 = load i64, ptr %_4.i.i12.i.us77.1, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us81.1 = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us73, 2, !dbg !42197
  %_17.i.i.i.i.i.i.us82.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us72, i64 2, !dbg !42198
  %79 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us74.1, i64 %_0.sroa.0.0.i7.i.us80.1), !dbg !42200
  %_7.0.i.i.i.i.i.i.us83.1 = extractvalue { i64, i1 } %79, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us84.1 = extractvalue { i64, i1 } %79, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us85.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us83.1, 0, !dbg !42204
  %_135.i.i.i.i.us86.1 = zext i1 %_8.i.i.i.i.i.i.us85.1 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us86.1, ptr %_17.i.i.i.i.i.i.us82, align 1, !dbg !42211, !noalias !41930
  %80 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us71.1, %_7.1.i.i.i.i.i.i.us84.1, !dbg !42212
  %_0.sroa.0.0.i.i.us74.2 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us76.2 = icmp ult i64 %_9.0.i.i.i.i.i.us81.1, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us76.2), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us77.2 = getelementptr inbounds nuw i64, ptr %57, i64 %_9.0.i.i.i.i.i.us81.1, !dbg !42191
  %_0.sroa.0.0.i7.i.us80.2 = load i64, ptr %_4.i.i12.i.us77.2, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us81.2 = or disjoint i64 %iter.sroa.7.0133.i.i.i.i.us73, 3, !dbg !42197
  %_17.i.i.i.i.i.i.us82.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us72, i64 3, !dbg !42198
  %81 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us74.2, i64 %_0.sroa.0.0.i7.i.us80.2), !dbg !42200
  %_7.0.i.i.i.i.i.i.us83.2 = extractvalue { i64, i1 } %81, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us84.2 = extractvalue { i64, i1 } %81, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us85.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us83.2, 0, !dbg !42204
  %_135.i.i.i.i.us86.2 = zext i1 %_8.i.i.i.i.i.i.us85.2 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us86.2, ptr %_17.i.i.i.i.i.i.us82.1, align 1, !dbg !42211, !noalias !41930
  %82 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us71.2, %_7.1.i.i.i.i.i.i.us84.2, !dbg !42212
  %_0.sroa.0.0.i.i.us74.3 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_5.i3.i11.i.us76.3 = icmp ult i64 %_9.0.i.i.i.i.i.us81.2, %_43.sroa.6.i.i.i.i.sroa.10.0.copyload, !dbg !42185
  call void @llvm.assume(i1 %_5.i3.i11.i.us76.3), !dbg !42190, !noalias !41930
  %_4.i.i12.i.us77.3 = getelementptr inbounds nuw i64, ptr %57, i64 %_9.0.i.i.i.i.i.us81.2, !dbg !42191
  %_0.sroa.0.0.i7.i.us80.3 = load i64, ptr %_4.i.i12.i.us77.3, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_9.0.i.i.i.i.i.us81.3 = add nuw i64 %iter.sroa.7.0133.i.i.i.i.us73, 4, !dbg !42197
  %_17.i.i.i.i.i.i.us82.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i.us72, i64 4, !dbg !42198
  %83 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us74.3, i64 %_0.sroa.0.0.i7.i.us80.3), !dbg !42200
  %_7.0.i.i.i.i.i.i.us83.3 = extractvalue { i64, i1 } %83, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.us84.3 = extractvalue { i64, i1 } %83, 1, !dbg !42200
  %_8.i.i.i.i.i.i.us85.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us83.3, 0, !dbg !42204
  %_135.i.i.i.i.us86.3 = zext i1 %_8.i.i.i.i.i.i.us85.3 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.us86.3, ptr %_17.i.i.i.i.i.i.us82.2, align 1, !dbg !42211, !noalias !41930
  %84 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.us71.3, %_7.1.i.i.i.i.i.i.us84.3, !dbg !42212
  %niter168.next.3 = add i64 %niter168, 4, !dbg !42160
  %niter168.ncmp.3 = icmp eq i64 %niter168.next.3, %unroll_iter167, !dbg !42160
  br i1 %niter168.ncmp.3, label %bb21.i.i.i.i.loopexit143.unr-lcssa, label %bb14.i.i.i.i.us70, !dbg !42160

bb14.i.i.i.i.preheader.split.split:               ; preds = %bb14.i.i.i.i.preheader.split
  call void @llvm.assume(i1 %_5.i.i5.i), !noalias !41930
  %xtraiter152 = and i64 %_23.i.i.i.i, 3, !dbg !42235
  %85 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !42235
  br i1 %85, label %bb14.i.i.i.i.epil.preheader, label %bb14.i.i.i.i.preheader.split.split.new, !dbg !42235

bb14.i.i.i.i.preheader.split.split.new:           ; preds = %bb14.i.i.i.i.preheader.split.split
  %unroll_iter157 = and i64 %_23.i.i.i.i, -4, !dbg !42235
  br label %bb14.i.i.i.i, !dbg !42235

bb14.i.i.i.i:                                     ; preds = %bb14.i.i.i.i, %bb14.i.i.i.i.preheader.split.split.new
  %failure10.sroa.0.0.off0135.i.i.i.i.1 = phi i1 [ %89, %bb14.i.i.i.i ], [ false, %bb14.i.i.i.i.preheader.split.split.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.2 = phi i1 [ %91, %bb14.i.i.i.i ], [ false, %bb14.i.i.i.i.preheader.split.split.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i.3 = phi i1 [ %93, %bb14.i.i.i.i ], [ false, %bb14.i.i.i.i.preheader.split.split.new ]
  %failure10.sroa.0.0.off0135.i.i.i.i = phi i1 [ %87, %bb14.i.i.i.i ], [ false, %bb14.i.i.i.i.preheader.split.split.new ]
  %iter.sroa.0.0134.i.i.i.i = phi ptr [ %_17.i.i.i.i.i.i.3, %bb14.i.i.i.i ], [ %_8.i.i, %bb14.i.i.i.i.preheader.split.split.new ]
  %niter158 = phi i64 [ %niter158.next.3, %bb14.i.i.i.i ], [ 0, %bb14.i.i.i.i.preheader.split.split.new ]
  %_0.sroa.0.0.i.i = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_17.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i, i64 1, !dbg !42198
  %86 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i, i64 %_0.sroa.0.0.i7.i), !dbg !42200
  %_7.0.i.i.i.i.i.i = extractvalue { i64, i1 } %86, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i = extractvalue { i64, i1 } %86, 1, !dbg !42200
  %_8.i.i.i.i.i.i = icmp sgt i64 %_7.0.i.i.i.i.i.i, 0, !dbg !42204
  %_135.i.i.i.i = zext i1 %_8.i.i.i.i.i.i to i8, !dbg !42205
  store i8 %_135.i.i.i.i, ptr %iter.sroa.0.0134.i.i.i.i, align 1, !dbg !42211, !noalias !41930
  %87 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i, %_7.1.i.i.i.i.i.i, !dbg !42212
  %_0.sroa.0.0.i.i.1 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.1 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_17.i.i.i.i.i.i.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i, i64 2, !dbg !42198
  %88 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.1, i64 %_0.sroa.0.0.i7.i.1), !dbg !42200
  %_7.0.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %88, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %88, 1, !dbg !42200
  %_8.i.i.i.i.i.i.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.1, 0, !dbg !42204
  %_135.i.i.i.i.1 = zext i1 %_8.i.i.i.i.i.i.1 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.1, ptr %_17.i.i.i.i.i.i, align 1, !dbg !42211, !noalias !41930
  %89 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.1, %_7.1.i.i.i.i.i.i.1, !dbg !42212
  %_0.sroa.0.0.i.i.2 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.2 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_17.i.i.i.i.i.i.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i, i64 3, !dbg !42198
  %90 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.2, i64 %_0.sroa.0.0.i7.i.2), !dbg !42200
  %_7.0.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %90, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %90, 1, !dbg !42200
  %_8.i.i.i.i.i.i.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.2, 0, !dbg !42204
  %_135.i.i.i.i.2 = zext i1 %_8.i.i.i.i.i.i.2 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.2, ptr %_17.i.i.i.i.i.i.1, align 1, !dbg !42211, !noalias !41930
  %91 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.2, %_7.1.i.i.i.i.i.i.2, !dbg !42212
  %_0.sroa.0.0.i.i.3 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.0.0.copyload, align 8, !dbg !42178, !noalias !42180, !noundef !37
  %_0.sroa.0.0.i7.i.3 = load i64, ptr %_43.sroa.6.i.i.i.i.sroa.8.0.copyload, align 8, !dbg !42192, !noalias !42194, !noundef !37
  %_17.i.i.i.i.i.i.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0134.i.i.i.i, i64 4, !dbg !42198
  %92 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.3, i64 %_0.sroa.0.0.i7.i.3), !dbg !42200
  %_7.0.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %92, 0, !dbg !42200
  %_7.1.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %92, 1, !dbg !42200
  %_8.i.i.i.i.i.i.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.3, 0, !dbg !42204
  %_135.i.i.i.i.3 = zext i1 %_8.i.i.i.i.i.i.3 to i8, !dbg !42205
  store i8 %_135.i.i.i.i.3, ptr %_17.i.i.i.i.i.i.2, align 1, !dbg !42211, !noalias !41930
  %93 = or i1 %failure10.sroa.0.0.off0135.i.i.i.i.3, %_7.1.i.i.i.i.i.i.3, !dbg !42212
  %niter158.next.3 = add i64 %niter158, 4, !dbg !42160
  %niter158.ncmp.3 = icmp eq i64 %niter158.next.3, %unroll_iter157, !dbg !42160
  br i1 %niter158.ncmp.3, label %bb21.i.i.i.i.loopexit145.unr-lcssa, label %bb14.i.i.i.i, !dbg !42160

bb22.i.i.i.i:                                     ; preds = %bb1.i47.i.i.i.i
  %.pr.i.i.i.i = load i64, ptr %_68.i.i.i.i, align 8, !dbg !42159, !noalias !41909
  %.not35.i.i.i.i = icmp eq i64 %.pr.i.i.i.i, -1, !dbg !42159
  br i1 %.not35.i.i.i.i, label %bb24.i.i.i.i, label %bb23.i.i.i.i, !dbg !42218

bb23.i.i.i.i:                                     ; preds = %bb22.i.i.i.i
  %94 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42236
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %94, ptr noundef nonnull align 8 dereferenceable(80) %_68.i.i.i.i, i64 80, i1 false), !dbg !42238, !noalias !41965
  store i64 0, ptr %_0, align 8, !dbg !42236, !alias.scope !41992, !noalias !41965
  call void @llvm.lifetime.end.p0(ptr nonnull %_68.i.i.i.i), !dbg !42239, !noalias !41909
; invoke core::ptr::drop_glue::<vortex_array::scalar_fn::unstable::rofl::output::VortexBuffer<i8>>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6output12VortexBufferaEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(88) %output.i.i.i.i)
          to label %bb26.i.i.i.i unwind label %cleanup12.i.i.i.i, !dbg !42042, !noalias !41930

bb24.i.i.i.i:                                     ; preds = %bb22.i.i.i.i, %bb22.thread.sink.split.i.i.i.i, %bb21.i.i.i.i, %bb10.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_74.i.i.i.i), !dbg !42240, !noalias !41909
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(88) %_74.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(88) %output.i.i.i.i, i64 88, i1 false), !dbg !42240, !noalias !41909
; invoke <vortex_array::scalar_fn::unstable::rofl::output::VortexBuffer<bool> as rofl::output::OutputBuffer<bool>>::finish
  %95 = invoke { ptr, ptr } @_RNvXNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6outputINtB2_12VortexBufferbEINtNtCshZi9mpuUhIi_4rofl6output12OutputBufferbE6finishCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(88) %_74.i.i.i.i, i64 noundef %_23.i.i.i.i)
          to label %bb25.i.i.i.i unwind label %bb48.i.i.i.i, !dbg !42241, !noalias !41930

bb25.i.i.i.i:                                     ; preds = %bb24.i.i.i.i
  %_73.0.i.i.i.i = extractvalue { ptr, ptr } %95, 0, !dbg !42240
  %_73.1.i.i.i.i = extractvalue { ptr, ptr } %95, 1, !dbg !42240
  call void @llvm.lifetime.end.p0(ptr nonnull %_74.i.i.i.i), !dbg !42242, !noalias !41909
  %_72.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42243
  store ptr %_73.0.i.i.i.i, ptr %_72.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !42243, !alias.scope !41992, !noalias !41965
  %_72.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !42243
  store ptr %_73.1.i.i.i.i, ptr %_72.sroa.5.0..sroa_idx.i.i.i.i, align 8, !dbg !42243, !alias.scope !41992, !noalias !41965
  store <2 x i64> <i64 0, i64 -9223372036854775780>, ptr %_0, align 8, !dbg !42243, !alias.scope !41992, !noalias !41965
  call void @llvm.lifetime.end.p0(ptr nonnull %_68.i.i.i.i), !dbg !42239, !noalias !41909
  br label %bb26.i.i.i.i, !dbg !42042

bb26.i.i.i.i:                                     ; preds = %bb25.i.i.i.i, %bb23.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %output.i.i.i.i), !dbg !42042, !noalias !41909
  call void @llvm.experimental.noalias.scope.decl(metadata !42244), !dbg !42247
  call void @llvm.experimental.noalias.scope.decl(metadata !42248), !dbg !42251
  call void @llvm.experimental.noalias.scope.decl(metadata !42254), !dbg !42257
  %96 = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 16, !dbg !42260
  call void @llvm.experimental.noalias.scope.decl(metadata !42263), !dbg !42260
  %97 = load ptr, ptr %96, align 8, !dbg !42266, !alias.scope !42268, !noalias !41909, !noundef !37
  %98 = icmp eq ptr %97, null, !dbg !42266
  br i1 %98, label %bb4.i50.i.i.i.i, label %bb2.i.i.i.i.i.i.i.i, !dbg !42266

bb2.i.i.i.i.i.i.i.i:                              ; preds = %bb26.i.i.i.i
  %_2.i.i.i.i.i.i.i.i.i.i = atomicrmw sub ptr %97, i64 1 release, align 8, !dbg !42269, !noalias !42274
  %99 = icmp eq i64 %_2.i.i.i.i.i.i.i.i.i.i, 1, !dbg !42279
  br i1 %99, label %bb2.i.i.i.i.i.i.i.i.i.i, label %bb4.i50.i.i.i.i, !dbg !42279

bb2.i.i.i.i.i.i.i.i.i.i:                          ; preds = %bb2.i.i.i.i.i.i.i.i
  fence acquire, !dbg !42280
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %96) #23
          to label %bb4.i50.i.i.i.i unwind label %cleanup.i.i.i.i.i, !dbg !42282, !noalias !41930

cleanup.i.i.i.i.i:                                ; preds = %bb2.i.i.i.i.i.i.i.i.i.i
  %100 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !42283), !dbg !42251
  call void @llvm.experimental.noalias.scope.decl(metadata !42286), !dbg !42289
  %101 = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 56, !dbg !42291
  call void @llvm.experimental.noalias.scope.decl(metadata !42293), !dbg !42291
  %102 = load ptr, ptr %101, align 8, !dbg !42296, !alias.scope !42298, !noalias !41909, !noundef !37
  %103 = icmp eq ptr %102, null, !dbg !42296
  br i1 %103, label %bb52.i.i.i.i, label %bb2.i.i.i1.i.i.i.i.i, !dbg !42296

bb2.i.i.i1.i.i.i.i.i:                             ; preds = %cleanup.i.i.i.i.i
  %_2.i.i.i.i.i2.i.i.i.i.i = atomicrmw sub ptr %102, i64 1 release, align 8, !dbg !42299, !noalias !42304
  %104 = icmp eq i64 %_2.i.i.i.i.i2.i.i.i.i.i, 1, !dbg !42309
  br i1 %104, label %bb2.i.i.i.i.i3.i.i.i.i.i, label %bb52.i.i.i.i, !dbg !42309

bb2.i.i.i.i.i3.i.i.i.i.i:                         ; preds = %bb2.i.i.i1.i.i.i.i.i
  fence acquire, !dbg !42310
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %101) #23
          to label %bb52.i.i.i.i unwind label %terminate.i.i.i.i.i, !dbg !42312, !noalias !41930

bb4.i50.i.i.i.i:                                  ; preds = %bb2.i.i.i.i.i.i.i.i.i.i, %bb2.i.i.i.i.i.i.i.i, %bb26.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !42313), !dbg !42251
  call void @llvm.experimental.noalias.scope.decl(metadata !42316), !dbg !42319
  %105 = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 56, !dbg !42321
  call void @llvm.experimental.noalias.scope.decl(metadata !42323), !dbg !42321
  %106 = load ptr, ptr %105, align 8, !dbg !42326, !alias.scope !42328, !noalias !41909, !noundef !37
  %107 = icmp eq ptr %106, null, !dbg !42326
  br i1 %107, label %bb28.i.i.i.i, label %bb2.i.i.i6.i.i.i.i.i, !dbg !42326

bb2.i.i.i6.i.i.i.i.i:                             ; preds = %bb4.i50.i.i.i.i
  %_2.i.i.i.i.i7.i.i.i.i.i = atomicrmw sub ptr %106, i64 1 release, align 8, !dbg !42329, !noalias !42334
  %108 = icmp eq i64 %_2.i.i.i.i.i7.i.i.i.i.i, 1, !dbg !42339
  br i1 %108, label %bb2.i.i.i.i.i8.i.i.i.i.i, label %bb28.i.i.i.i, !dbg !42339

bb2.i.i.i.i.i8.i.i.i.i.i:                         ; preds = %bb2.i.i.i6.i.i.i.i.i
  fence acquire, !dbg !42340
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %105) #23
          to label %bb28.i.i.i.i unwind label %cleanup.i.i.i.i, !dbg !42342, !noalias !41930

terminate.i.i.i.i.i:                              ; preds = %bb2.i.i.i.i.i3.i.i.i.i.i
  %109 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !42251, !noalias !41930
  unreachable, !dbg !42251

bb28.i.i.i.i:                                     ; preds = %bb2.i.i.i.i.i8.i.i.i.i.i, %bb2.i.i.i6.i.i.i.i.i, %bb4.i50.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i.i), !dbg !42247, !noalias !41909
  %110 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 16, !dbg !42343
  %111 = load i8, ptr %110, align 8, !dbg !42345, !range !1916, !alias.scope !42347, !noalias !41956, !noundef !37
  %112 = icmp eq i8 %111, -1, !dbg !42345
  br i1 %112, label %bb5.i.i.i, label %bb37.sink.split.i.i.i.i, !dbg !42345

bb37.sink.split.i.i.i.i:                          ; preds = %bb34.i.i.i.i, %bb28.i.i.i.i
  %.sink.i.i.i.i = phi ptr [ %128, %bb34.i.i.i.i ], [ %110, %bb28.i.i.i.i ]
; call core::ptr::drop_glue::<vortex_array::dtype::DType>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %.sink.i.i.i.i), !dbg !42352, !noalias !41853
  br label %bb5.i.i.i, !dbg !42352

bb30.i.i.i.i:                                     ; preds = %bb69.i.i.i.i, %bb67.i.i.i.i
  store i64 1, ptr %_0, align 8, !dbg !42355, !alias.scope !41992, !noalias !41965
; invoke core::ptr::drop_glue::<vortex_array::scalar_fn::unstable::rofl::output::VortexBuffer<i8>>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6output12VortexBufferaEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(88) %output.i.i.i.i)
          to label %bb31.i.i.i.i unwind label %cleanup12.i.i.i.i, !dbg !42042, !noalias !41930

bb31.i.i.i.i:                                     ; preds = %bb30.i.i.i.i, %bb60.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %output.i.i.i.i), !dbg !42042, !noalias !41909
  call void @llvm.experimental.noalias.scope.decl(metadata !42357), !dbg !42247
  call void @llvm.experimental.noalias.scope.decl(metadata !42360), !dbg !42363
  call void @llvm.experimental.noalias.scope.decl(metadata !42365), !dbg !42368
  %113 = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 16, !dbg !42370
  call void @llvm.experimental.noalias.scope.decl(metadata !42372), !dbg !42370
  %114 = load ptr, ptr %113, align 8, !dbg !42375, !alias.scope !42377, !noalias !41909, !noundef !37
  %115 = icmp eq ptr %114, null, !dbg !42375
  br i1 %115, label %bb4.i57.i.i.i.i, label %bb2.i.i.i.i55.i.i.i.i, !dbg !42375

bb2.i.i.i.i55.i.i.i.i:                            ; preds = %bb31.i.i.i.i
  %_2.i.i.i.i.i.i56.i.i.i.i = atomicrmw sub ptr %114, i64 1 release, align 8, !dbg !42378, !noalias !42383
  %116 = icmp eq i64 %_2.i.i.i.i.i.i56.i.i.i.i, 1, !dbg !42388
  br i1 %116, label %bb2.i.i.i.i.i.i61.i.i.i.i, label %bb4.i57.i.i.i.i, !dbg !42388

bb2.i.i.i.i.i.i61.i.i.i.i:                        ; preds = %bb2.i.i.i.i55.i.i.i.i
  fence acquire, !dbg !42389
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %113) #23
          to label %bb4.i57.i.i.i.i unwind label %cleanup.i62.i.i.i.i, !dbg !42391, !noalias !41930

cleanup.i62.i.i.i.i:                              ; preds = %bb2.i.i.i.i.i.i61.i.i.i.i
  %117 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !42392), !dbg !42363
  call void @llvm.experimental.noalias.scope.decl(metadata !42395), !dbg !42398
  %118 = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 56, !dbg !42400
  call void @llvm.experimental.noalias.scope.decl(metadata !42402), !dbg !42400
  %119 = load ptr, ptr %118, align 8, !dbg !42405, !alias.scope !42407, !noalias !41909, !noundef !37
  %120 = icmp eq ptr %119, null, !dbg !42405
  br i1 %120, label %bb52.i.i.i.i, label %bb2.i.i.i1.i63.i.i.i.i, !dbg !42405

bb2.i.i.i1.i63.i.i.i.i:                           ; preds = %cleanup.i62.i.i.i.i
  %_2.i.i.i.i.i2.i64.i.i.i.i = atomicrmw sub ptr %119, i64 1 release, align 8, !dbg !42408, !noalias !42413
  %121 = icmp eq i64 %_2.i.i.i.i.i2.i64.i.i.i.i, 1, !dbg !42418
  br i1 %121, label %bb2.i.i.i.i.i3.i66.i.i.i.i, label %bb52.i.i.i.i, !dbg !42418

bb2.i.i.i.i.i3.i66.i.i.i.i:                       ; preds = %bb2.i.i.i1.i63.i.i.i.i
  fence acquire, !dbg !42419
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %118) #23
          to label %bb52.i.i.i.i unwind label %terminate.i67.i.i.i.i, !dbg !42421, !noalias !41930

bb4.i57.i.i.i.i:                                  ; preds = %bb2.i.i.i.i.i.i61.i.i.i.i, %bb2.i.i.i.i55.i.i.i.i, %bb31.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !42422), !dbg !42363
  call void @llvm.experimental.noalias.scope.decl(metadata !42425), !dbg !42428
  %122 = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 56, !dbg !42430
  call void @llvm.experimental.noalias.scope.decl(metadata !42432), !dbg !42430
  %123 = load ptr, ptr %122, align 8, !dbg !42435, !alias.scope !42437, !noalias !41909, !noundef !37
  %124 = icmp eq ptr %123, null, !dbg !42435
  br i1 %124, label %bb34.i.i.i.i, label %bb2.i.i.i6.i58.i.i.i.i, !dbg !42435

bb2.i.i.i6.i58.i.i.i.i:                           ; preds = %bb4.i57.i.i.i.i
  %_2.i.i.i.i.i7.i59.i.i.i.i = atomicrmw sub ptr %123, i64 1 release, align 8, !dbg !42438, !noalias !42443
  %125 = icmp eq i64 %_2.i.i.i.i.i7.i59.i.i.i.i, 1, !dbg !42448
  br i1 %125, label %bb2.i.i.i.i.i8.i60.i.i.i.i, label %bb34.i.i.i.i, !dbg !42448

bb2.i.i.i.i.i8.i60.i.i.i.i:                       ; preds = %bb2.i.i.i6.i58.i.i.i.i
  fence acquire, !dbg !42449
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %122) #23
          to label %bb34.i.i.i.i unwind label %cleanup.i.i.i.i, !dbg !42451, !noalias !41930

terminate.i67.i.i.i.i:                            ; preds = %bb2.i.i.i.i.i3.i66.i.i.i.i
  %126 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !42363, !noalias !41930
  unreachable, !dbg !42363

unreachable.i.i.i.i:                              ; preds = %bb64.i.i.i.i
  unreachable

terminate.i.i.i.i:                                ; preds = %bb40.i.i.i.i, %bb48.thread121.loopexit.split-lp.i.i.i.i, %bb2.i.i.i.i.i.i
  %127 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !42452, !noalias !41957
  unreachable, !dbg !42452

bb34.i.i.i.i:                                     ; preds = %bb2.i.i.i.i.i8.i60.i.i.i.i, %bb2.i.i.i6.i58.i.i.i.i, %bb4.i57.i.i.i.i, %bb33.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i.i), !dbg !42247, !noalias !41909
  %128 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 16, !dbg !42453
  %129 = load i8, ptr %128, align 8, !dbg !42455, !range !1916, !alias.scope !42457, !noalias !41956, !noundef !37
  %130 = icmp eq i8 %129, -1, !dbg !42455
  br i1 %130, label %bb5.i.i.i, label %bb37.sink.split.i.i.i.i, !dbg !42455

bb40.i.i.i.i:                                     ; preds = %bb48.thread121.loopexit.split-lp.i.i.i.i, %bb48.i.i.i.i, %cleanup12.i.i.i.i, %cleanup11.i.i.i.i
  %.pn37.i.i.i.i = phi { ptr, i32 } [ %16, %cleanup12.i.i.i.i ], [ %lpad.loopexit.split-lp.i.i.i.i, %bb48.thread121.loopexit.split-lp.i.i.i.i ], [ %lpad.thr_comm.split-lp.i.i.i.i, %bb48.i.i.i.i ], [ %14, %cleanup11.i.i.i.i ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>, rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(80) %columns.i.i.i.i) #21
          to label %bb52.i.i.i.i unwind label %terminate.i.i.i.i, !dbg !42247, !noalias !41930

bb6.i.i.i:                                        ; preds = %bb62.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.sroa.13.i.i.i), !dbg !42462
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.sroa.17.i.i.i), !dbg !42462
  call void @llvm.experimental.noalias.scope.decl(metadata !42463), !dbg !42466
  %tolerant.i.i.i.i = icmp eq i64 %_10.i.i.i, 2, !dbg !42467
  br i1 %tolerant.i.i.i.i, label %bb1.i.i.i.i, label %start.bb4_crit_edge.i.i.i.i, !dbg !42469

start.bb4_crit_edge.i.i.i.i:                      ; preds = %bb6.i.i.i
  %.phi.trans.insert.i.i.i.i = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 40
  %_11.0.pre.i.i.i.i = load ptr, ptr %.phi.trans.insert.i.i.i.i, align 8, !dbg !42470, !alias.scope !42471, !noalias !42472
  %.phi.trans.insert4.i.i.i.i = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 48
  %_11.1.pre.i.i.i.i = load i64, ptr %.phi.trans.insert4.i.i.i.i, align 8, !dbg !42470, !alias.scope !42471, !noalias !42472
  br label %bb4.i30.i.i.i, !dbg !42469

bb4.i30.i.i.i:                                    ; preds = %bb11.i37.i.i.i, %start.bb4_crit_edge.i.i.i.i
  %_11.1.i.i.i.i = phi i64 [ %_11.1.pre.i.i.i.i, %start.bb4_crit_edge.i.i.i.i ], [ %_10.1.i.i.i.i, %bb11.i37.i.i.i ], !dbg !42470
  %_11.0.i.i.i.i = phi ptr [ %_11.0.pre.i.i.i.i, %start.bb4_crit_edge.i.i.i.i ], [ %_10.0.i.i.i.i, %bb11.i37.i.i.i ], !dbg !42470
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i.i), !dbg !42474, !noalias !42475
  %131 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 80, !dbg !42476
  %_12.i.i.i.i = load ptr, ptr %131, align 8, !dbg !42476, !alias.scope !42471, !noalias !42472, !nonnull !37, !align !40, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([88 x i8]) align 8 captures(none) dereferenceable(88) %_9.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i.i.i, i64 noundef %_11.1.i.i.i.i, i1 noundef zeroext %tolerant.i.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i.i.i)
          to label %.noexc39.i.i.i unwind label %bb42.thread112.i.i.i, !dbg !42474, !noalias !42477

.noexc39.i.i.i:                                   ; preds = %bb4.i30.i.i.i
  %_20.i.i.i.i = load i64, ptr %_9.i.i.i.i, align 8, !dbg !42478, !range !4730, !noalias !42475, !noundef !37
  %132 = trunc nuw i64 %_20.i.i.i.i to i1, !dbg !42480
  %133 = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 8, !dbg !42481
  %_18.sroa.7.8.copyload58.i.i.i = load i64, ptr %133, align 8, !dbg !42481, !noalias !42482
  %_18.sroa.12.8..sroa_idx61.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 16, !dbg !42481
  %_18.sroa.12.8.copyload62.i.i.i = load i8, ptr %_18.sroa.12.8..sroa_idx61.i.i.i, align 8, !dbg !42481, !noalias !42482
  %_18.sroa.13.8..sroa_idx65.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 17, !dbg !42481
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.13.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.13.8..sroa_idx65.i.i.i, i64 23, i1 false), !dbg !42481, !noalias !42482
  %_18.sroa.14.8..sroa_idx66.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 40, !dbg !42481
  %_18.sroa.14.8.copyload67.i.i.i = load i8, ptr %_18.sroa.14.8..sroa_idx66.i.i.i, align 8, !dbg !42481, !noalias !42482
  %_18.sroa.17.8..sroa_idx68.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 41, !dbg !42481
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_18.sroa.17.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_18.sroa.17.8..sroa_idx68.i.i.i, i64 47, i1 false), !dbg !42481, !noalias !42482
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i), !dbg !42483, !noalias !42475
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_17.sroa.6.sroa.0.sroa.9.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.13.i.i.i, i64 23, i1 false), !dbg !42484, !noalias !41867
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_17.sroa.6.sroa.9.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_18.sroa.17.i.i.i, i64 47, i1 false), !dbg !42484, !noalias !41867
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.sroa.13.i.i.i), !dbg !42487
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.sroa.17.i.i.i), !dbg !42487
  br i1 %132, label %bb63.i.i.i, label %bb64.i.i.i, !dbg !42480

bb1.i.i.i.i:                                      ; preds = %bb6.i.i.i
  %134 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 48, !dbg !42488
  %_10.1.i.i.i.i = load i64, ptr %134, align 8, !dbg !42488, !alias.scope !42471, !noalias !42472, !noundef !37
  %switch138 = icmp ult i64 %_10.1.i.i.i.i, 2, !dbg !42489
  br i1 %switch138, label %panic3.i41.invoke, label %bb11.i37.i.i.i, !dbg !42489

panic3.i41.invoke:                                ; preds = %bb1.i.i.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i.i.i, i64 noundef %_10.1.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i41.cont unwind label %bb42.thread112.i.i.i, !dbg !42489

panic3.i41.cont:                                  ; preds = %panic3.i41.invoke
  unreachable

bb11.i37.i.i.i:                                   ; preds = %bb1.i.i.i.i
  %135 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 40, !dbg !42488
  %_10.0.i.i.i.i = load ptr, ptr %135, align 8, !dbg !42488, !alias.scope !42471, !noalias !42472, !nonnull !37, !align !40, !noundef !37
  br label %bb4.i30.i.i.i, !dbg !42491

bb5.i.i.i:                                        ; preds = %bb34.i.i.i.i, %bb37.sink.split.i.i.i.i, %bb28.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.5.sroa.0.sroa.8.i.i.i.i), !dbg !42492
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.5.sroa.8.i.i.i.i), !dbg !42492
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i.i), !dbg !42493, !noalias !41867
  br label %bb3.i.i, !dbg !42494

bb63.i.i.i:                                       ; preds = %.noexc39.i.i.i
  %_94.sroa.0.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !42495
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_94.sroa.0.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_17.sroa.6.sroa.0.sroa.9.i.i.i, i64 23, i1 false), !dbg !42487, !noalias !41889
  %_94.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 41, !dbg !42495
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_94.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_17.sroa.6.sroa.9.i.i.i, i64 47, i1 false), !dbg !42487, !noalias !41889
  %136 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42495
  store i64 %_18.sroa.7.8.copyload58.i.i.i, ptr %136, align 8, !dbg !42495, !alias.scope !41891, !noalias !41889
  %_94.sroa.0.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42495
  store i8 %_18.sroa.12.8.copyload62.i.i.i, ptr %_94.sroa.0.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !42495, !alias.scope !41891, !noalias !41889
  %_94.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !42495
  store i8 %_18.sroa.14.8.copyload67.i.i.i, ptr %_94.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !42495, !alias.scope !41891, !noalias !41889
  store i64 1, ptr %_0, align 8, !dbg !42495, !alias.scope !41891, !noalias !41889
  br label %bb49.critedge.i.i.i, !dbg !41892

bb64.i.i.i:                                       ; preds = %.noexc39.i.i.i
  %.not20.i.i.i = icmp eq i8 %_18.sroa.14.8.copyload67.i.i.i, 2, !dbg !42462
  br i1 %.not20.i.i.i, label %bb8.i.i.i, label %bb9.i.i.i, !dbg !42501

bb9.i.i.i:                                        ; preds = %bb64.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i.i.i), !dbg !42502, !noalias !41867
  store i64 %_18.sroa.7.8.copyload58.i.i.i, ptr %columns.i.i.i, align 8, !dbg !42502, !noalias !41867
  %val.sroa.0.sroa.2.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 8, !dbg !42502
  store i8 %_18.sroa.12.8.copyload62.i.i.i, ptr %val.sroa.0.sroa.2.0.columns.sroa_idx.i.i.i, align 8, !dbg !42502, !noalias !41867
  %val.sroa.0.sroa.3.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 9, !dbg !42502
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val.sroa.0.sroa.3.0.columns.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_17.sroa.6.sroa.0.sroa.9.i.i.i, i64 23, i1 false), !dbg !42502, !noalias !41867
  %val.sroa.2.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 32, !dbg !42502
  store i8 %_18.sroa.14.8.copyload67.i.i.i, ptr %val.sroa.2.0.columns.sroa_idx.i.i.i, align 8, !dbg !42502, !noalias !41867
  %val.sroa.3.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 33, !dbg !42502
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %val.sroa.3.0.columns.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_17.sroa.6.sroa.9.i.i.i, i64 47, i1 false), !dbg !42502, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_26.i.i.i), !dbg !42503, !noalias !41867
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_26.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i.i.i)
          to label %bb11.i.i.i unwind label %cleanup10.i.i.i, !dbg !42503, !noalias !42477

bb8.i.i.i:                                        ; preds = %bb64.i.i.i
  store <2 x i64> <i64 0, i64 -9223372036854775778>, ptr %_0, align 8, !dbg !42505, !alias.scope !41891, !noalias !41889
  br label %bb49.critedge.i.i.i, !dbg !42506

cleanup10.i.i.i:                                  ; preds = %bb9.i.i.i
  %137 = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i, !dbg !42507

bb11.i.i.i:                                       ; preds = %bb9.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i.i.i), !dbg !42507, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %source.i.i.i), !dbg !42508, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_29.sroa.6.i.i.i), !dbg !42510
  call void @llvm.lifetime.start.p0(ptr nonnull %_30.i.i.i), !dbg !42510, !noalias !41867
  %138 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 88, !dbg !42511
  %_32.i.i.i = load i64, ptr %138, align 8, !dbg !42511, !alias.scope !41862, !noalias !41897, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(none) dereferenceable(80) %_30.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i.i.i, i64 noundef %_32.i.i.i)
          to label %bb12.i.i.i unwind label %cleanup11.i.i.i, !dbg !42510, !noalias !42477

cleanup11.i.i.i:                                  ; preds = %bb11.i.i.i
  %139 = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i

bb12.i.i.i:                                       ; preds = %bb11.i.i.i
  %140 = load i64, ptr %_30.i.i.i, align 8, !dbg !42512, !range !1887, !noalias !41867, !noundef !37
  %.not21.i.i.i = icmp eq i64 %140, -1, !dbg !42512
  %141 = getelementptr inbounds nuw i8, ptr %_30.i.i.i, i64 8, !dbg !42515
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_29.sroa.6.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %141, i64 56, i1 false), !dbg !42515, !noalias !41867
  br i1 %.not21.i.i.i, label %bb66.i.i.i, label %bb65.i.i.i, !dbg !42516

bb65.i.i.i:                                       ; preds = %bb12.i.i.i
  %_98.sroa.5.0._30.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_30.i.i.i, i64 64, !dbg !42517
  %_101.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 72, !dbg !42518
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %_101.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(16) %_98.sroa.5.0._30.sroa_idx.i.i.i, i64 16, i1 false), !dbg !42517, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %_30.i.i.i), !dbg !42524, !noalias !41867
  %_101.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42518
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_101.sroa.4.0..sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_29.sroa.6.i.i.i, i64 56, i1 false), !dbg !42524, !noalias !41889
  %142 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42518
  store i64 %140, ptr %142, align 8, !dbg !42518, !alias.scope !41891, !noalias !41889
  store i64 1, ptr %_0, align 8, !dbg !42518, !alias.scope !41891, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %_29.sroa.6.i.i.i), !dbg !42525
  br label %bb31.i.i.i, !dbg !42526

bb66.i.i.i:                                       ; preds = %bb12.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_30.i.i.i), !dbg !42524, !noalias !41867
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %source.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_29.sroa.6.i.i.i, i64 56, i1 false), !dbg !42510, !noalias !41867
  call void @llvm.lifetime.end.p0(ptr nonnull %_29.sroa.6.i.i.i), !dbg !42525
  call void @llvm.lifetime.start.p0(ptr nonnull %output.i.i.i), !dbg !42528, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_36.sroa.6.i.i.i), !dbg !42530
  call void @llvm.lifetime.start.p0(ptr nonnull %_37.i.i.i), !dbg !42530, !noalias !41867
  %143 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 96, !dbg !42531
  %_38.i.i.i = load i64, ptr %143, align 8, !dbg !42531, !alias.scope !41862, !noalias !41897, !noundef !37
; invoke <vortex_array::scalar_fn::unstable::rofl::VortexHost as rofl::output::OutputBinding<bool>>::allocate
  invoke void @_RNvXs0_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6outputNtB7_10VortexHostINtNtCshZi9mpuUhIi_4rofl6output13OutputBindingbE8allocate(ptr noalias nofree noundef nonnull sret([88 x i8]) align 8 captures(none) dereferenceable(88) %_37.i.i.i, i64 noundef %_38.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i.i.i)
          to label %bb13.i.i.i unwind label %cleanup12.i.i.i, !dbg !42530, !noalias !42477

cleanup12.i.i.i:                                  ; preds = %bb29.i.i.i, %bb66.i.i.i
  %144 = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i

bb13.i.i.i:                                       ; preds = %bb66.i.i.i
  %145 = load i64, ptr %_37.i.i.i, align 8, !dbg !42532, !range !26899, !noalias !41867, !noundef !37
  %146 = icmp eq i64 %145, 0, !dbg !42532
  %147 = getelementptr inbounds nuw i8, ptr %_37.i.i.i, i64 8, !dbg !42535
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %_36.sroa.6.i.i.i, ptr noundef nonnull align 8 dereferenceable(80) %147, i64 80, i1 false), !dbg !42535, !noalias !41867
  call void @llvm.lifetime.end.p0(ptr nonnull %_37.i.i.i), !dbg !42536, !noalias !41867
  br i1 %146, label %bb67.i.i.i, label %bb68.i.i.i, !dbg !42537

bb67.i.i.i:                                       ; preds = %bb13.i.i.i
  %148 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42538
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %148, ptr noundef nonnull align 8 dereferenceable(80) %_36.sroa.6.i.i.i, i64 80, i1 false), !dbg !42536, !noalias !41889
  store i64 1, ptr %_0, align 8, !dbg !42538, !alias.scope !41891, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.sroa.6.i.i.i), !dbg !42544
  call void @llvm.lifetime.end.p0(ptr nonnull %output.i.i.i), !dbg !42545, !noalias !41867
  br label %bb31.i.i.i, !dbg !42546

bb68.i.i.i:                                       ; preds = %bb13.i.i.i
  %val5.sroa.4.0.output.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %output.i.i.i, i64 8, !dbg !42547
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %val5.sroa.4.0.output.sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(80) %_36.sroa.6.i.i.i, i64 80, i1 false), !dbg !42530, !noalias !41867
  store i64 %145, ptr %output.i.i.i, align 8, !dbg !42547, !noalias !41867
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.sroa.6.i.i.i), !dbg !42544
  %149 = getelementptr inbounds nuw i8, ptr %output.i.i.i, i64 48, !dbg !42550
  store i64 0, ptr %149, align 8, !dbg !42550, !alias.scope !42555, !noalias !42477
  %150 = getelementptr inbounds nuw i8, ptr %output.i.i.i, i64 40, !dbg !42560
  %_8.i.i46 = load ptr, ptr %150, align 8, !dbg !42560, !alias.scope !42555, !noalias !42477, !nonnull !37, !noundef !37
  %151 = getelementptr inbounds nuw i8, ptr %output.i.i.i, i64 56, !dbg !42563
  %_6.i.i47 = load i64, ptr %151, align 8, !dbg !42563, !alias.scope !42555, !noalias !42477, !noundef !37
  %_110.not.i.i.i = icmp ugt i64 %_38.i.i.i, %_6.i.i47
  br i1 %_110.not.i.i.i, label %bb71.i.i.i, label %bb69.i.i.i, !dbg !42565, !prof !11657

cleanup13.i.i.i:                                  ; preds = %bb89.i.i.i
  %lpad.thr_comm.split-lp.i.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i, !dbg !42545

bb69.i.i.i:                                       ; preds = %bb68.i.i.i
  %switch.i.i.i = icmp eq i64 %_10.i.i.i, 0, !dbg !42574
  br i1 %switch.i.i.i, label %bb16.i.i.i, label %bb15.i.i.i, !dbg !42574

bb71.i.i.i:                                       ; preds = %bb68.i.i.i
; invoke core::slice::index::slice_index_fail
  invoke void @_RNvNtNtCslWxY2MhVcag_4core5slice5index16slice_index_fail(i64 noundef 0, i64 noundef %_38.i.i.i, i64 noundef %_6.i.i47, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_c36786f282933a289f505b54550b5c03) #22
          to label %unreachable.i.i.i unwind label %bb50.i.i.i, !dbg !42576, !noalias !42477

bb15.i.i.i:                                       ; preds = %bb69.i.i.i
  %_128116.i.i.i = icmp samesign eq i64 %_38.i.i.i, 0, !dbg !42577
  br i1 %_128116.i.i.i, label %bb20.i.i.i, label %bb19.preheader.i.i.i, !dbg !42586

bb19.preheader.i.i.i:                             ; preds = %bb15.i.i.i
  call void @llvm.memset.p0.i64(ptr nonnull align 1 %_8.i.i46, i8 0, i64 %_38.i.i.i, i1 false), !dbg !42587, !noalias !42477
  br label %bb20.i.i.i, !dbg !42591

bb16.i.i.i:                                       ; preds = %bb69.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_47.i.i.i), !dbg !42592, !noalias !41867
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_47.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %source.i.i.i, i64 56, i1 false), !dbg !42592, !noalias !41867
  %152 = invoke fastcc noundef zeroext i1 @_RINvYINtNtCshZi9mpuUhIi_4rofl5tuple11TupleSourceTINtB6_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBL_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels8map_into16IndexedSourceExt16map_checked_intobbNCINvMNtNtB8_7execute5ownedINtB3m_7ExecuteBY_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3F_INtNtB8_7visitor10RowVisitorBY_E19visit_deferred_boolB57_bKB4T_NCINvXs1_B40_B3X_INtB5r_5RowFnBY_E8dispatchB3F_Es4_0NCB6r_s5_0E0NCB5g_s_0B7f_E0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(56) %_47.i.i.i, ptr noalias nofree noundef nonnull %_8.i.i46, i64 noundef %_38.i.i.i)
          to label %bb22.i.i.i unwind label %bb50.i.i.i, !dbg !42593

bb22.i.i.i:                                       ; preds = %bb16.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_47.i.i.i), !dbg !42594, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_67.i.i.i), !dbg !42595, !noalias !41867
  br i1 %152, label %bb1.i42.i.i.i, label %bb89.i.i.i, !dbg !42597, !prof !11822

bb1.i42.i.i.i:                                    ; preds = %bb87.i.i.i, %bb22.i.i.i
; invoke rofl_examples::functions::row_error::<vortex_array::scalar_fn::unstable::rofl::VortexHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(address) dereferenceable(80) %_67.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb23.i.i.i unwind label %bb50.i.i.i, !dbg !42599, !noalias !42477

bb20.i.i.i:                                       ; preds = %bb19.preheader.i.i.i, %bb15.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %failure6.i.i.i), !dbg !42591, !noalias !41867
  store i8 0, ptr %failure6.i.i.i, align 1, !dbg !42600, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_56.i.i.i), !dbg !42601, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_60.i.i.i), !dbg !42603, !noalias !41867
  store ptr %prepared.i.i.i, ptr %_60.i.i.i, align 8, !dbg !42603, !noalias !41867
  %153 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 8, !dbg !42603
  store ptr %prepared.i.i.i, ptr %153, align 8, !dbg !42603, !noalias !41867
  %154 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 16, !dbg !42603
  store ptr %source.i.i.i, ptr %154, align 8, !dbg !42603, !noalias !41867
  %155 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 24, !dbg !42603
  store ptr %_8.i.i46, ptr %155, align 8, !dbg !42603, !noalias !41867
  %156 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 32, !dbg !42603
  store i64 %_38.i.i.i, ptr %156, align 8, !dbg !42603, !noalias !41867
  %157 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 40, !dbg !42603
  store ptr %failure6.i.i.i, ptr %157, align 8, !dbg !42603, !noalias !41867
  %158 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 8, !dbg !42601
  %self.val29.i.i.i = load ptr, ptr %158, align 8, !dbg !42601, !alias.scope !41862, !noalias !41897
  invoke fastcc void @_RINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostNCINvMNtB2_5ownedINtB2_7ExecuteBK_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2b_INtNtB4_7visitor10RowVisitorBK_E19visit_deferred_boolB3C_bKB3o_NCINvXs1_B2v_B2s_INtB3W_5RowFnBK_E8dispatchB2b_Es4_0NCB4W_s5_0E0NCB3L_s_0B5K_Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 captures(address) dereferenceable(80) %_56.i.i.i, i64 %_10.i.i.i, ptr %self.val29.i.i.i, i64 noundef %_32.i.i.i, i64 noundef %_38.i.i.i, ptr noalias nofree noundef align 8 captures(address) dereferenceable(48) %_60.i.i.i)
          to label %bb21.i.i.i unwind label %bb50.i.i.i, !dbg !42601, !noalias !42477

bb21.i.i.i:                                       ; preds = %bb20.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_60.i.i.i), !dbg !42604, !noalias !41867
  %159 = load i64, ptr %_56.i.i.i, align 8, !dbg !42605, !range !1887, !noalias !41867, !noundef !37
  %.not22.i.i.i = icmp eq i64 %159, -1, !dbg !42605
  br i1 %.not22.i.i.i, label %bb87.i.i.i, label %bb86.i.i.i, !dbg !42607

bb86.i.i.i:                                       ; preds = %bb21.i.i.i
  %160 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42608
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %160, ptr noundef nonnull align 8 dereferenceable(80) %_56.i.i.i, i64 80, i1 false), !dbg !42614, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %_56.i.i.i), !dbg !42615, !noalias !41867
  store i64 1, ptr %_0, align 8, !dbg !42608, !alias.scope !41891, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %failure6.i.i.i), !dbg !42616, !noalias !41867
  br label %bb29.i.i.i, !dbg !42617

bb87.i.i.i:                                       ; preds = %bb21.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_56.i.i.i), !dbg !42615, !noalias !41867
  %161 = load i8, ptr %failure6.i.i.i, align 1, !dbg !42619, !range !168, !noalias !41867, !noundef !37
  call void @llvm.lifetime.end.p0(ptr nonnull %failure6.i.i.i), !dbg !42616, !noalias !41867
  %extract.t.i.i.i = trunc nuw i8 %161 to i1, !dbg !42616
  call void @llvm.lifetime.start.p0(ptr nonnull %_67.i.i.i), !dbg !42595, !noalias !41867
  br i1 %extract.t.i.i.i, label %bb1.i42.i.i.i, label %bb89.i.i.i, !dbg !42597, !prof !11822

bb23.i.i.i:                                       ; preds = %bb1.i42.i.i.i
  %.pr.i.i.i = load i64, ptr %_67.i.i.i, align 8, !dbg !42620, !noalias !41867
  %.not24.i.i.i = icmp eq i64 %.pr.i.i.i, -1, !dbg !42620
  br i1 %.not24.i.i.i, label %bb89.i.i.i, label %bb88.i.i.i, !dbg !42622

bb88.i.i.i:                                       ; preds = %bb23.i.i.i
  %162 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42623
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %162, ptr noundef nonnull align 8 dereferenceable(80) %_67.i.i.i, i64 80, i1 false), !dbg !42629, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %_67.i.i.i), !dbg !42630, !noalias !41867
  store i64 1, ptr %_0, align 8, !dbg !42623, !alias.scope !41891, !noalias !41889
  br label %bb29.i.i.i, !dbg !42631

bb89.i.i.i:                                       ; preds = %bb23.i.i.i, %bb87.i.i.i, %bb22.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_67.i.i.i), !dbg !42630, !noalias !41867
  call void @llvm.lifetime.start.p0(ptr nonnull %_73.i.i.i), !dbg !42633, !noalias !41867
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(88) %_73.i.i.i, ptr noundef nonnull align 8 dereferenceable(88) %output.i.i.i, i64 88, i1 false), !dbg !42633, !noalias !41867
; invoke <vortex_array::scalar_fn::unstable::rofl::output::VortexBuffer<bool> as rofl::output::OutputBuffer<bool>>::finish
  %163 = invoke { ptr, ptr } @_RNvXNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6outputINtB2_12VortexBufferbEINtNtCshZi9mpuUhIi_4rofl6output12OutputBufferbE6finishCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(88) %_73.i.i.i, i64 noundef %_38.i.i.i)
          to label %bb24.i.i.i unwind label %cleanup13.i.i.i, !dbg !42634, !noalias !42477

bb24.i.i.i:                                       ; preds = %bb89.i.i.i
  %_72.0.i.i.i = extractvalue { ptr, ptr } %163, 0, !dbg !42633
  %_72.1.i.i.i = extractvalue { ptr, ptr } %163, 1, !dbg !42633
  call void @llvm.lifetime.end.p0(ptr nonnull %_73.i.i.i), !dbg !42635, !noalias !41867
  %_71.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42636
  store ptr %_72.0.i.i.i, ptr %_71.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !42636, !alias.scope !41891, !noalias !41889
  %_71.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !42636
  store ptr %_72.1.i.i.i, ptr %_71.sroa.5.0..sroa_idx.i.i.i, align 8, !dbg !42636, !alias.scope !41891, !noalias !41889
  store <2 x i64> <i64 0, i64 -9223372036854775780>, ptr %_0, align 8, !dbg !42636, !alias.scope !41891, !noalias !41889
  call void @llvm.lifetime.end.p0(ptr nonnull %output.i.i.i), !dbg !42545, !noalias !41867
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i.i), !dbg !42546, !noalias !41867
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>, rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(80) %columns.i.i.i)
          to label %bb27.i.i.i unwind label %bb42.thread112.i.i.i, !dbg !42494, !noalias !42477

bb27.i.i.i:                                       ; preds = %bb24.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i), !dbg !42494, !noalias !41867
  %164 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 16, !dbg !42637
  %165 = load i8, ptr %164, align 8, !dbg !42639, !range !1916, !alias.scope !42641, !noalias !41897, !noundef !37
  %166 = icmp eq i8 %165, -1, !dbg !42639
  br i1 %166, label %bb3.i.i, label %bb2.i.i44.i.i.i, !dbg !42639

bb2.i.i44.i.i.i:                                  ; preds = %bb27.i.i.i
; call core::ptr::drop_glue::<vortex_array::dtype::DType>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %164), !dbg !42639, !noalias !41853
  br label %bb3.i.i, !dbg !42639

bb29.i.i.i:                                       ; preds = %bb88.i.i.i, %bb86.i.i.i
; invoke core::ptr::drop_glue::<vortex_array::scalar_fn::unstable::rofl::output::VortexBuffer<i8>>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6output12VortexBufferaEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(88) %output.i.i.i)
          to label %bb30.i.i.i unwind label %cleanup12.i.i.i, !dbg !42545, !noalias !42477

bb30.i.i.i:                                       ; preds = %bb29.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %output.i.i.i), !dbg !42545, !noalias !41867
  br label %bb31.i.i.i, !dbg !42546

bb31.i.i.i:                                       ; preds = %bb30.i.i.i, %bb67.i.i.i, %bb65.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i.i), !dbg !42546, !noalias !41867
  call void @llvm.experimental.noalias.scope.decl(metadata !42646), !dbg !42494
  call void @llvm.experimental.noalias.scope.decl(metadata !42649), !dbg !42652
  call void @llvm.experimental.noalias.scope.decl(metadata !42654), !dbg !42657
  %167 = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 16, !dbg !42659
  call void @llvm.experimental.noalias.scope.decl(metadata !42661), !dbg !42659
  %168 = load ptr, ptr %167, align 8, !dbg !42664, !alias.scope !42666, !noalias !41867, !noundef !37
  %169 = icmp eq ptr %168, null, !dbg !42664
  br i1 %169, label %bb4.i45.i.i.i, label %bb2.i.i.i.i.i.i.i, !dbg !42664

bb2.i.i.i.i.i.i.i:                                ; preds = %bb31.i.i.i
  %_2.i.i.i.i.i.i.i.i.i = atomicrmw sub ptr %168, i64 1 release, align 8, !dbg !42667, !noalias !42672
  %170 = icmp eq i64 %_2.i.i.i.i.i.i.i.i.i, 1, !dbg !42677
  br i1 %170, label %bb2.i.i.i.i.i.i.i.i.i, label %bb4.i45.i.i.i, !dbg !42677

bb2.i.i.i.i.i.i.i.i.i:                            ; preds = %bb2.i.i.i.i.i.i.i
  fence acquire, !dbg !42678
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %167) #23
          to label %bb4.i45.i.i.i unwind label %cleanup.i46.i.i.i, !dbg !42680, !noalias !42477

cleanup.i46.i.i.i:                                ; preds = %bb2.i.i.i.i.i.i.i.i.i
  %171 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !42681), !dbg !42652
  call void @llvm.experimental.noalias.scope.decl(metadata !42684), !dbg !42687
  %172 = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 56, !dbg !42689
  call void @llvm.experimental.noalias.scope.decl(metadata !42691), !dbg !42689
  %173 = load ptr, ptr %172, align 8, !dbg !42694, !alias.scope !42696, !noalias !41867, !noundef !37
  %174 = icmp eq ptr %173, null, !dbg !42694
  br i1 %174, label %bb60.i.i.i, label %bb2.i.i.i1.i.i.i.i, !dbg !42694

bb2.i.i.i1.i.i.i.i:                               ; preds = %cleanup.i46.i.i.i
  %_2.i.i.i.i.i2.i.i.i.i = atomicrmw sub ptr %173, i64 1 release, align 8, !dbg !42697, !noalias !42702
  %175 = icmp eq i64 %_2.i.i.i.i.i2.i.i.i.i, 1, !dbg !42707
  br i1 %175, label %bb2.i.i.i.i.i3.i.i.i.i, label %bb60.i.i.i, !dbg !42707

bb2.i.i.i.i.i3.i.i.i.i:                           ; preds = %bb2.i.i.i1.i.i.i.i
  fence acquire, !dbg !42708
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %172) #23
          to label %bb60.i.i.i unwind label %terminate.i48.i.i.i, !dbg !42710, !noalias !42477

bb4.i45.i.i.i:                                    ; preds = %bb2.i.i.i.i.i.i.i.i.i, %bb2.i.i.i.i.i.i.i, %bb31.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !42711), !dbg !42652
  call void @llvm.experimental.noalias.scope.decl(metadata !42714), !dbg !42717
  %176 = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 56, !dbg !42719
  call void @llvm.experimental.noalias.scope.decl(metadata !42721), !dbg !42719
  %177 = load ptr, ptr %176, align 8, !dbg !42724, !alias.scope !42726, !noalias !41867, !noundef !37
  %178 = icmp eq ptr %177, null, !dbg !42724
  br i1 %178, label %bb33.i.i.i, label %bb2.i.i.i6.i.i.i.i, !dbg !42724

bb2.i.i.i6.i.i.i.i:                               ; preds = %bb4.i45.i.i.i
  %_2.i.i.i.i.i7.i.i.i.i = atomicrmw sub ptr %177, i64 1 release, align 8, !dbg !42727, !noalias !42732
  %179 = icmp eq i64 %_2.i.i.i.i.i7.i.i.i.i, 1, !dbg !42737
  br i1 %179, label %bb2.i.i.i.i.i8.i.i.i.i, label %bb33.i.i.i, !dbg !42737

bb2.i.i.i.i.i8.i.i.i.i:                           ; preds = %bb2.i.i.i6.i.i.i.i
  fence acquire, !dbg !42738
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %176) #23
          to label %bb33.i.i.i unwind label %bb42.thread112.i.i.i, !dbg !42740, !noalias !42477

terminate.i48.i.i.i:                              ; preds = %bb2.i.i.i.i.i3.i.i.i.i
  %180 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !42652, !noalias !42477
  unreachable, !dbg !42652

unreachable.i.i.i:                                ; preds = %bb71.i.i.i
  unreachable

bb50.i.i.i:                                       ; preds = %bb20.i.i.i, %bb1.i42.i.i.i, %bb16.i.i.i, %bb71.i.i.i
  %lpad.thr_comm.i.i.i = landingpad { ptr, i32 }
          cleanup
; invoke core::ptr::drop_glue::<vortex_array::scalar_fn::unstable::rofl::output::VortexBuffer<i8>>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6output12VortexBufferaEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(88) %output.i.i.i) #21
          to label %bb39.i.i.i unwind label %terminate.i.i.i, !dbg !42545, !noalias !42477

terminate.i.i.i:                                  ; preds = %bb2.i.i55.i.i.i, %bb39.i.i.i, %bb50.i.i.i
  %181 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !42741, !noalias !42742
  unreachable, !dbg !42741

bb33.i.i.i:                                       ; preds = %bb2.i.i.i.i.i8.i.i.i.i, %bb2.i.i.i6.i.i.i.i, %bb4.i45.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i), !dbg !42494, !noalias !41867
  br label %bb49.critedge.i.i.i, !dbg !42494

bb39.i.i.i:                                       ; preds = %bb50.i.i.i, %cleanup13.i.i.i, %cleanup12.i.i.i, %cleanup11.i.i.i, %cleanup10.i.i.i
  %.pn.i.i.i = phi { ptr, i32 } [ %144, %cleanup12.i.i.i ], [ %lpad.thr_comm.i.i.i, %bb50.i.i.i ], [ %lpad.thr_comm.split-lp.i.i.i, %cleanup13.i.i.i ], [ %139, %cleanup11.i.i.i ], [ %137, %cleanup10.i.i.i ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>, rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(80) %columns.i.i.i) #21
          to label %bb60.i.i.i unwind label %terminate.i.i.i, !dbg !42494, !noalias !42477

bb49.critedge.i.i.i:                              ; preds = %bb33.i.i.i, %bb8.i.i.i, %bb63.i.i.i, %bb61.i.i.i
  %182 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 16, !dbg !42743
  %183 = load i8, ptr %182, align 8, !dbg !42745, !range !1916, !alias.scope !42747, !noalias !41897, !noundef !37
  %184 = icmp eq i8 %183, -1, !dbg !42745
  br i1 %184, label %bb3.i.i, label %bb2.i.i53.i.i.i, !dbg !42745

bb2.i.i53.i.i.i:                                  ; preds = %bb49.critedge.i.i.i
; call core::ptr::drop_glue::<vortex_array::dtype::DType>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %182), !dbg !42745, !noalias !41853
  br label %bb3.i.i, !dbg !42745

bb42.thread112.i.i.i:                             ; preds = %panic3.i41.invoke, %bb2.i.i.i.i.i8.i.i.i.i, %bb24.i.i.i, %bb4.i30.i.i.i, %bb2.i.i
  %lpad.thr_comm110.i.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb60.i.i.i, !dbg !42494

bb60.i.i.i:                                       ; preds = %bb42.thread112.i.i.i, %bb39.i.i.i, %bb2.i.i.i.i.i3.i.i.i.i, %bb2.i.i.i1.i.i.i.i, %cleanup.i46.i.i.i
  %.pn27104.i.i.i = phi { ptr, i32 } [ %lpad.thr_comm110.i.i.i, %bb42.thread112.i.i.i ], [ %171, %cleanup.i46.i.i.i ], [ %171, %bb2.i.i.i1.i.i.i.i ], [ %171, %bb2.i.i.i.i.i3.i.i.i.i ], [ %.pn.i.i.i, %bb39.i.i.i ]
  %185 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 16, !dbg !42752
  %186 = load i8, ptr %185, align 8, !dbg !42754, !range !1916, !alias.scope !42756, !noalias !41897, !noundef !37
  %187 = icmp eq i8 %186, -1, !dbg !42754
  br i1 %187, label %bb36.i.i, label %bb2.i.i55.i.i.i, !dbg !42754

bb2.i.i55.i.i.i:                                  ; preds = %bb60.i.i.i
; invoke core::ptr::drop_glue::<vortex_array::dtype::DType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %185)
          to label %bb36.i.i unwind label %terminate.i.i.i, !dbg !42754, !noalias !42742

bb3.i.i:                                          ; preds = %bb2.i.i53.i.i.i, %bb49.critedge.i.i.i, %bb2.i.i44.i.i.i, %bb27.i.i.i, %bb5.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_17.sroa.6.sroa.0.sroa.9.i.i.i), !dbg !42761
  call void @llvm.lifetime.end.p0(ptr nonnull %_17.sroa.6.sroa.9.i.i.i), !dbg !42761
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i.i), !dbg !42762, !noalias !41857
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB30_NCINvYBG_B35_19visit_deferred_boolB45_bKB30_NCINvXs1_B27_B24_INtB38_5RowFnBU_E8dispatchBG_Es4_0NCB50_s5_0E0NCB4i_s_0B5N_ECskkDzpO6M0zw_10boundaries.exit, !dbg !42763

bb4.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_11.i.i), !dbg !42765, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %_13.i.i), !dbg !42766, !noalias !41857
  %188 = getelementptr inbounds nuw i8, ptr %_13.i.i, i64 1, !dbg !42767
  store i8 0, ptr %188, align 1, !dbg !42767, !alias.scope !42770, !noalias !41857
  store i8 1, ptr %_13.i.i, align 8, !dbg !42767, !alias.scope !42770, !noalias !41857
; invoke <rofl::execute::Execute<vortex_array::scalar_fn::unstable::rofl::VortexHost, rofl_examples::functions::PositiveSum<true>>>::validate::<(i64, i64)>
  invoke fastcc void @_RINvMs_NtCshZi9mpuUhIi_4rofl7executeINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8validateTxxEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 captures(address) dereferenceable(80) %_11.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(104) %self, ptr noalias nofree noundef align 8 captures(address) dereferenceable(24) %_13.i.i)
          to label %bb5.i.i unwind label %bb35.thread189.i.i, !dbg !42773

bb5.i.i:                                          ; preds = %bb4.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i), !dbg !42774, !noalias !41857
  %189 = load i64, ptr %_11.i.i, align 8, !dbg !42775, !range !1887, !noalias !41857, !noundef !37
  %.not.i.i = icmp eq i64 %189, -1, !dbg !42775
  br i1 %.not.i.i, label %bb48.i.i, label %bb47.i.i, !dbg !42778

bb47.i.i:                                         ; preds = %bb5.i.i
  %190 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42779
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %190, ptr noundef nonnull align 8 dereferenceable(80) %_11.i.i, i64 80, i1 false), !dbg !42786, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i), !dbg !42787, !noalias !41857
  store i64 1, ptr %_0, align 8, !dbg !42779, !alias.scope !41854, !noalias !41853
  br label %bb39.critedge.i.i, !dbg !42763

bb48.i.i:                                         ; preds = %bb5.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i), !dbg !42787, !noalias !41857
  %_15.i.i = load i64, ptr %self, align 8, !dbg !42788, !range !5768, !alias.scope !41853, !noalias !41854, !noundef !37
  %191 = icmp eq i64 %_15.i.i, 1, !dbg !42791
  br i1 %191, label %bb7.i.i, label %bb9.i.i, !dbg !42791

bb7.i.i:                                          ; preds = %bb48.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_16.i.i), !dbg !42792, !noalias !41857
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(104) %_16.i.i, ptr noundef nonnull align 8 dereferenceable(104) %self, i64 104, i1 false), !dbg !42792, !noalias !41854
  call void @llvm.experimental.noalias.scope.decl(metadata !42793), !dbg !42796
  call void @llvm.experimental.noalias.scope.decl(metadata !42797), !dbg !42796
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.5.sroa.0.sroa.8.i.i.i), !dbg !42799
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.5.sroa.8.i.i.i), !dbg !42799
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i35.i.i), !dbg !42799, !noalias !42802
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.sroa.13.i.i.i), !dbg !42803
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.sroa.17.i.i.i), !dbg !42803
  call void @llvm.experimental.noalias.scope.decl(metadata !42804), !dbg !42807
  %_3.i.i.i.i = load i64, ptr %_16.i.i, align 8, !dbg !42808, !range !5768, !alias.scope !42810, !noalias !42811, !noundef !37
  %tolerant.i.i36.i.i = icmp eq i64 %_3.i.i.i.i, 2, !dbg !42813
  br i1 %tolerant.i.i36.i.i, label %bb1.i.i78.i.i, label %start.bb4_crit_edge.i.i37.i.i, !dbg !42814

start.bb4_crit_edge.i.i37.i.i:                    ; preds = %bb7.i.i
  %.phi.trans.insert.i.i38.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 40
  %_11.0.pre.i.i39.i.i = load ptr, ptr %.phi.trans.insert.i.i38.i.i, align 8, !dbg !42815, !alias.scope !42810, !noalias !42811
  %.phi.trans.insert4.i.i40.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 48
  %_11.1.pre.i.i41.i.i = load i64, ptr %.phi.trans.insert4.i.i40.i.i, align 8, !dbg !42815, !alias.scope !42810, !noalias !42811
  br label %bb4.i.i42.i.i, !dbg !42814

bb4.i.i42.i.i:                                    ; preds = %bb11.i.i83.i.i, %start.bb4_crit_edge.i.i37.i.i
  %_11.1.i.i43.i.i = phi i64 [ %_11.1.pre.i.i41.i.i, %start.bb4_crit_edge.i.i37.i.i ], [ %_10.1.i.i80.i.i, %bb11.i.i83.i.i ], !dbg !42815
  %_11.0.i.i44.i.i = phi ptr [ %_11.0.pre.i.i39.i.i, %start.bb4_crit_edge.i.i37.i.i ], [ %_10.0.i.i79.i.i, %bb11.i.i83.i.i ], !dbg !42815
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i33.i.i), !dbg !42816, !noalias !42817
  %192 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 80, !dbg !42818
  %_12.i.i45.i.i = load ptr, ptr %192, align 8, !dbg !42818, !alias.scope !42810, !noalias !42811, !nonnull !37, !align !40, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([88 x i8]) align 8 captures(none) dereferenceable(88) %_9.i.i33.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i44.i.i, i64 noundef %_11.1.i.i43.i.i, i1 noundef zeroext %tolerant.i.i36.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i45.i.i)
          to label %.noexc.i.i.i unwind label %cleanup.i.i.i, !dbg !42816, !noalias !42819

.noexc.i.i.i:                                     ; preds = %bb4.i.i42.i.i
  %_20.i.i48.i.i = load i64, ptr %_9.i.i33.i.i, align 8, !dbg !42820, !range !4730, !noalias !42817, !noundef !37
  %193 = trunc nuw i64 %_20.i.i48.i.i to i1, !dbg !42822
  %194 = getelementptr inbounds nuw i8, ptr %_9.i.i33.i.i, i64 8, !dbg !42823
  %_9.sroa.7.8.copyload62.i.i.i = load i64, ptr %194, align 8, !dbg !42823, !noalias !42824
  %_9.sroa.12.8..sroa_idx65.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i33.i.i, i64 16, !dbg !42823
  %_9.sroa.12.8.copyload66.i.i.i = load i8, ptr %_9.sroa.12.8..sroa_idx65.i.i.i, align 8, !dbg !42823, !noalias !42824
  %_9.sroa.13.8..sroa_idx69.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i33.i.i, i64 17, !dbg !42823
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.13.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.13.8..sroa_idx69.i.i.i, i64 23, i1 false), !dbg !42823, !noalias !42824
  %_9.sroa.14.8..sroa_idx70.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i33.i.i, i64 40, !dbg !42823
  %_9.sroa.14.8.copyload71.i.i.i = load i8, ptr %_9.sroa.14.8..sroa_idx70.i.i.i, align 8, !dbg !42823, !noalias !42824
  %_9.sroa.17.8..sroa_idx72.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i33.i.i, i64 41, !dbg !42823
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_9.sroa.17.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_9.sroa.17.8..sroa_idx72.i.i.i, i64 47, i1 false), !dbg !42823, !noalias !42824
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i33.i.i), !dbg !42825, !noalias !42817
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.5.sroa.0.sroa.8.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.13.i.i.i, i64 23, i1 false), !dbg !42826, !noalias !42802
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_8.sroa.5.sroa.8.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_9.sroa.17.i.i.i, i64 47, i1 false), !dbg !42826, !noalias !42802
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.13.i.i.i), !dbg !42829
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.17.i.i.i), !dbg !42829
  br i1 %193, label %bb43.i77.i.i, label %bb44.i.i.i, !dbg !42822

bb1.i.i78.i.i:                                    ; preds = %bb7.i.i
  %195 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 48, !dbg !42830
  %_10.1.i.i80.i.i = load i64, ptr %195, align 8, !dbg !42830, !alias.scope !42810, !noalias !42811, !noundef !37
  %switch139 = icmp ult i64 %_10.1.i.i80.i.i, 2, !dbg !42831
  br i1 %switch139, label %panic3.i48.invoke, label %bb11.i.i83.i.i, !dbg !42831

panic3.i48.invoke:                                ; preds = %bb1.i.i78.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i80.i.i, i64 noundef %_10.1.i.i80.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i48.cont unwind label %cleanup.i.i.i, !dbg !42831

panic3.i48.cont:                                  ; preds = %panic3.i48.invoke
  unreachable

bb11.i.i83.i.i:                                   ; preds = %bb1.i.i78.i.i
  %196 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 40, !dbg !42830
  %_10.0.i.i79.i.i = load ptr, ptr %196, align 8, !dbg !42830, !alias.scope !42810, !noalias !42811, !nonnull !37, !align !40, !noundef !37
  br label %bb4.i.i42.i.i, !dbg !42833

cleanup.i.i.i:                                    ; preds = %panic3.i48.invoke, %bb2.i.i.i.i.i8.i45.i.i.i, %bb2.i.i.i.i.i8.i.i65.i.i, %bb45.i.i.i, %bb4.i.i42.i.i
  %197 = landingpad { ptr, i32 }
          cleanup
  br label %bb27.i46.i.i

bb43.i77.i.i:                                     ; preds = %.noexc.i.i.i
  %_63.sroa.0.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !42834
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_63.sroa.0.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.5.sroa.0.sroa.8.i.i.i, i64 23, i1 false), !dbg !42829, !noalias !42841
  %_63.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 41, !dbg !42834
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_63.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_8.sroa.5.sroa.8.i.i.i, i64 47, i1 false), !dbg !42829, !noalias !42841
  br label %bb16.i76.i.i, !dbg !42842

bb44.i.i.i:                                       ; preds = %.noexc.i.i.i
  %.not.i49.i.i = icmp eq i8 %_9.sroa.14.8.copyload71.i.i.i, 2, !dbg !42844
  br i1 %.not.i49.i.i, label %bb45.i.i.i, label %bb46.i.i.i, !dbg !42847

bb46.i.i.i:                                       ; preds = %bb44.i.i.i
  %val2.sroa.0.sroa.5.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 9, !dbg !42848
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val2.sroa.0.sroa.5.0.columns.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.5.sroa.0.sroa.8.i.i.i, i64 23, i1 false), !dbg !42803, !noalias !42802
  %val2.sroa.5.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 33, !dbg !42848
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %val2.sroa.5.0.columns.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_8.sroa.5.sroa.8.i.i.i, i64 47, i1 false), !dbg !42803, !noalias !42802
  store i64 %_9.sroa.7.8.copyload62.i.i.i, ptr %columns.i35.i.i, align 8, !dbg !42848, !noalias !42802
  %val2.sroa.0.sroa.4.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 8, !dbg !42848
  store i8 %_9.sroa.12.8.copyload66.i.i.i, ptr %val2.sroa.0.sroa.4.0.columns.sroa_idx.i.i.i, align 8, !dbg !42848, !noalias !42802
  %val2.sroa.4.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 32, !dbg !42848
  store i8 %_9.sroa.14.8.copyload71.i.i.i, ptr %val2.sroa.4.0.columns.sroa_idx.i.i.i, align 8, !dbg !42848, !noalias !42802
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.i.i.i), !dbg !42851, !noalias !42802
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_18.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i35.i.i)
          to label %bb4.i51.i.i unwind label %cleanup5.i.i.i, !dbg !42851, !noalias !42819

bb45.i.i.i:                                       ; preds = %bb44.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_61.i.i.i), !dbg !42853, !noalias !42802
; invoke <vortex_array::scalar_fn::unstable::rofl::VortexHost as rofl::host::Host>::error
  invoke void @_RNvXNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4roflNtB2_10VortexHostNtNtCshZi9mpuUhIi_4rofl4host4Host5error(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(address) dereferenceable(80) %_61.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_90e3c4e2332b77b0fece2c0e180e7e89, i64 noundef 27)
          to label %bb47.i.i.i unwind label %cleanup.i.i.i, !dbg !42854, !noalias !42819

bb47.i.i.i:                                       ; preds = %bb45.i.i.i
  %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.i = load i64, ptr %_61.i.i.i, align 8, !dbg !42857, !noalias !42802
  %_7.sroa.6.sroa.0.sroa.8.0._61.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_61.i.i.i, i64 8, !dbg !42857
  %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.i = load i8, ptr %_7.sroa.6.sroa.0.sroa.8.0._61.sroa_idx.i.i.i, align 8, !dbg !42857, !noalias !42802
  %_7.sroa.6.sroa.0.sroa.9.0._61.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_61.i.i.i, i64 9, !dbg !42857
  %_69.sroa.0.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !42858
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_69.sroa.0.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_7.sroa.6.sroa.0.sroa.9.0._61.sroa_idx.i.i.i, i64 23, i1 false), !dbg !42857, !noalias !42841
  %_7.sroa.6.sroa.8.0._61.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_61.i.i.i, i64 32, !dbg !42857
  %_7.sroa.6.sroa.8.0.copyload.i.i.i = load i8, ptr %_7.sroa.6.sroa.8.0._61.sroa_idx.i.i.i, align 8, !dbg !42857, !noalias !42802
  %_7.sroa.6.sroa.9.0._61.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_61.i.i.i, i64 33, !dbg !42857
  %_69.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 41, !dbg !42858
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_69.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_7.sroa.6.sroa.9.0._61.sroa_idx.i.i.i, i64 47, i1 false), !dbg !42857, !noalias !42841
  call void @llvm.lifetime.end.p0(ptr nonnull %_61.i.i.i), !dbg !42864, !noalias !42802
  br label %bb16.i76.i.i, !dbg !42865

bb16.i76.i.i:                                     ; preds = %bb47.i.i.i, %bb43.i77.i.i
  %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.sink.i = phi i64 [ %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.i, %bb47.i.i.i ], [ %_9.sroa.7.8.copyload62.i.i.i, %bb43.i77.i.i ]
  %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.sink.i = phi i8 [ %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.i, %bb47.i.i.i ], [ %_9.sroa.12.8.copyload66.i.i.i, %bb43.i77.i.i ]
  %_7.sroa.6.sroa.8.0.copyload.i.i.sink.i = phi i8 [ %_7.sroa.6.sroa.8.0.copyload.i.i.i, %bb47.i.i.i ], [ %_9.sroa.14.8.copyload71.i.i.i, %bb43.i77.i.i ]
  %198 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42866
  store i64 %_7.sroa.6.sroa.0.sroa.0.0.copyload.i.i.sink.i, ptr %198, align 8, !dbg !42866, !alias.scope !42868, !noalias !42841
  %_69.sroa.0.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42866
  store i8 %_7.sroa.6.sroa.0.sroa.8.0.copyload.i.i.sink.i, ptr %_69.sroa.0.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !42866, !alias.scope !42868, !noalias !42841
  %_69.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !42866
  store i8 %_7.sroa.6.sroa.8.0.copyload.i.i.sink.i, ptr %_69.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !42866, !alias.scope !42868, !noalias !42841
  store i64 1, ptr %_0, align 8, !dbg !42869, !alias.scope !42868, !noalias !42841
  br label %bb19.i.i.i, !dbg !42871

cleanup5.i.i.i:                                   ; preds = %bb46.i.i.i
  %199 = landingpad { ptr, i32 }
          cleanup
  br label %bb25.i.i.i, !dbg !42872

bb4.i51.i.i:                                      ; preds = %bb46.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.i.i.i), !dbg !42872, !noalias !42802
  call void @llvm.lifetime.start.p0(ptr nonnull %_20.sroa.6.i.i.i), !dbg !42873
  call void @llvm.lifetime.start.p0(ptr nonnull %_21.i.i.i), !dbg !42873, !noalias !42802
  %200 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 88, !dbg !42875
  %_23.i.i.i = load i64, ptr %200, align 8, !dbg !42875, !alias.scope !42797, !noalias !42876, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(none) dereferenceable(80) %_21.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i35.i.i, i64 noundef %_23.i.i.i)
          to label %bb5.i52.i.i unwind label %cleanup6.i.i.i, !dbg !42873, !noalias !42819

cleanup6.i.i.i:                                   ; preds = %bb4.i51.i.i
  %201 = landingpad { ptr, i32 }
          cleanup
  br label %bb25.i.i.i

bb5.i52.i.i:                                      ; preds = %bb4.i51.i.i
  %202 = load i64, ptr %_21.i.i.i, align 8, !dbg !42877, !range !1887, !noalias !42802, !noundef !37
  %.not21.i53.i.i = icmp eq i64 %202, -1, !dbg !42877
  %203 = getelementptr inbounds nuw i8, ptr %_21.i.i.i, i64 8, !dbg !42880
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_20.sroa.6.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %203, i64 56, i1 false), !dbg !42880, !noalias !42802
  br i1 %.not21.i53.i.i, label %bb6.i56.i.i, label %bb48.i.i.i, !dbg !42881

bb48.i.i.i:                                       ; preds = %bb5.i52.i.i
  %_73.sroa.5.0._21.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_21.i.i.i, i64 64, !dbg !42882
  %_76.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 72, !dbg !42883
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %_76.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(16) %_73.sroa.5.0._21.sroa_idx.i.i.i, i64 16, i1 false), !dbg !42882, !noalias !42841
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.i.i.i), !dbg !42889, !noalias !42802
  %_76.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42883
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_76.sroa.4.0..sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_20.sroa.6.i.i.i, i64 56, i1 false), !dbg !42889, !noalias !42841
  %204 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42883
  store i64 %202, ptr %204, align 8, !dbg !42883, !alias.scope !42868, !noalias !42841
  store i64 1, ptr %_0, align 8, !dbg !42883, !alias.scope !42868, !noalias !42841
  call void @llvm.lifetime.end.p0(ptr nonnull %_20.sroa.6.i.i.i), !dbg !42890
  br label %bb15.i54.i.i, !dbg !42891

bb6.i56.i.i:                                      ; preds = %bb5.i52.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.i.i.i), !dbg !42889, !noalias !42802
  call void @llvm.lifetime.start.p0(ptr nonnull %state.i.i.i), !dbg !42892, !noalias !42802
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %state.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_20.sroa.6.i.i.i, i64 56, i1 false), !dbg !42873, !noalias !42802
  call void @llvm.lifetime.end.p0(ptr nonnull %_20.sroa.6.i.i.i), !dbg !42890
  %205 = getelementptr inbounds nuw i8, ptr %state.i.i.i, i64 56, !dbg !42894
  store i8 0, ptr %205, align 8, !dbg !42894, !noalias !42802
  call void @llvm.lifetime.start.p0(ptr nonnull %values.i.i.i), !dbg !42895, !noalias !42802
  call void @llvm.lifetime.start.p0(ptr nonnull %_35.i.i.i), !dbg !42899, !noalias !42802
  invoke void @_RINvXs1_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6outputNtB8_10VortexHostNtNtCshZi9mpuUhIi_4rofl6output13BooleanOutput12collect_boolKb1_NCINvMNtNtB1w_7execute11packed_boolINtB2B_7ExecuteB1b_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKB2q_EE15boolean_attemptTxxEubKB2q_NCINvYB32_INtNtB1w_7visitor10RowVisitorB1b_E19visit_deferred_boolB4E_bKB2q_NCINvXs1_B3o_B3l_INtB52_5RowFnB1b_E8dispatchB32_Es4_0NCB64_s5_0E0NCB4R_s_0B6T_Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(none) dereferenceable(80) %_35.i.i.i, i64 noundef %_23.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %state.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i45.i.i)
          to label %bb7.i.i.i unwind label %cleanup8.i.i.i, !dbg !42899, !noalias !42819

cleanup8.i.i.i:                                   ; preds = %bb2.i.i.i34.i.i.i, %bb6.i56.i.i
  %206 = landingpad { ptr, i32 }
          cleanup
  br label %bb25.i.i.i

bb7.i.i.i:                                        ; preds = %bb6.i56.i.i
  %207 = load i64, ptr %_35.i.i.i, align 8, !dbg !42900, !range !1887, !noalias !42802, !noundef !37
  %.not22.i57.i.i = icmp eq i64 %207, -1, !dbg !42900
  %208 = getelementptr inbounds nuw i8, ptr %_35.i.i.i, i64 8, !dbg !42903
  %_79.0.i.i.i = load ptr, ptr %208, align 8, !dbg !42903, !noalias !42802
  %209 = getelementptr inbounds nuw i8, ptr %_35.i.i.i, i64 16, !dbg !42903
  %_79.1.i.i.i = load ptr, ptr %209, align 8, !dbg !42903, !noalias !42802
  br i1 %.not22.i57.i.i, label %bb51.i.i.i, label %bb50.i58.i.i, !dbg !42904

bb50.i58.i.i:                                     ; preds = %bb7.i.i.i
  %_80.sroa.6.0._35.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_35.i.i.i, i64 24, !dbg !42905
  %_83.sroa.6.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !42906
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_83.sroa.6.0..sroa_idx.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_80.sroa.6.0._35.sroa_idx.i.i.i, i64 56, i1 false), !dbg !42905, !noalias !42841
  call void @llvm.lifetime.end.p0(ptr nonnull %_35.i.i.i), !dbg !42912, !noalias !42802
  %210 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42906
  store i64 %207, ptr %210, align 8, !dbg !42906, !alias.scope !42868, !noalias !42841
  %_83.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42906
  store ptr %_79.0.i.i.i, ptr %_83.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !42906, !alias.scope !42868, !noalias !42841
  %_83.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !42906
  store ptr %_79.1.i.i.i, ptr %_83.sroa.5.0..sroa_idx.i.i.i, align 8, !dbg !42906, !alias.scope !42868, !noalias !42841
  store i64 1, ptr %_0, align 8, !dbg !42906, !alias.scope !42868, !noalias !42841
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i.i), !dbg !42913, !noalias !42802
  call void @llvm.lifetime.end.p0(ptr nonnull %state.i.i.i), !dbg !42914, !noalias !42802
  br label %bb15.i54.i.i, !dbg !42891

bb51.i.i.i:                                       ; preds = %bb7.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_35.i.i.i), !dbg !42912, !noalias !42802
  store ptr %_79.0.i.i.i, ptr %values.i.i.i, align 8, !dbg !42915, !noalias !42802
  %211 = getelementptr inbounds nuw i8, ptr %values.i.i.i, i64 8, !dbg !42915
  store ptr %_79.1.i.i.i, ptr %211, align 8, !dbg !42915, !noalias !42802
  call void @llvm.lifetime.start.p0(ptr nonnull %_39.i.i.i), !dbg !42918, !noalias !42802
  %212 = load i8, ptr %205, align 8, !dbg !42920, !range !168, !noalias !42802, !noundef !37
  %_42.i.i.i = trunc nuw i8 %212 to i1, !dbg !42920
  br i1 %_42.i.i.i, label %bb1.i29.i.i.i, label %bb10.i.i.i, !dbg !42921, !prof !11822

bb1.i29.i.i.i:                                    ; preds = %bb51.i.i.i
; invoke rofl_examples::functions::row_error::<vortex_array::scalar_fn::unstable::rofl::VortexHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(address) dereferenceable(80) %_39.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb8.i73.i.i unwind label %cleanup9.i.i.i, !dbg !42923, !noalias !42819

cleanup9.i.i.i:                                   ; preds = %bb1.i29.i.i.i
  %213 = landingpad { ptr, i32 }
          cleanup
  %_2.i.i.i.i.i.i = atomicrmw sub ptr %_79.0.i.i.i, i64 1 release, align 8, !dbg !42924, !noalias !42930
  %214 = icmp eq i64 %_2.i.i.i.i.i.i, 1, !dbg !42937
  br i1 %214, label %bb2.i.i.i.i72.i.i, label %bb25.i.i.i, !dbg !42937

bb2.i.i.i.i72.i.i:                                ; preds = %cleanup9.i.i.i
  fence acquire, !dbg !42938
; invoke <alloc::sync::Arc<vortex_array::array::typed::ArrayInner<dyn vortex_array::array::DynArrayData>>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcINtNtNtCsg1Afd8KoF7C_12vortex_array5array5typed10ArrayInnerDNtBL_12DynArrayDataEL_EE9drop_slowBN_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i.i) #23
          to label %bb25.i.i.i unwind label %terminate.i47.i.i, !dbg !42940, !noalias !42819

bb8.i73.i.i:                                      ; preds = %bb1.i29.i.i.i
  %.pr.i74.i.i = load i64, ptr %_39.i.i.i, align 8, !dbg !42918, !noalias !42802
  %.not23.i.i.i = icmp eq i64 %.pr.i74.i.i, -1, !dbg !42918
  br i1 %.not23.i.i.i, label %bb10.i.i.i, label %bb9.i75.i.i, !dbg !42941

bb9.i75.i.i:                                      ; preds = %bb8.i73.i.i
  %215 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !42942
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %215, ptr noundef nonnull align 8 dereferenceable(80) %_39.i.i.i, i64 80, i1 false), !dbg !42944, !noalias !42841
  store i64 0, ptr %_0, align 8, !dbg !42942, !alias.scope !42868, !noalias !42841
  call void @llvm.lifetime.end.p0(ptr nonnull %_39.i.i.i), !dbg !42945, !noalias !42802
  %_2.i.i.i33.i.i.i = atomicrmw sub ptr %_79.0.i.i.i, i64 1 release, align 8, !dbg !42946, !noalias !42952
  %216 = icmp eq i64 %_2.i.i.i33.i.i.i, 1, !dbg !42959
  br i1 %216, label %bb2.i.i.i34.i.i.i, label %bb11.i59.i.i, !dbg !42959

bb2.i.i.i34.i.i.i:                                ; preds = %bb9.i75.i.i
  fence acquire, !dbg !42960
; invoke <alloc::sync::Arc<vortex_array::array::typed::ArrayInner<dyn vortex_array::array::DynArrayData>>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcINtNtNtCsg1Afd8KoF7C_12vortex_array5array5typed10ArrayInnerDNtBL_12DynArrayDataEL_EE9drop_slowBN_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i.i) #23
          to label %bb11.i59.i.i unwind label %cleanup8.i.i.i, !dbg !42962, !noalias !42819

bb10.i.i.i:                                       ; preds = %bb8.i73.i.i, %bb51.i.i.i
  %_44.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !42963
  store ptr %_79.0.i.i.i, ptr %_44.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !42963, !alias.scope !42868, !noalias !42841
  %_44.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !42963
  store ptr %_79.1.i.i.i, ptr %_44.sroa.5.0..sroa_idx.i.i.i, align 8, !dbg !42963, !alias.scope !42868, !noalias !42841
  store <2 x i64> <i64 0, i64 -9223372036854775780>, ptr %_0, align 8, !dbg !42963, !alias.scope !42868, !noalias !42841
  call void @llvm.lifetime.end.p0(ptr nonnull %_39.i.i.i), !dbg !42945, !noalias !42802
  br label %bb11.i59.i.i, !dbg !42913

bb11.i59.i.i:                                     ; preds = %bb10.i.i.i, %bb2.i.i.i34.i.i.i, %bb9.i75.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i.i), !dbg !42913, !noalias !42802
  call void @llvm.lifetime.end.p0(ptr nonnull %state.i.i.i), !dbg !42914, !noalias !42802
  call void @llvm.experimental.noalias.scope.decl(metadata !42964), !dbg !42871
  call void @llvm.experimental.noalias.scope.decl(metadata !42967), !dbg !42970
  call void @llvm.experimental.noalias.scope.decl(metadata !42972), !dbg !42975
  %217 = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 16, !dbg !42977
  call void @llvm.experimental.noalias.scope.decl(metadata !42979), !dbg !42977
  %218 = load ptr, ptr %217, align 8, !dbg !42982, !alias.scope !42984, !noalias !42802, !noundef !37
  %219 = icmp eq ptr %218, null, !dbg !42982
  br i1 %219, label %bb4.i37.i.i.i, label %bb2.i.i.i.i.i60.i.i, !dbg !42982

bb2.i.i.i.i.i60.i.i:                              ; preds = %bb11.i59.i.i
  %_2.i.i.i.i.i.i.i61.i.i = atomicrmw sub ptr %218, i64 1 release, align 8, !dbg !42985, !noalias !42990
  %220 = icmp eq i64 %_2.i.i.i.i.i.i.i61.i.i, 1, !dbg !42995
  br i1 %220, label %bb2.i.i.i.i.i.i.i66.i.i, label %bb4.i37.i.i.i, !dbg !42995

bb2.i.i.i.i.i.i.i66.i.i:                          ; preds = %bb2.i.i.i.i.i60.i.i
  fence acquire, !dbg !42996
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %217) #23
          to label %bb4.i37.i.i.i unwind label %cleanup.i.i67.i.i, !dbg !42998, !noalias !42819

cleanup.i.i67.i.i:                                ; preds = %bb2.i.i.i.i.i.i.i66.i.i
  %221 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !42999), !dbg !42970
  call void @llvm.experimental.noalias.scope.decl(metadata !43002), !dbg !43005
  %222 = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 56, !dbg !43007
  call void @llvm.experimental.noalias.scope.decl(metadata !43009), !dbg !43007
  %223 = load ptr, ptr %222, align 8, !dbg !43012, !alias.scope !43014, !noalias !42802, !noundef !37
  %224 = icmp eq ptr %223, null, !dbg !43012
  br i1 %224, label %bb27.i46.i.i, label %bb2.i.i.i1.i.i68.i.i, !dbg !43012

bb2.i.i.i1.i.i68.i.i:                             ; preds = %cleanup.i.i67.i.i
  %_2.i.i.i.i.i2.i.i69.i.i = atomicrmw sub ptr %223, i64 1 release, align 8, !dbg !43015, !noalias !43020
  %225 = icmp eq i64 %_2.i.i.i.i.i2.i.i69.i.i, 1, !dbg !43025
  br i1 %225, label %bb2.i.i.i.i.i3.i.i70.i.i, label %bb27.i46.i.i, !dbg !43025

bb2.i.i.i.i.i3.i.i70.i.i:                         ; preds = %bb2.i.i.i1.i.i68.i.i
  fence acquire, !dbg !43026
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %222) #23
          to label %bb27.i46.i.i unwind label %terminate.i.i71.i.i, !dbg !43028, !noalias !42819

bb4.i37.i.i.i:                                    ; preds = %bb2.i.i.i.i.i.i.i66.i.i, %bb2.i.i.i.i.i60.i.i, %bb11.i59.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !43029), !dbg !42970
  call void @llvm.experimental.noalias.scope.decl(metadata !43032), !dbg !43035
  %226 = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 56, !dbg !43037
  call void @llvm.experimental.noalias.scope.decl(metadata !43039), !dbg !43037
  %227 = load ptr, ptr %226, align 8, !dbg !43042, !alias.scope !43044, !noalias !42802, !noundef !37
  %228 = icmp eq ptr %227, null, !dbg !43042
  br i1 %228, label %bb13.i64.i.i, label %bb2.i.i.i6.i.i62.i.i, !dbg !43042

bb2.i.i.i6.i.i62.i.i:                             ; preds = %bb4.i37.i.i.i
  %_2.i.i.i.i.i7.i.i63.i.i = atomicrmw sub ptr %227, i64 1 release, align 8, !dbg !43045, !noalias !43050
  %229 = icmp eq i64 %_2.i.i.i.i.i7.i.i63.i.i, 1, !dbg !43055
  br i1 %229, label %bb2.i.i.i.i.i8.i.i65.i.i, label %bb13.i64.i.i, !dbg !43055

bb2.i.i.i.i.i8.i.i65.i.i:                         ; preds = %bb2.i.i.i6.i.i62.i.i
  fence acquire, !dbg !43056
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %226) #23
          to label %bb13.i64.i.i unwind label %cleanup.i.i.i, !dbg !43058, !noalias !42819

terminate.i.i71.i.i:                              ; preds = %bb2.i.i.i.i.i3.i.i70.i.i
  %230 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !42970, !noalias !42819
  unreachable, !dbg !42970

bb13.i64.i.i:                                     ; preds = %bb2.i.i.i.i.i8.i.i65.i.i, %bb2.i.i.i6.i.i62.i.i, %bb4.i37.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i35.i.i), !dbg !42871, !noalias !42802
  %231 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 16, !dbg !43059
  %232 = load i8, ptr %231, align 8, !dbg !43061, !range !1916, !alias.scope !43063, !noalias !42876, !noundef !37
  %233 = icmp eq i8 %232, -1, !dbg !43061
  br i1 %233, label %bb8.i.i, label %bb20.sink.split.i.i.i, !dbg !43061

bb20.sink.split.i.i.i:                            ; preds = %bb19.i.i.i, %bb13.i64.i.i
  %.sink.i.i.i = phi ptr [ %249, %bb19.i.i.i ], [ %231, %bb13.i64.i.i ]
; call core::ptr::drop_glue::<vortex_array::dtype::DType>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %.sink.i.i.i), !dbg !43068, !noalias !41853
  br label %bb8.i.i, !dbg !43068

terminate.i47.i.i:                                ; preds = %bb2.i.i59.i.i.i, %bb25.i.i.i, %bb2.i.i.i.i72.i.i
  %234 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !43071, !noalias !43072
  unreachable, !dbg !43071

bb15.i54.i.i:                                     ; preds = %bb50.i58.i.i, %bb48.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !43073), !dbg !42871
  call void @llvm.experimental.noalias.scope.decl(metadata !43076), !dbg !43079
  call void @llvm.experimental.noalias.scope.decl(metadata !43081), !dbg !43084
  %235 = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 16, !dbg !43086
  call void @llvm.experimental.noalias.scope.decl(metadata !43088), !dbg !43086
  %236 = load ptr, ptr %235, align 8, !dbg !43091, !alias.scope !43093, !noalias !42802, !noundef !37
  %237 = icmp eq ptr %236, null, !dbg !43091
  br i1 %237, label %bb4.i42.i.i.i, label %bb2.i.i.i.i40.i.i.i, !dbg !43091

bb2.i.i.i.i40.i.i.i:                              ; preds = %bb15.i54.i.i
  %_2.i.i.i.i.i.i41.i.i.i = atomicrmw sub ptr %236, i64 1 release, align 8, !dbg !43094, !noalias !43099
  %238 = icmp eq i64 %_2.i.i.i.i.i.i41.i.i.i, 1, !dbg !43104
  br i1 %238, label %bb2.i.i.i.i.i.i46.i.i.i, label %bb4.i42.i.i.i, !dbg !43104

bb2.i.i.i.i.i.i46.i.i.i:                          ; preds = %bb2.i.i.i.i40.i.i.i
  fence acquire, !dbg !43105
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %235) #23
          to label %bb4.i42.i.i.i unwind label %cleanup.i47.i.i.i, !dbg !43107, !noalias !42819

cleanup.i47.i.i.i:                                ; preds = %bb2.i.i.i.i.i.i46.i.i.i
  %239 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !43108), !dbg !43079
  call void @llvm.experimental.noalias.scope.decl(metadata !43111), !dbg !43114
  %240 = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 56, !dbg !43116
  call void @llvm.experimental.noalias.scope.decl(metadata !43118), !dbg !43116
  %241 = load ptr, ptr %240, align 8, !dbg !43121, !alias.scope !43123, !noalias !42802, !noundef !37
  %242 = icmp eq ptr %241, null, !dbg !43121
  br i1 %242, label %bb27.i46.i.i, label %bb2.i.i.i1.i48.i.i.i, !dbg !43121

bb2.i.i.i1.i48.i.i.i:                             ; preds = %cleanup.i47.i.i.i
  %_2.i.i.i.i.i2.i49.i.i.i = atomicrmw sub ptr %241, i64 1 release, align 8, !dbg !43124, !noalias !43129
  %243 = icmp eq i64 %_2.i.i.i.i.i2.i49.i.i.i, 1, !dbg !43134
  br i1 %243, label %bb2.i.i.i.i.i3.i51.i.i.i, label %bb27.i46.i.i, !dbg !43134

bb2.i.i.i.i.i3.i51.i.i.i:                         ; preds = %bb2.i.i.i1.i48.i.i.i
  fence acquire, !dbg !43135
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %240) #23
          to label %bb27.i46.i.i unwind label %terminate.i52.i.i.i, !dbg !43137, !noalias !42819

bb4.i42.i.i.i:                                    ; preds = %bb2.i.i.i.i.i.i46.i.i.i, %bb2.i.i.i.i40.i.i.i, %bb15.i54.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !43138), !dbg !43079
  call void @llvm.experimental.noalias.scope.decl(metadata !43141), !dbg !43144
  %244 = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 56, !dbg !43146
  call void @llvm.experimental.noalias.scope.decl(metadata !43148), !dbg !43146
  %245 = load ptr, ptr %244, align 8, !dbg !43151, !alias.scope !43153, !noalias !42802, !noundef !37
  %246 = icmp eq ptr %245, null, !dbg !43151
  br i1 %246, label %bb19.i.i.i, label %bb2.i.i.i6.i43.i.i.i, !dbg !43151

bb2.i.i.i6.i43.i.i.i:                             ; preds = %bb4.i42.i.i.i
  %_2.i.i.i.i.i7.i44.i.i.i = atomicrmw sub ptr %245, i64 1 release, align 8, !dbg !43154, !noalias !43159
  %247 = icmp eq i64 %_2.i.i.i.i.i7.i44.i.i.i, 1, !dbg !43164
  br i1 %247, label %bb2.i.i.i.i.i8.i45.i.i.i, label %bb19.i.i.i, !dbg !43164

bb2.i.i.i.i.i8.i45.i.i.i:                         ; preds = %bb2.i.i.i6.i43.i.i.i
  fence acquire, !dbg !43165
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %244) #23
          to label %bb19.i.i.i unwind label %cleanup.i.i.i, !dbg !43167, !noalias !42819

terminate.i52.i.i.i:                              ; preds = %bb2.i.i.i.i.i3.i51.i.i.i
  %248 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !43079, !noalias !42819
  unreachable, !dbg !43079

bb25.i.i.i:                                       ; preds = %bb2.i.i.i.i72.i.i, %cleanup9.i.i.i, %cleanup8.i.i.i, %cleanup6.i.i.i, %cleanup5.i.i.i
  %.pn.i50.i.i = phi { ptr, i32 } [ %206, %cleanup8.i.i.i ], [ %199, %cleanup5.i.i.i ], [ %213, %cleanup9.i.i.i ], [ %201, %cleanup6.i.i.i ], [ %213, %bb2.i.i.i.i72.i.i ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>, rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(80) %columns.i35.i.i) #21
          to label %bb27.i46.i.i unwind label %terminate.i47.i.i, !dbg !42871, !noalias !42819

bb19.i.i.i:                                       ; preds = %bb2.i.i.i.i.i8.i45.i.i.i, %bb2.i.i.i6.i43.i.i.i, %bb4.i42.i.i.i, %bb16.i76.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i35.i.i), !dbg !42871, !noalias !42802
  %249 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 16, !dbg !43168
  %250 = load i8, ptr %249, align 8, !dbg !43170, !range !1916, !alias.scope !43172, !noalias !42876, !noundef !37
  %251 = icmp eq i8 %250, -1, !dbg !43170
  br i1 %251, label %bb8.i.i, label %bb20.sink.split.i.i.i, !dbg !43170

bb27.i46.i.i:                                     ; preds = %bb25.i.i.i, %bb2.i.i.i.i.i3.i51.i.i.i, %bb2.i.i.i1.i48.i.i.i, %cleanup.i47.i.i.i, %bb2.i.i.i.i.i3.i.i70.i.i, %bb2.i.i.i1.i.i68.i.i, %cleanup.i.i67.i.i, %cleanup.i.i.i
  %.pn25.i.i.i = phi { ptr, i32 } [ %.pn.i50.i.i, %bb25.i.i.i ], [ %221, %cleanup.i.i67.i.i ], [ %197, %cleanup.i.i.i ], [ %221, %bb2.i.i.i.i.i3.i.i70.i.i ], [ %221, %bb2.i.i.i1.i.i68.i.i ], [ %239, %bb2.i.i.i.i.i3.i51.i.i.i ], [ %239, %bb2.i.i.i1.i48.i.i.i ], [ %239, %cleanup.i47.i.i.i ]
  %252 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 16, !dbg !43177
  %253 = load i8, ptr %252, align 8, !dbg !43179, !range !1916, !alias.scope !43181, !noalias !42876, !noundef !37
  %254 = icmp eq i8 %253, -1, !dbg !43179
  br i1 %254, label %bb36.i.i, label %bb2.i.i59.i.i.i, !dbg !43179

bb2.i.i59.i.i.i:                                  ; preds = %bb27.i46.i.i
; invoke core::ptr::drop_glue::<vortex_array::dtype::DType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %252)
          to label %bb36.i.i unwind label %terminate.i47.i.i, !dbg !43179, !noalias !43072

bb9.i.i:                                          ; preds = %bb48.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i.i), !dbg !43186, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %_24.sroa.13.i.i), !dbg !43187
  call void @llvm.lifetime.start.p0(ptr nonnull %_24.sroa.17.i.i), !dbg !43187
  call void @llvm.experimental.noalias.scope.decl(metadata !43188), !dbg !43191
  %tolerant.i.i.i = icmp eq i64 %_15.i.i, 2, !dbg !43192
  %255 = getelementptr inbounds nuw i8, ptr %self, i64 48
  %_10.1.i.i.i = load i64, ptr %255, align 8, !dbg !43194, !alias.scope !43195, !noalias !43196
  %switch140 = icmp ult i64 %_10.1.i.i.i, 2
  %or.cond = select i1 %tolerant.i.i.i, i1 %switch140, i1 false, !dbg !43198
  br i1 %or.cond, label %panic3.i53.invoke, label %bb4.i89.i.i, !dbg !43198

bb4.i89.i.i:                                      ; preds = %bb9.i.i
  %_11.0.i.i.i.in = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_11.0.i.i.i = load ptr, ptr %_11.0.i.i.i.in, align 8, !dbg !43194, !alias.scope !43195, !noalias !43196
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i), !dbg !43199, !noalias !43200
  %256 = getelementptr inbounds nuw i8, ptr %self, i64 80, !dbg !43201
  %_12.i.i.i = load ptr, ptr %256, align 8, !dbg !43201, !alias.scope !43195, !noalias !43196, !nonnull !37, !align !40, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([88 x i8]) align 8 captures(none) dereferenceable(88) %_9.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i.i, i64 noundef %_10.1.i.i.i, i1 noundef zeroext %tolerant.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i.i)
          to label %.noexc99.i.i unwind label %bb35.thread189.i.i, !dbg !43199, !noalias !41853

.noexc99.i.i:                                     ; preds = %bb4.i89.i.i
  %_20.i.i.i = load i64, ptr %_9.i.i.i, align 8, !dbg !43202, !range !4730, !noalias !43200, !noundef !37
  %257 = trunc nuw i64 %_20.i.i.i to i1, !dbg !43204
  %258 = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 8, !dbg !43205
  %_24.sroa.7.8.copyload127.i.i = load i64, ptr %258, align 8, !dbg !43205, !noalias !43206
  %_24.sroa.12.8..sroa_idx130.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 16, !dbg !43205
  %_24.sroa.12.8.copyload131.i.i = load i8, ptr %_24.sroa.12.8..sroa_idx130.i.i, align 8, !dbg !43205, !noalias !43206
  %_24.sroa.13.8..sroa_idx134.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 17, !dbg !43205
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.13.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.13.8..sroa_idx134.i.i, i64 23, i1 false), !dbg !43205, !noalias !43206
  %_24.sroa.14.8..sroa_idx135.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 40, !dbg !43205
  %_24.sroa.14.8.copyload136.i.i = load i8, ptr %_24.sroa.14.8..sroa_idx135.i.i, align 8, !dbg !43205, !noalias !43206
  %_24.sroa.17.8..sroa_idx137.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 41, !dbg !43205
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_24.sroa.17.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_24.sroa.17.8..sroa_idx137.i.i, i64 47, i1 false), !dbg !43205, !noalias !43206
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i), !dbg !43207, !noalias !43200
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_23.sroa.5.sroa.0.sroa.8.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.13.i.i, i64 23, i1 false), !dbg !43208, !noalias !41857
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_23.sroa.5.sroa.8.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_24.sroa.17.i.i, i64 47, i1 false), !dbg !43208, !noalias !41857
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.sroa.13.i.i), !dbg !43211
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.sroa.17.i.i), !dbg !43211
  br i1 %257, label %bb49.i.i, label %bb50.i.i, !dbg !43204

panic3.i53.invoke:                                ; preds = %bb9.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i.i, i64 noundef %_10.1.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i53.cont unwind label %bb35.thread189.i.i, !dbg !43212

panic3.i53.cont:                                  ; preds = %panic3.i53.invoke
  unreachable

bb8.i.i:                                          ; preds = %bb19.i.i.i, %bb20.sink.split.i.i.i, %bb13.i64.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.5.sroa.0.sroa.8.i.i.i), !dbg !43214
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.5.sroa.8.i.i.i), !dbg !43214
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i.i), !dbg !43215, !noalias !41857
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB30_NCINvYBG_B35_19visit_deferred_boolB45_bKB30_NCINvXs1_B27_B24_INtB38_5RowFnBU_E8dispatchBG_Es4_0NCB50_s5_0E0NCB4i_s_0B5N_ECskkDzpO6M0zw_10boundaries.exit, !dbg !42763

bb49.i.i:                                         ; preds = %.noexc99.i.i
  %_82.sroa.0.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !43216
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_82.sroa.0.sroa.5.0..sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_23.sroa.5.sroa.0.sroa.8.i.i, i64 23, i1 false), !dbg !43211, !noalias !41853
  %_82.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 41, !dbg !43216
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_82.sroa.5.0..sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_23.sroa.5.sroa.8.i.i, i64 47, i1 false), !dbg !43211, !noalias !41853
  br label %bb24.i.i, !dbg !42763

bb50.i.i:                                         ; preds = %.noexc99.i.i
  %.not24.i.i = icmp eq i8 %_24.sroa.14.8.copyload136.i.i, 2, !dbg !43222
  br i1 %.not24.i.i, label %bb51.i.i, label %bb52.i.i, !dbg !43225

bb52.i.i:                                         ; preds = %bb50.i.i
  %val3.sroa.0.sroa.5.0.columns.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 9, !dbg !43226
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val3.sroa.0.sroa.5.0.columns.sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_23.sroa.5.sroa.0.sroa.8.i.i, i64 23, i1 false), !dbg !43187, !noalias !41857
  %val3.sroa.5.0.columns.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 33, !dbg !43226
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %val3.sroa.5.0.columns.sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_23.sroa.5.sroa.8.i.i, i64 47, i1 false), !dbg !43187, !noalias !41857
  store i64 %_24.sroa.7.8.copyload127.i.i, ptr %columns.i.i, align 8, !dbg !43226, !noalias !41857
  %val3.sroa.0.sroa.4.0.columns.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 8, !dbg !43226
  store i8 %_24.sroa.12.8.copyload131.i.i, ptr %val3.sroa.0.sroa.4.0.columns.sroa_idx.i.i, align 8, !dbg !43226, !noalias !41857
  %val3.sroa.4.0.columns.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 32, !dbg !43226
  store i8 %_24.sroa.14.8.copyload136.i.i, ptr %val3.sroa.4.0.columns.sroa_idx.i.i, align 8, !dbg !43226, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %_33.i.i), !dbg !43229, !noalias !41857
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_33.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i.i)
          to label %bb12.i.i unwind label %cleanup8.i.i, !dbg !43229, !noalias !41853

bb51.i.i:                                         ; preds = %bb50.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_80.i.i), !dbg !43231, !noalias !41857
; invoke <vortex_array::scalar_fn::unstable::rofl::VortexHost as rofl::host::Host>::error
  invoke void @_RNvXNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4roflNtB2_10VortexHostNtNtCshZi9mpuUhIi_4rofl4host4Host5error(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(address) dereferenceable(80) %_80.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_90e3c4e2332b77b0fece2c0e180e7e89, i64 noundef 27)
          to label %bb53.i.i unwind label %bb35.thread189.i.i, !dbg !43232, !noalias !41853

bb53.i.i:                                         ; preds = %bb51.i.i
  %_22.sroa.6.sroa.0.sroa.0.0.copyload.i.i = load i64, ptr %_80.i.i, align 8, !dbg !43235, !noalias !41857
  %_22.sroa.6.sroa.0.sroa.8.0._80.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_80.i.i, i64 8, !dbg !43235
  %_22.sroa.6.sroa.0.sroa.8.0.copyload.i.i = load i8, ptr %_22.sroa.6.sroa.0.sroa.8.0._80.sroa_idx.i.i, align 8, !dbg !43235, !noalias !41857
  %_22.sroa.6.sroa.0.sroa.9.0._80.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_80.i.i, i64 9, !dbg !43235
  %_88.sroa.0.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !43236
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_88.sroa.0.sroa.5.0..sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_22.sroa.6.sroa.0.sroa.9.0._80.sroa_idx.i.i, i64 23, i1 false), !dbg !43235, !noalias !41853
  %_22.sroa.6.sroa.8.0._80.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_80.i.i, i64 32, !dbg !43235
  %_22.sroa.6.sroa.8.0.copyload.i.i = load i8, ptr %_22.sroa.6.sroa.8.0._80.sroa_idx.i.i, align 8, !dbg !43235, !noalias !41857
  %_22.sroa.6.sroa.9.0._80.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_80.i.i, i64 33, !dbg !43235
  %_88.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 41, !dbg !43236
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(47) %_88.sroa.5.0..sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(47) %_22.sroa.6.sroa.9.0._80.sroa_idx.i.i, i64 47, i1 false), !dbg !43235, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %_80.i.i), !dbg !43242, !noalias !41857
  br label %bb24.i.i, !dbg !43243

bb24.i.i:                                         ; preds = %bb53.i.i, %bb49.i.i
  %_22.sroa.6.sroa.0.sroa.0.0.copyload.i.i.sink = phi i64 [ %_22.sroa.6.sroa.0.sroa.0.0.copyload.i.i, %bb53.i.i ], [ %_24.sroa.7.8.copyload127.i.i, %bb49.i.i ]
  %_22.sroa.6.sroa.0.sroa.8.0.copyload.i.i.sink = phi i8 [ %_22.sroa.6.sroa.0.sroa.8.0.copyload.i.i, %bb53.i.i ], [ %_24.sroa.12.8.copyload131.i.i, %bb49.i.i ]
  %_22.sroa.6.sroa.8.0.copyload.i.i.sink = phi i8 [ %_22.sroa.6.sroa.8.0.copyload.i.i, %bb53.i.i ], [ %_24.sroa.14.8.copyload136.i.i, %bb49.i.i ]
  %259 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !43244
  store i64 %_22.sroa.6.sroa.0.sroa.0.0.copyload.i.i.sink, ptr %259, align 8, !dbg !43244, !alias.scope !41854, !noalias !41853
  %_88.sroa.0.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !43244
  store i8 %_22.sroa.6.sroa.0.sroa.8.0.copyload.i.i.sink, ptr %_88.sroa.0.sroa.4.0..sroa_idx.i.i, align 8, !dbg !43244, !alias.scope !41854, !noalias !41853
  %_88.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !43244
  store i8 %_22.sroa.6.sroa.8.0.copyload.i.i.sink, ptr %_88.sroa.4.0..sroa_idx.i.i, align 8, !dbg !43244, !alias.scope !41854, !noalias !41853
  store i64 1, ptr %_0, align 8, !dbg !43245, !alias.scope !41854, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i), !dbg !43247, !noalias !41857
  br label %bb39.critedge.i.i, !dbg !43247

cleanup8.i.i:                                     ; preds = %bb52.i.i
  %260 = landingpad { ptr, i32 }
          cleanup
  br label %bb32.i.i, !dbg !43248

bb12.i.i:                                         ; preds = %bb52.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_33.i.i), !dbg !43248, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %source.i.i), !dbg !43249, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %_36.sroa.6.i.i), !dbg !43251
  call void @llvm.lifetime.start.p0(ptr nonnull %_37.i.i), !dbg !43251, !noalias !41857
  %261 = getelementptr inbounds nuw i8, ptr %self, i64 88, !dbg !43252
  %_39.i.i = load i64, ptr %261, align 8, !dbg !43252, !alias.scope !41853, !noalias !41854, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<vortex_array::scalar_fn::unstable::rofl::VortexHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(none) dereferenceable(80) %_37.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(80) %columns.i.i, i64 noundef %_39.i.i)
          to label %bb13.i.i unwind label %cleanup9.i.i, !dbg !43251, !noalias !41853

cleanup9.i.i:                                     ; preds = %bb12.i.i
  %262 = landingpad { ptr, i32 }
          cleanup
  br label %bb32.i.i

bb13.i.i:                                         ; preds = %bb12.i.i
  %263 = load i64, ptr %_37.i.i, align 8, !dbg !43253, !range !1887, !noalias !41857, !noundef !37
  %.not25.i.i = icmp eq i64 %263, -1, !dbg !43253
  %264 = getelementptr inbounds nuw i8, ptr %_37.i.i, i64 8, !dbg !43256
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_36.sroa.6.i.i, ptr noundef nonnull align 8 dereferenceable(56) %264, i64 56, i1 false), !dbg !43256, !noalias !41857
  br i1 %.not25.i.i, label %bb14.i.i, label %bb54.i.i, !dbg !43257

bb54.i.i:                                         ; preds = %bb13.i.i
  %_92.sroa.5.0._37.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_37.i.i, i64 64, !dbg !43258
  %_95.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 72, !dbg !43259
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %_95.sroa.5.0..sroa_idx.i.i, ptr noundef nonnull align 8 dereferenceable(16) %_92.sroa.5.0._37.sroa_idx.i.i, i64 16, i1 false), !dbg !43258, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %_37.i.i), !dbg !43265, !noalias !41857
  %_95.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !43259
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_95.sroa.4.0..sroa_idx.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_36.sroa.6.i.i, i64 56, i1 false), !dbg !43265, !noalias !41853
  %265 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !43259
  store i64 %263, ptr %265, align 8, !dbg !43259, !alias.scope !41854, !noalias !41853
  store i64 1, ptr %_0, align 8, !dbg !43259, !alias.scope !41854, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.sroa.6.i.i), !dbg !43266
  br label %bb22.i.i, !dbg !43267

cleanup10.i.i:                                    ; preds = %bb2.i.i.i109.i.i, %bb14.i.i
  %266 = landingpad { ptr, i32 }
          cleanup
  br label %bb32.i.i

bb14.i.i:                                         ; preds = %bb13.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_37.i.i), !dbg !43265, !noalias !41857
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %source.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_36.sroa.6.i.i, i64 56, i1 false), !dbg !43251, !noalias !41857
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.sroa.6.i.i), !dbg !43266
  call void @llvm.lifetime.start.p0(ptr nonnull %failure.i.i), !dbg !43269, !noalias !41857
  store i8 0, ptr %failure.i.i, align 1, !dbg !43271, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %collect.i.i), !dbg !43272, !noalias !41857
  store ptr %source.i.i, ptr %collect.i.i, align 8, !dbg !43274, !noalias !41857
  %267 = getelementptr inbounds nuw i8, ptr %collect.i.i, i64 8, !dbg !43274
  store ptr %prepared.i.i.i, ptr %267, align 8, !dbg !43274, !noalias !41857
  %268 = getelementptr inbounds nuw i8, ptr %collect.i.i, i64 16, !dbg !43274
  store ptr %prepared.i.i.i, ptr %268, align 8, !dbg !43274, !noalias !41857
  %269 = getelementptr inbounds nuw i8, ptr %collect.i.i, i64 24, !dbg !43274
  store ptr %failure.i.i, ptr %269, align 8, !dbg !43274, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %values.i.i), !dbg !43275, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %_50.i.i), !dbg !43277, !noalias !41857
  invoke void @_RINvXs1_NtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl6outputNtB8_10VortexHostNtNtCshZi9mpuUhIi_4rofl6output13BooleanOutput12collect_boolKb1_NCINvMNtNtB1w_7execute11packed_boolINtB2B_7ExecuteB1b_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKB2q_EE16deferred_booleanTxxEubKB2q_NCINvYB32_INtNtB1w_7visitor10RowVisitorB1b_E19visit_deferred_boolB4F_bKB2q_NCINvXs1_B3o_B3l_INtB53_5RowFnB1b_E8dispatchB32_Es4_0NCB65_s5_0E0NCB4S_s_0B6U_Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(none) dereferenceable(80) %_50.i.i, i64 noundef %_39.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(none) dereferenceable(32) %collect.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(40) %_12.i.i.i)
          to label %bb15.i.i unwind label %cleanup10.i.i, !dbg !43277, !noalias !41853

bb15.i.i:                                         ; preds = %bb14.i.i
  %270 = load i64, ptr %_50.i.i, align 8, !dbg !43278, !range !1887, !noalias !41857, !noundef !37
  %.not26.i.i = icmp eq i64 %270, -1, !dbg !43278
  %271 = getelementptr inbounds nuw i8, ptr %_50.i.i, i64 8, !dbg !43281
  %_98.0.i.i = load ptr, ptr %271, align 8, !dbg !43281, !noalias !41857
  %272 = getelementptr inbounds nuw i8, ptr %_50.i.i, i64 16, !dbg !43281
  %_98.1.i.i = load ptr, ptr %272, align 8, !dbg !43281, !noalias !41857
  br i1 %.not26.i.i, label %bb57.i.i, label %bb56.i.i, !dbg !43282

bb56.i.i:                                         ; preds = %bb15.i.i
  %_99.sroa.6.0._50.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_50.i.i, i64 24, !dbg !43283
  %_102.sroa.6.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !43284
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_102.sroa.6.0..sroa_idx.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_99.sroa.6.0._50.sroa_idx.i.i, i64 56, i1 false), !dbg !43283, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %_50.i.i), !dbg !43290, !noalias !41857
  %273 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !43284
  store i64 %270, ptr %273, align 8, !dbg !43284, !alias.scope !41854, !noalias !41853
  %_102.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !43284
  store ptr %_98.0.i.i, ptr %_102.sroa.4.0..sroa_idx.i.i, align 8, !dbg !43284, !alias.scope !41854, !noalias !41853
  %_102.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !43284
  store ptr %_98.1.i.i, ptr %_102.sroa.5.0..sroa_idx.i.i, align 8, !dbg !43284, !alias.scope !41854, !noalias !41853
  store i64 1, ptr %_0, align 8, !dbg !43284, !alias.scope !41854, !noalias !41853
  br label %bb21.i.i, !dbg !43291

bb57.i.i:                                         ; preds = %bb15.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_50.i.i), !dbg !43290, !noalias !41857
  store ptr %_98.0.i.i, ptr %values.i.i, align 8, !dbg !43293, !noalias !41857
  %274 = getelementptr inbounds nuw i8, ptr %values.i.i, i64 8, !dbg !43293
  store ptr %_98.1.i.i, ptr %274, align 8, !dbg !43293, !noalias !41857
  call void @llvm.lifetime.start.p0(ptr nonnull %_55.i.i), !dbg !43296, !noalias !41857
  %275 = load i8, ptr %failure.i.i, align 1, !dbg !43298, !range !168, !noalias !41857, !noundef !37
  %_58.i.i = trunc nuw i8 %275 to i1, !dbg !43298
  br i1 %_58.i.i, label %bb1.i102.i.i, label %bb59.i.i, !dbg !43299, !prof !11822

bb1.i102.i.i:                                     ; preds = %bb57.i.i
; invoke rofl_examples::functions::row_error::<vortex_array::scalar_fn::unstable::rofl::VortexHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([80 x i8]) align 8 captures(address) dereferenceable(80) %_55.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb16.i.i unwind label %cleanup11.i.i, !dbg !43301, !noalias !41853

cleanup11.i.i:                                    ; preds = %bb1.i102.i.i
  %276 = landingpad { ptr, i32 }
          cleanup
  %_2.i.i.i.i.i = atomicrmw sub ptr %_98.0.i.i, i64 1 release, align 8, !dbg !43302, !noalias !43308
  %277 = icmp eq i64 %_2.i.i.i.i.i, 1, !dbg !43315
  br i1 %277, label %bb2.i.i.i105.i.i, label %bb32.i.i, !dbg !43315

bb2.i.i.i105.i.i:                                 ; preds = %cleanup11.i.i
  fence acquire, !dbg !43316
; invoke <alloc::sync::Arc<vortex_array::array::typed::ArrayInner<dyn vortex_array::array::DynArrayData>>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcINtNtNtCsg1Afd8KoF7C_12vortex_array5array5typed10ArrayInnerDNtBL_12DynArrayDataEL_EE9drop_slowBN_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i) #23
          to label %bb32.i.i unwind label %terminate.i.i, !dbg !43318, !noalias !41853

bb16.i.i:                                         ; preds = %bb1.i102.i.i
  %.pr.i.i = load i64, ptr %_55.i.i, align 8, !dbg !43319, !noalias !41857
  %.not27.i.i = icmp eq i64 %.pr.i.i, -1, !dbg !43319
  br i1 %.not27.i.i, label %bb59.i.i, label %bb58.i.i, !dbg !43321

bb58.i.i:                                         ; preds = %bb16.i.i
  %278 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !43322
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(80) %278, ptr noundef nonnull align 8 dereferenceable(80) %_55.i.i, i64 80, i1 false), !dbg !43328, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %_55.i.i), !dbg !43329, !noalias !41857
  store i64 1, ptr %_0, align 8, !dbg !43322, !alias.scope !41854, !noalias !41853
  %_2.i.i.i108.i.i = atomicrmw sub ptr %_98.0.i.i, i64 1 release, align 8, !dbg !43330, !noalias !43336
  %279 = icmp eq i64 %_2.i.i.i108.i.i, 1, !dbg !43343
  br i1 %279, label %bb2.i.i.i109.i.i, label %bb21.i.i, !dbg !43343

bb2.i.i.i109.i.i:                                 ; preds = %bb58.i.i
  fence acquire, !dbg !43344
; invoke <alloc::sync::Arc<vortex_array::array::typed::ArrayInner<dyn vortex_array::array::DynArrayData>>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcINtNtNtCsg1Afd8KoF7C_12vortex_array5array5typed10ArrayInnerDNtBL_12DynArrayDataEL_EE9drop_slowBN_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i) #23
          to label %bb21.i.i unwind label %cleanup10.i.i, !dbg !43346, !noalias !41853

bb59.i.i:                                         ; preds = %bb16.i.i, %bb57.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_55.i.i), !dbg !43329, !noalias !41857
  %_60.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !43347
  store ptr %_98.0.i.i, ptr %_60.sroa.4.0..sroa_idx.i.i, align 8, !dbg !43347, !alias.scope !41854, !noalias !41853
  %_60.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !43347
  store ptr %_98.1.i.i, ptr %_60.sroa.5.0..sroa_idx.i.i, align 8, !dbg !43347, !alias.scope !41854, !noalias !41853
  store <2 x i64> <i64 0, i64 -9223372036854775780>, ptr %_0, align 8, !dbg !43347, !alias.scope !41854, !noalias !41853
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i), !dbg !43348, !noalias !41857
  call void @llvm.lifetime.end.p0(ptr nonnull %collect.i.i), !dbg !43349, !noalias !41857
  call void @llvm.lifetime.end.p0(ptr nonnull %failure.i.i), !dbg !43350, !noalias !41857
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i), !dbg !43351, !noalias !41857
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>, rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(80) %columns.i.i)
          to label %bb19.i.i unwind label %bb35.thread189.i.i, !dbg !43247, !noalias !41853

bb19.i.i:                                         ; preds = %bb59.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i), !dbg !43247, !noalias !41857
  %280 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !43352
  %281 = load i8, ptr %280, align 8, !dbg !43354, !range !1916, !alias.scope !43356, !noalias !41854, !noundef !37
  %282 = icmp eq i8 %281, -1, !dbg !43354
  br i1 %282, label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB30_NCINvYBG_B35_19visit_deferred_boolB45_bKB30_NCINvXs1_B27_B24_INtB38_5RowFnBU_E8dispatchBG_Es4_0NCB50_s5_0E0NCB4i_s_0B5N_ECskkDzpO6M0zw_10boundaries.exit, label %bb2.i.i.i.i, !dbg !43354

bb2.i.i.i.i:                                      ; preds = %bb19.i.i
; call core::ptr::drop_glue::<vortex_array::dtype::DType>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %280), !dbg !43354
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB30_NCINvYBG_B35_19visit_deferred_boolB45_bKB30_NCINvXs1_B27_B24_INtB38_5RowFnBU_E8dispatchBG_Es4_0NCB50_s5_0E0NCB4i_s_0B5N_ECskkDzpO6M0zw_10boundaries.exit, !dbg !43354

bb21.i.i:                                         ; preds = %bb2.i.i.i109.i.i, %bb58.i.i, %bb56.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i), !dbg !43348, !noalias !41857
  call void @llvm.lifetime.end.p0(ptr nonnull %collect.i.i), !dbg !43349, !noalias !41857
  call void @llvm.lifetime.end.p0(ptr nonnull %failure.i.i), !dbg !43350, !noalias !41857
  br label %bb22.i.i, !dbg !43351

terminate.i.i:                                    ; preds = %bb2.i.i124.i.i, %bb32.i.i, %bb2.i.i.i105.i.i
  %283 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !43361
  unreachable, !dbg !43361

bb22.i.i:                                         ; preds = %bb21.i.i, %bb54.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i), !dbg !43351, !noalias !41857
  call void @llvm.experimental.noalias.scope.decl(metadata !43362), !dbg !43247
  call void @llvm.experimental.noalias.scope.decl(metadata !43365), !dbg !43368
  call void @llvm.experimental.noalias.scope.decl(metadata !43370), !dbg !43373
  %284 = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 16, !dbg !43375
  call void @llvm.experimental.noalias.scope.decl(metadata !43377), !dbg !43375
  %285 = load ptr, ptr %284, align 8, !dbg !43380, !alias.scope !43382, !noalias !41857, !noundef !37
  %286 = icmp eq ptr %285, null, !dbg !43380
  br i1 %286, label %bb4.i113.i.i, label %bb2.i.i.i.i112.i.i, !dbg !43380

bb2.i.i.i.i112.i.i:                               ; preds = %bb22.i.i
  %_2.i.i.i.i.i.i.i.i = atomicrmw sub ptr %285, i64 1 release, align 8, !dbg !43383, !noalias !43388
  %287 = icmp eq i64 %_2.i.i.i.i.i.i.i.i, 1, !dbg !43393
  br i1 %287, label %bb2.i.i.i.i.i.i114.i.i, label %bb4.i113.i.i, !dbg !43393

bb2.i.i.i.i.i.i114.i.i:                           ; preds = %bb2.i.i.i.i112.i.i
  fence acquire, !dbg !43394
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %284) #23
          to label %bb4.i113.i.i unwind label %cleanup.i115.i.i, !dbg !43396, !noalias !41853

cleanup.i115.i.i:                                 ; preds = %bb2.i.i.i.i.i.i114.i.i
  %288 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !43397), !dbg !43368
  call void @llvm.experimental.noalias.scope.decl(metadata !43400), !dbg !43403
  %289 = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 56, !dbg !43405
  call void @llvm.experimental.noalias.scope.decl(metadata !43407), !dbg !43405
  %290 = load ptr, ptr %289, align 8, !dbg !43410, !alias.scope !43412, !noalias !41857, !noundef !37
  %291 = icmp eq ptr %290, null, !dbg !43410
  br i1 %291, label %bb46.i.i, label %bb2.i.i.i1.i.i.i, !dbg !43410

bb2.i.i.i1.i.i.i:                                 ; preds = %cleanup.i115.i.i
  %_2.i.i.i.i.i2.i.i.i = atomicrmw sub ptr %290, i64 1 release, align 8, !dbg !43413, !noalias !43418
  %292 = icmp eq i64 %_2.i.i.i.i.i2.i.i.i, 1, !dbg !43423
  br i1 %292, label %bb2.i.i.i.i.i3.i.i.i, label %bb46.i.i, !dbg !43423

bb2.i.i.i.i.i3.i.i.i:                             ; preds = %bb2.i.i.i1.i.i.i
  fence acquire, !dbg !43424
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %289) #23
          to label %bb46.i.i unwind label %terminate.i117.i.i, !dbg !43426, !noalias !41853

bb4.i113.i.i:                                     ; preds = %bb2.i.i.i.i.i.i114.i.i, %bb2.i.i.i.i112.i.i, %bb22.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !43427), !dbg !43368
  call void @llvm.experimental.noalias.scope.decl(metadata !43430), !dbg !43433
  %293 = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 56, !dbg !43435
  call void @llvm.experimental.noalias.scope.decl(metadata !43437), !dbg !43435
  %294 = load ptr, ptr %293, align 8, !dbg !43440, !alias.scope !43442, !noalias !41857, !noundef !37
  %295 = icmp eq ptr %294, null, !dbg !43440
  br i1 %295, label %bb25.i.i, label %bb2.i.i.i6.i.i.i, !dbg !43440

bb2.i.i.i6.i.i.i:                                 ; preds = %bb4.i113.i.i
  %_2.i.i.i.i.i7.i.i.i = atomicrmw sub ptr %294, i64 1 release, align 8, !dbg !43443, !noalias !43448
  %296 = icmp eq i64 %_2.i.i.i.i.i7.i.i.i, 1, !dbg !43453
  br i1 %296, label %bb2.i.i.i.i.i8.i.i.i, label %bb25.i.i, !dbg !43453

bb2.i.i.i.i.i8.i.i.i:                             ; preds = %bb2.i.i.i6.i.i.i
  fence acquire, !dbg !43454
; invoke <alloc::sync::Arc<vortex_buffer::allocation::BufferBacking>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs7x6tOKv5niH_13vortex_buffer10allocation13BufferBackingE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(8) %293) #23
          to label %bb25.i.i unwind label %bb35.thread189.i.i, !dbg !43456, !noalias !41853

terminate.i117.i.i:                               ; preds = %bb2.i.i.i.i.i3.i.i.i
  %297 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !43368, !noalias !41853
  unreachable, !dbg !43368

bb25.i.i:                                         ; preds = %bb2.i.i.i.i.i8.i.i.i, %bb2.i.i.i6.i.i.i, %bb4.i113.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i), !dbg !43247, !noalias !41857
  br label %bb39.critedge.i.i, !dbg !43247

bb32.i.i:                                         ; preds = %bb2.i.i.i105.i.i, %cleanup11.i.i, %cleanup10.i.i, %cleanup9.i.i, %cleanup8.i.i
  %.pn.i.i = phi { ptr, i32 } [ %266, %cleanup10.i.i ], [ %260, %cleanup8.i.i ], [ %262, %cleanup9.i.i ], [ %276, %bb2.i.i.i105.i.i ], [ %276, %cleanup11.i.i ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>, rofl::tuple::Column<vortex_array::scalar_fn::unstable::rofl::VortexHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(80) %columns.i.i) #21
          to label %bb46.i.i unwind label %terminate.i.i, !dbg !43247, !noalias !41853

bb39.critedge.i.i:                                ; preds = %bb25.i.i, %bb24.i.i, %bb47.i.i
  %298 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !43457
  %299 = load i8, ptr %298, align 8, !dbg !43459, !range !1916, !alias.scope !43461, !noalias !41854, !noundef !37
  %300 = icmp eq i8 %299, -1, !dbg !43459
  br i1 %300, label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB30_NCINvYBG_B35_19visit_deferred_boolB45_bKB30_NCINvXs1_B27_B24_INtB38_5RowFnBU_E8dispatchBG_Es4_0NCB50_s5_0E0NCB4i_s_0B5N_ECskkDzpO6M0zw_10boundaries.exit, label %bb2.i.i122.i.i, !dbg !43459

bb2.i.i122.i.i:                                   ; preds = %bb39.critedge.i.i
; call core::ptr::drop_glue::<vortex_array::dtype::DType>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %298), !dbg !43459
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB30_NCINvYBG_B35_19visit_deferred_boolB45_bKB30_NCINvXs1_B27_B24_INtB38_5RowFnBU_E8dispatchBG_Es4_0NCB50_s5_0E0NCB4i_s_0B5N_ECskkDzpO6M0zw_10boundaries.exit, !dbg !43459

bb35.thread189.i.i:                               ; preds = %panic3.i53.invoke, %bb2.i.i.i.i.i8.i.i.i, %bb59.i.i, %bb51.i.i, %bb4.i89.i.i, %bb4.i.i
  %lpad.thr_comm.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb46.i.i, !dbg !43247

bb36.i.i:                                         ; preds = %bb2.i.i124.i.i, %bb46.i.i, %bb2.i.i59.i.i.i, %bb27.i46.i.i, %bb2.i.i55.i.i.i, %bb60.i.i.i, %bb2.i.i.i.i.i.i, %bb52.i.i.i.i
  %.pn29181.i.i = phi { ptr, i32 } [ %.pn29187.i.i, %bb46.i.i ], [ %.pn39.i.i.i.i, %bb2.i.i.i.i.i.i ], [ %.pn29187.i.i, %bb2.i.i124.i.i ], [ %.pn25.i.i.i, %bb2.i.i59.i.i.i ], [ %.pn25.i.i.i, %bb27.i46.i.i ], [ %.pn27104.i.i.i, %bb2.i.i55.i.i.i ], [ %.pn39.i.i.i.i, %bb52.i.i.i.i ], [ %.pn27104.i.i.i, %bb60.i.i.i ]
  resume { ptr, i32 } %.pn29181.i.i, !dbg !43361

bb46.i.i:                                         ; preds = %bb35.thread189.i.i, %bb32.i.i, %bb2.i.i.i.i.i3.i.i.i, %bb2.i.i.i1.i.i.i, %cleanup.i115.i.i
  %.pn29187.i.i = phi { ptr, i32 } [ %lpad.thr_comm.i.i, %bb35.thread189.i.i ], [ %288, %bb2.i.i.i.i.i3.i.i.i ], [ %288, %cleanup.i115.i.i ], [ %288, %bb2.i.i.i1.i.i.i ], [ %.pn.i.i, %bb32.i.i ]
  %301 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !43466
  %302 = load i8, ptr %301, align 8, !dbg !43468, !range !1916, !alias.scope !43470, !noalias !41854, !noundef !37
  %303 = icmp eq i8 %302, -1, !dbg !43468
  br i1 %303, label %bb36.i.i, label %bb2.i.i124.i.i, !dbg !43468

bb2.i.i124.i.i:                                   ; preds = %bb46.i.i
; invoke core::ptr::drop_glue::<vortex_array::dtype::DType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsg1Afd8KoF7C_12vortex_array5dtype5DTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %301)
          to label %bb36.i.i unwind label %terminate.i.i, !dbg !43468

_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtNtNtNtCsg1Afd8KoF7C_12vortex_array9scalar_fn8unstable4rofl10VortexHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB30_NCINvYBG_B35_19visit_deferred_boolB45_bKB30_NCINvXs1_B27_B24_INtB38_5RowFnBU_E8dispatchBG_Es4_0NCB50_s5_0E0NCB4i_s_0B5N_ECskkDzpO6M0zw_10boundaries.exit: ; preds = %bb2.i.i122.i.i, %bb39.critedge.i.i, %bb2.i.i.i.i, %bb19.i.i, %bb8.i.i, %bb3.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_23.sroa.5.sroa.0.sroa.8.i.i), !dbg !43475
  call void @llvm.lifetime.end.p0(ptr nonnull %_23.sroa.5.sroa.8.i.i), !dbg !43475
  ret void, !dbg !43476
}