; target/release/deps/boundaries-3c3a77a76c6fcdfa.boundaries.ecd45eb892372cfc-cgu.15.rcgu.ll
define hidden void @_RINvXs_NtCs7Kazvvc7DnG_10rofl_arrow5batchNtB5_13ArrowValidityNtNtCshZi9mpuUhIi_4rofl4host9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleNCINvNtB11_7execute13selected_rowsNtB7_9ArrowHostB1N_NCINvMNtB2z_5ownedINtB2z_7ExecuteB32_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3D_INtNtB11_7visitor10RowVisitorB32_E19visit_deferred_boolB56_bKB4S_NCINvXs1_B3Z_B3W_INtB5q_5RowFnB32_E8dispatchB3D_Es4_0NCB6s_s5_0E0NCB5f_s_0B7h_Es_0Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(56) %self, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(48) %0, ptr noalias nofree noundef align 8 captures(none) dereferenceable(8) %1) unnamed_addr #0 personality ptr @rust_eh_personality !dbg !4869 {
start:
  %chunks.i = alloca [32 x i8], align 8
  %_11 = alloca [32 x i8], align 8
  %2 = load ptr, ptr %self, align 8, !dbg !4870, !noundef !31
  %.not = icmp eq ptr %2, null, !dbg !4870
  br i1 %.not, label %bb3, label %bb2, !dbg !4871

bb2:                                              ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_11), !dbg !4872
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 8, !dbg !4875
  %_18 = load ptr, ptr %3, align 8, !dbg !4875, !noundef !31
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !4882
  %_19 = load i64, ptr %4, align 8, !dbg !4882, !noundef !31
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 24, !dbg !4885
  %_13 = load i64, ptr %5, align 8, !dbg !4885, !noundef !31
  %6 = getelementptr inbounds nuw i8, ptr %self, i64 32, !dbg !4888
  %_14 = load i64, ptr %6, align 8, !dbg !4888, !noundef !31
; call <rofl_kernels::bit::view::BitmapView>::new
  call void @_RNvMNtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB2_10BitmapView3new(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_11, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_18, i64 noundef %_19, i64 noundef %_13, i64 noundef %_14), !dbg !4872
  tail call void @llvm.experimental.noalias.scope.decl(metadata !4891), !dbg !4894
  call void @llvm.lifetime.start.p0(ptr nonnull %chunks.i), !dbg !4895, !noalias !4898
  %_40.sroa.2.0.self.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_11, i64 24, !dbg !4900
  %_40.sroa.2.0.copyload.i = load i64, ptr %_40.sroa.2.0.self.sroa_idx.i, align 8, !dbg !4900, !alias.scope !4891, !noalias !4903
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %chunks.i, ptr noundef nonnull readonly align 8 dereferenceable(32) %_11, i64 24, i1 false), !dbg !4904, !noalias !4903
  %_40.sroa.2.0.chunks.sroa_idx.i = getelementptr inbounds nuw i8, ptr %chunks.i, i64 24, !dbg !4904
  store i64 %_40.sroa.2.0.copyload.i, ptr %_40.sroa.2.0.chunks.sroa_idx.i, align 8, !dbg !4904, !noalias !4898
  %_4211.i = lshr i64 %_40.sroa.2.0.copyload.i, 6, !dbg !4905
; call <rofl_kernels::bit::view::BitmapChunks>::remainder_bits
  %_9.i = call noundef i64 @_RNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB5_12BitmapChunks14remainder_bits(ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %chunks.i), !dbg !4909, !noalias !4891
  %.promoted50 = load i64, ptr %1, align 8
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %_16.i.i.i = load ptr, ptr %7, align 8, !nonnull !31, !align !368
  %view.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i, i64 8
  %_6.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i, i64 24
  %view.i2.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i, i64 32
  %8 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %_17.1.i.i.i = load i64, ptr %8, align 8
  %9 = getelementptr inbounds nuw i8, ptr %_16.i.i.i, i64 16
  %10 = getelementptr inbounds nuw i8, ptr %_16.i.i.i, i64 40
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %_18.0.i.i.i = load ptr, ptr %11, align 8, !nonnull !31
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %_19.i.i.i = load ptr, ptr %12, align 8, !nonnull !31
  br label %bb3.i.outer, !dbg !4910

bb3.i.outer.backedge:                             ; preds = %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit, %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit43
  %.promoted4952.ph.be = phi i64 [ %32, %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit43 ], [ %21, %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit ]
  br label %bb3.i.outer, !dbg !4912

bb3.i.outer:                                      ; preds = %bb3.i.outer.backedge, %bb2
  %.promoted4952.ph = phi i64 [ %.promoted50, %bb2 ], [ %.promoted4952.ph.be, %bb3.i.outer.backedge ]
  %iter.sroa.6.0.i.ph = phi i64 [ 0, %bb2 ], [ %iter.sroa.6.1.i, %bb3.i.outer.backedge ]
  %iter.sroa.13.0.i.ph = phi ptr [ %chunks.i, %bb2 ], [ %iter.sroa.13.2.i, %bb3.i.outer.backedge ]
  %iter.sroa.16.0.i.ph = phi i64 [ 0, %bb2 ], [ %iter.sroa.16.1.i, %bb3.i.outer.backedge ]
  %iter.sroa.21.0.i.ph = phi i64 [ 0, %bb2 ], [ %_9.0.i.i, %bb3.i.outer.backedge ]
  br label %bb3.i, !dbg !4912

bb3.i:                                            ; preds = %bb3.i.outer, %bb6.i
  %iter.sroa.6.0.i = phi i64 [ %iter.sroa.6.1.i, %bb6.i ], [ %iter.sroa.6.0.i.ph, %bb3.i.outer ], !dbg !4917
  %iter.sroa.13.0.i = phi ptr [ %iter.sroa.13.2.i, %bb6.i ], [ %iter.sroa.13.0.i.ph, %bb3.i.outer ], !dbg !4917
  %iter.sroa.16.0.i = phi i64 [ %iter.sroa.16.1.i, %bb6.i ], [ %iter.sroa.16.0.i.ph, %bb3.i.outer ], !dbg !4917
  %iter.sroa.21.0.i = phi i64 [ %_9.0.i.i, %bb6.i ], [ %iter.sroa.21.0.i.ph, %bb3.i.outer ], !dbg !4917
  %.not.i.i.i.i = icmp ne ptr %iter.sroa.13.0.i, null, !dbg !4918
  %_0.i.i.i.i.i.i.i.i.i = icmp ult i64 %iter.sroa.16.0.i, %_4211.i
  %or.cond.i = select i1 %.not.i.i.i.i, i1 %_0.i.i.i.i.i.i.i.i.i, i1 false, !dbg !4912
  br i1 %or.cond.i, label %_RINvNtNtNtCslWxY2MhVcag_4core4iter8adapters5chain17and_then_or_clearINtNtB4_3map3MapINtNtNtB8_3ops5range5RangejENCNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB1U_12BitmapChunks4iter0EyNvYB14_NtNtNtB6_6traits8iterator8Iterator4nextECskkDzpO6M0zw_10boundaries.exit.i.i.i, label %bb5.i.i.i.i.i, !dbg !4912

_RINvNtNtNtCslWxY2MhVcag_4core4iter8adapters5chain17and_then_or_clearINtNtB4_3map3MapINtNtNtB8_3ops5range5RangejENCNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB1U_12BitmapChunks4iter0EyNvYB14_NtNtNtB6_6traits8iterator8Iterator4nextECskkDzpO6M0zw_10boundaries.exit.i.i.i: ; preds = %bb3.i
  %_0.i1.i.i.i.i.i.i.i.i = add nuw nsw i64 %iter.sroa.16.0.i, 1, !dbg !4919
  %_4.i.i.i.i.i.i.i = shl nuw i64 %iter.sroa.16.0.i, 6, !dbg !4926
; call <rofl_kernels::bit::view::BitmapView>::word
  %_0.i.i.i.i.i.i14.i = call noundef i64 @_RNvMNtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB2_10BitmapView4word(ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(32) %iter.sroa.13.0.i, i64 noundef %_4.i.i.i.i.i.i.i, i64 noundef 64), !dbg !4930, !noalias !4891
  br label %bb6.i, !dbg !4930

bb5.i.i.i.i.i:                                    ; preds = %bb3.i
  %_5.not.i.i.i.i.i.i.not.i = icmp eq i64 %iter.sroa.6.0.i, 0, !dbg !4931
  br i1 %_5.not.i.i.i.i.i.i.not.i, label %bb6.i, label %_RINvXs_NtCshZi9mpuUhIi_4rofl4hostNtNtNtCs7tX4SdoNkTE_12rofl_kernels3bit4view10BitmapViewNtB5_9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleQNCINvNtB7_7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1R_NCINvMNtB2E_5ownedINtB2E_7ExecuteB36_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB44_INtNtB7_7visitor10RowVisitorB36_E19visit_deferred_boolB5x_bKB5j_NCINvXs1_B4q_B4n_INtB5R_5RowFnB36_E8dispatchB44_Es4_0NCB6S_s5_0E0NCB5G_s_0B7H_Es_0Es_0ECskkDzpO6M0zw_10boundaries.exit, !dbg !4931

bb6.i:                                            ; preds = %bb5.i.i.i.i.i, %_RINvNtNtNtCslWxY2MhVcag_4core4iter8adapters5chain17and_then_or_clearINtNtB4_3map3MapINtNtNtB8_3ops5range5RangejENCNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB1U_12BitmapChunks4iter0EyNvYB14_NtNtNtB6_6traits8iterator8Iterator4nextECskkDzpO6M0zw_10boundaries.exit.i.i.i
  %iter.sroa.6.1.i = phi i64 [ %iter.sroa.6.0.i, %_RINvNtNtNtCslWxY2MhVcag_4core4iter8adapters5chain17and_then_or_clearINtNtB4_3map3MapINtNtNtB8_3ops5range5RangejENCNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB1U_12BitmapChunks4iter0EyNvYB14_NtNtNtB6_6traits8iterator8Iterator4nextECskkDzpO6M0zw_10boundaries.exit.i.i.i ], [ 1, %bb5.i.i.i.i.i ], !dbg !4917
  %iter.sroa.13.2.i = phi ptr [ %iter.sroa.13.0.i, %_RINvNtNtNtCslWxY2MhVcag_4core4iter8adapters5chain17and_then_or_clearINtNtB4_3map3MapINtNtNtB8_3ops5range5RangejENCNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB1U_12BitmapChunks4iter0EyNvYB14_NtNtNtB6_6traits8iterator8Iterator4nextECskkDzpO6M0zw_10boundaries.exit.i.i.i ], [ null, %bb5.i.i.i.i.i ], !dbg !4917
  %iter.sroa.16.1.i = phi i64 [ %_0.i1.i.i.i.i.i.i.i.i, %_RINvNtNtNtCslWxY2MhVcag_4core4iter8adapters5chain17and_then_or_clearINtNtB4_3map3MapINtNtNtB8_3ops5range5RangejENCNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB1U_12BitmapChunks4iter0EyNvYB14_NtNtNtB6_6traits8iterator8Iterator4nextECskkDzpO6M0zw_10boundaries.exit.i.i.i ], [ %iter.sroa.16.0.i, %bb5.i.i.i.i.i ], !dbg !4917
  %self.1.pn.i.i.ph.i.i = phi i64 [ %_0.i.i.i.i.i.i14.i, %_RINvNtNtNtCslWxY2MhVcag_4core4iter8adapters5chain17and_then_or_clearINtNtB4_3map3MapINtNtNtB8_3ops5range5RangejENCNvMs0_NtNtCs7tX4SdoNkTE_12rofl_kernels3bit4viewNtB1U_12BitmapChunks4iter0EyNvYB14_NtNtNtB6_6traits8iterator8Iterator4nextECskkDzpO6M0zw_10boundaries.exit.i.i.i ], [ %_9.i, %bb5.i.i.i.i.i ]
  %_9.0.i.i = add i64 %iter.sroa.21.0.i, 1, !dbg !4937
  switch i64 %self.1.pn.i.i.ph.i.i, label %bb13.lr.ph.i [
    i64 -1, label %bb9.preheader.i
    i64 0, label %bb3.i
  ], !dbg !4938

bb13.lr.ph.i:                                     ; preds = %bb6.i
  %_33.i = shl i64 %iter.sroa.21.0.i, 6
  br label %bb13.i, !dbg !4940

bb9.preheader.i:                                  ; preds = %bb6.i
  %_25.i = shl i64 %iter.sroa.21.0.i, 6
  br label %bb24.i, !dbg !4941

bb24.i:                                           ; preds = %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit, %bb9.preheader.i
  %13 = phi i64 [ %.promoted4952.ph, %bb9.preheader.i ], [ %21, %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit ]
  %iter2.sroa.0.032.i = phi i64 [ 0, %bb9.preheader.i ], [ %22, %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit ]
  %_24.i = add nuw nsw i64 %iter2.sroa.0.032.i, %_25.i, !dbg !4948
  call void @llvm.experimental.noalias.scope.decl(metadata !4950), !dbg !4953, !noalias !4891
  call void @llvm.experimental.noalias.scope.decl(metadata !4959), !dbg !4962, !noalias !4964
  %14 = load ptr, ptr %_16.i.i.i, align 8, !dbg !4967, !alias.scope !4969, !noalias !4970, !noundef !31
  %.not.i.i.i = icmp eq ptr %14, null, !dbg !4967
  br i1 %.not.i.i.i, label %bb3.i.i.i, label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i, !dbg !4973

bb3.i.i.i:                                        ; preds = %bb24.i
  %view.val.i.i.i = load ptr, ptr %view.i.i.i, align 8, !dbg !4974, !alias.scope !4969, !noalias !4970, !nonnull !31, !align !368, !noundef !31
  %view.val2.i.i.i = load i64, ptr %9, align 8, !dbg !4974, !alias.scope !4969, !noalias !4970, !noundef !31
  %_5.i3.i.i.i = icmp ult i64 %13, %view.val2.i.i.i, !dbg !4975
  call void @llvm.assume(i1 %_5.i3.i.i.i), !dbg !4979, !noalias !4964
  %_4.i.i.i.i = getelementptr inbounds nuw i64, ptr %view.val.i.i.i, i64 %13, !dbg !4980
  br label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i, !dbg !4981

_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i: ; preds = %bb24.i, %bb3.i.i.i
  %_0.sroa.0.0.in.i.i.i = phi ptr [ %_4.i.i.i.i, %bb3.i.i.i ], [ %14, %bb24.i ]
  %_0.sroa.0.0.i.i.i = load i64, ptr %_0.sroa.0.0.in.i.i.i, align 8, !dbg !4982, !noalias !4984, !noundef !31
  call void @llvm.experimental.noalias.scope.decl(metadata !4985), !dbg !4962, !noalias !4964
  %15 = load ptr, ptr %_6.i.i, align 8, !dbg !4988, !alias.scope !4990, !noalias !4970, !noundef !31
  %.not.i1.i.i = icmp eq ptr %15, null, !dbg !4988
  br i1 %.not.i1.i.i, label %bb3.i8.i.i, label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, !dbg !4991

bb3.i8.i.i:                                       ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i
  %view.val.i9.i.i = load ptr, ptr %view.i2.i.i, align 8, !dbg !4992, !alias.scope !4990, !noalias !4970, !nonnull !31, !align !368, !noundef !31
  %view.val2.i10.i.i = load i64, ptr %10, align 8, !dbg !4992, !alias.scope !4990, !noalias !4970, !noundef !31
  %_5.i3.i11.i.i = icmp ult i64 %13, %view.val2.i10.i.i, !dbg !4993
  call void @llvm.assume(i1 %_5.i3.i11.i.i), !dbg !4997, !noalias !4964
  %_4.i.i12.i.i = getelementptr inbounds nuw i64, ptr %view.val.i9.i.i, i64 %13, !dbg !4998
  br label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, !dbg !4999

_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i: ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i, %bb3.i8.i.i
  %_0.sroa.0.0.in.i6.i.i = phi ptr [ %_4.i.i12.i.i, %bb3.i8.i.i ], [ %15, %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i ]
  %_11.i.i.i = icmp ult i64 %_24.i, %_17.1.i.i.i, !dbg !5000
  br i1 %_11.i.i.i, label %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit, label %panic.i.i.i, !dbg !5000

panic.i.i.i:                                      ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i
; call core::panicking::panic_bounds_check
  call void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_24.i, i64 noundef %_17.1.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d179419b0efea413e3bae0e1e9c82584.llvm.2401947754960793252) #21, !dbg !5000, !noalias !4970
  unreachable

_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit: ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i
  %_0.sroa.0.0.i7.i.i = load i64, ptr %_0.sroa.0.0.in.i6.i.i, align 8, !dbg !5001, !noalias !5003, !noundef !31
  %16 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.i, i64 %_0.sroa.0.0.i7.i.i), !dbg !5004
  %_7.0.i.i.i.i.i = extractvalue { i64, i1 } %16, 0, !dbg !5004
  %_8.i.i.i.i.i = icmp sgt i64 %_7.0.i.i.i.i.i, 0, !dbg !5008
  %_7.1.i.i.i.i.i = extractvalue { i64, i1 } %16, 1, !dbg !5004
  %_9.i.i.i = getelementptr inbounds nuw i8, ptr %_18.0.i.i.i, i64 %_24.i, !dbg !5000
  %_21.i.i.i = zext i1 %_8.i.i.i.i.i to i8, !dbg !5009
  store i8 %_21.i.i.i, ptr %_9.i.i.i, align 1, !dbg !5012, !noalias !4970
  %17 = load i8, ptr %_19.i.i.i, align 1, !dbg !5013, !range !581, !alias.scope !5015, !noalias !4970, !noundef !31
  %18 = trunc nuw i8 %17 to i1, !dbg !5013
  %19 = or i1 %_7.1.i.i.i.i.i, %18, !dbg !5013
  %20 = zext i1 %19 to i8, !dbg !5013
  store i8 %20, ptr %_19.i.i.i, align 1, !dbg !5013, !alias.scope !5015, !noalias !4970
  %21 = add i64 %13, 1, !dbg !5018
  store i64 %21, ptr %1, align 8, !dbg !5018, !noalias !5020
  %22 = add nuw nsw i64 %iter2.sroa.0.032.i, 1, !dbg !5021
  %exitcond.not.i = icmp eq i64 %22, 64, !dbg !5027
  br i1 %exitcond.not.i, label %bb3.i.outer.backedge, label %bb24.i, !dbg !4941

bb13.i:                                           ; preds = %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit43, %bb13.lr.ph.i
  %23 = phi i64 [ %.promoted4952.ph, %bb13.lr.ph.i ], [ %32, %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit43 ]
  %word.sroa.0.031.i = phi i64 [ %self.1.pn.i.i.ph.i.i, %bb13.lr.ph.i ], [ %33, %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit43 ]
  %24 = call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %word.sroa.0.031.i, i1 true), !dbg !5030
  %_32.i = or disjoint i64 %24, %_33.i, !dbg !5033
  call void @llvm.experimental.noalias.scope.decl(metadata !5034), !dbg !5037, !noalias !4891
  call void @llvm.experimental.noalias.scope.decl(metadata !5041), !dbg !5044, !noalias !5046
  %25 = load ptr, ptr %_16.i.i.i, align 8, !dbg !5049, !alias.scope !5051, !noalias !5052, !noundef !31
  %.not.i.i.i6 = icmp eq ptr %25, null, !dbg !5049
  br i1 %.not.i.i.i6, label %bb3.i.i.i38, label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i11, !dbg !5055

bb3.i.i.i38:                                      ; preds = %bb13.i
  %view.val.i.i.i39 = load ptr, ptr %view.i.i.i, align 8, !dbg !5056, !alias.scope !5051, !noalias !5052, !nonnull !31, !align !368, !noundef !31
  %view.val2.i.i.i40 = load i64, ptr %9, align 8, !dbg !5056, !alias.scope !5051, !noalias !5052, !noundef !31
  %_5.i3.i.i.i41 = icmp ult i64 %23, %view.val2.i.i.i40, !dbg !5057
  call void @llvm.assume(i1 %_5.i3.i.i.i41), !dbg !5061, !noalias !5046
  %_4.i.i.i.i42 = getelementptr inbounds nuw i64, ptr %view.val.i.i.i39, i64 %23, !dbg !5062
  br label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i11, !dbg !5063

_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i11: ; preds = %bb13.i, %bb3.i.i.i38
  %_0.sroa.0.0.in.i.i.i12 = phi ptr [ %_4.i.i.i.i42, %bb3.i.i.i38 ], [ %25, %bb13.i ]
  %_0.sroa.0.0.i.i.i13 = load i64, ptr %_0.sroa.0.0.in.i.i.i12, align 8, !dbg !5064, !noalias !5066, !noundef !31
  call void @llvm.experimental.noalias.scope.decl(metadata !5067), !dbg !5044, !noalias !5046
  %26 = load ptr, ptr %_6.i.i, align 8, !dbg !5070, !alias.scope !5072, !noalias !5052, !noundef !31
  %.not.i1.i.i15 = icmp eq ptr %26, null, !dbg !5070
  br i1 %.not.i1.i.i15, label %bb3.i8.i.i33, label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i20, !dbg !5073

bb3.i8.i.i33:                                     ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i11
  %view.val.i9.i.i34 = load ptr, ptr %view.i2.i.i, align 8, !dbg !5074, !alias.scope !5072, !noalias !5052, !nonnull !31, !align !368, !noundef !31
  %view.val2.i10.i.i35 = load i64, ptr %10, align 8, !dbg !5074, !alias.scope !5072, !noalias !5052, !noundef !31
  %_5.i3.i11.i.i36 = icmp ult i64 %23, %view.val2.i10.i.i35, !dbg !5075
  call void @llvm.assume(i1 %_5.i3.i11.i.i36), !dbg !5079, !noalias !5046
  %_4.i.i12.i.i37 = getelementptr inbounds nuw i64, ptr %view.val.i9.i.i34, i64 %23, !dbg !5080
  br label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i20, !dbg !5081

_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i20: ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i11, %bb3.i8.i.i33
  %_0.sroa.0.0.in.i6.i.i21 = phi ptr [ %_4.i.i12.i.i37, %bb3.i8.i.i33 ], [ %26, %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i.i11 ]
  %_11.i.i.i23 = icmp ult i64 %_32.i, %_17.1.i.i.i, !dbg !5082
  br i1 %_11.i.i.i23, label %_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit43, label %panic.i.i.i24, !dbg !5082

panic.i.i.i24:                                    ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i20
; call core::panicking::panic_bounds_check
  call void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_32.i, i64 noundef %_17.1.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d179419b0efea413e3bae0e1e9c82584.llvm.2401947754960793252) #21, !dbg !5082, !noalias !5052
  unreachable

_RNvXs1_NtNtNtCslWxY2MhVcag_4core3ops8function5implsQNCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNtNtBb_7convert10InfallibleNCINvMNtBT_5ownedINtBT_7ExecuteB1B_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB2V_INtNtBV_7visitor10RowVisitorB1B_E19visit_deferred_boolB4n_bKB49_NCINvXs1_B3g_B3d_INtB4H_5RowFnB1B_E8dispatchB2V_Es4_0NCB5I_s5_0E0NCB4w_s_0B6x_Es_0Es_0INtB7_5FnMutTjEE8call_mutCskkDzpO6M0zw_10boundaries.exit43: ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i20
  %_0.sroa.0.0.i7.i.i25 = load i64, ptr %_0.sroa.0.0.in.i6.i.i21, align 8, !dbg !5083, !noalias !5085, !noundef !31
  %27 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.i13, i64 %_0.sroa.0.0.i7.i.i25), !dbg !5086
  %_7.0.i.i.i.i.i26 = extractvalue { i64, i1 } %27, 0, !dbg !5086
  %_8.i.i.i.i.i27 = icmp sgt i64 %_7.0.i.i.i.i.i26, 0, !dbg !5090
  %_7.1.i.i.i.i.i28 = extractvalue { i64, i1 } %27, 1, !dbg !5086
  %_9.i.i.i30 = getelementptr inbounds nuw i8, ptr %_18.0.i.i.i, i64 %_32.i, !dbg !5082
  %_21.i.i.i31 = zext i1 %_8.i.i.i.i.i27 to i8, !dbg !5091
  store i8 %_21.i.i.i31, ptr %_9.i.i.i30, align 1, !dbg !5094, !noalias !5052
  %28 = load i8, ptr %_19.i.i.i, align 1, !dbg !5095, !range !581, !alias.scope !5097, !noalias !5052, !noundef !31
  %29 = trunc nuw i8 %28 to i1, !dbg !5095
  %30 = or i1 %_7.1.i.i.i.i.i28, %29, !dbg !5095
  %31 = zext i1 %30 to i8, !dbg !5095
  store i8 %31, ptr %_19.i.i.i, align 1, !dbg !5095, !alias.scope !5097, !noalias !5052
  %32 = add i64 %23, 1, !dbg !5100
  store i64 %32, ptr %1, align 8, !dbg !5100, !noalias !5101
  %_38.i = add i64 %word.sroa.0.031.i, -1, !dbg !5102
  %33 = and i64 %_38.i, %word.sroa.0.031.i, !dbg !5103
  %34 = icmp eq i64 %33, 0, !dbg !4940
  br i1 %34, label %bb3.i.outer.backedge, label %bb13.i, !dbg !4940

_RINvXs_NtCshZi9mpuUhIi_4rofl4hostNtNtNtCs7tX4SdoNkTE_12rofl_kernels3bit4view10BitmapViewNtB5_9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleQNCINvNtB7_7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1R_NCINvMNtB2E_5ownedINtB2E_7ExecuteB36_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB44_INtNtB7_7visitor10RowVisitorB36_E19visit_deferred_boolB5x_bKB5j_NCINvXs1_B4q_B4n_INtB5R_5RowFnB36_E8dispatchB44_Es4_0NCB6S_s5_0E0NCB5G_s_0B7H_Es_0Es_0ECskkDzpO6M0zw_10boundaries.exit: ; preds = %bb5.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %chunks.i), !dbg !5104, !noalias !4898
  call void @llvm.lifetime.end.p0(ptr nonnull %_11), !dbg !5105
  br label %bb6, !dbg !5106

bb3:                                              ; preds = %start
  %35 = getelementptr inbounds nuw i8, ptr %self, i64 48, !dbg !5107
  %_6 = load i64, ptr %35, align 8, !dbg !5107, !noundef !31
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5108), !dbg !5111
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5114), !dbg !5111
  %_0.i.i.i7.i.not = icmp eq i64 %_6, 0, !dbg !5116
  br i1 %_0.i.i.i7.i.not, label %bb6, label %bb3.lr.ph.i, !dbg !5124

bb3.lr.ph.i:                                      ; preds = %bb3
  %.promoted.i = load i64, ptr %1, align 8, !alias.scope !5114, !noalias !5125
  %36 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %_16.i.i.i.i = load ptr, ptr %36, align 8, !alias.scope !5127, !noalias !5130, !nonnull !31, !align !368, !noundef !31
  %37 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %_17.1.i.i.i.i = load i64, ptr %37, align 8, !alias.scope !5108, !noalias !5130
  %38 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %_18.0.i.i.i.i = load ptr, ptr %38, align 8, !alias.scope !5108, !noalias !5130, !nonnull !31
  %39 = getelementptr inbounds nuw i8, ptr %0, i64 40
  %_19.i.i.i.i = load ptr, ptr %39, align 8, !alias.scope !5108, !noalias !5130, !nonnull !31
  %view.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 8
  %_6.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 24
  %view.i2.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 32
  %40 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 16
  %41 = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i, i64 40
  br label %bb3.i1, !dbg !5124

bb3.i1:                                           ; preds = %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3V_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5o_bKB5a_NCINvXs1_B4h_B4e_INtB5I_5RowFnB2X_E8dispatchB3V_Es4_0NCB6K_s5_0E0NCB5x_s_0B7z_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, %bb3.lr.ph.i
  %_0.i1.i.i68.i = phi i64 [ 0, %bb3.lr.ph.i ], [ %_0.i1.i.i.i, %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3V_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5o_bKB5a_NCINvXs1_B4h_B4e_INtB5I_5RowFnB2X_E8dispatchB3V_Es4_0NCB6K_s5_0E0NCB5x_s_0B7z_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i ]
  %42 = phi i64 [ %.promoted.i, %bb3.lr.ph.i ], [ %50, %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3V_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5o_bKB5a_NCINvXs1_B4h_B4e_INtB5I_5RowFnB2X_E8dispatchB3V_Es4_0NCB6K_s5_0E0NCB5x_s_0B7z_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5131), !dbg !5132
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5137), !dbg !5140
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5142), !dbg !5145, !noalias !5147
  %43 = load ptr, ptr %_16.i.i.i.i, align 8, !dbg !5148, !alias.scope !5150, !noalias !5147, !noundef !31
  %.not.i.i = icmp eq ptr %43, null, !dbg !5148
  br i1 %.not.i.i, label %bb3.i.i, label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, !dbg !5151

bb3.i.i:                                          ; preds = %bb3.i1
  %view.val.i.i = load ptr, ptr %view.i.i, align 8, !dbg !5152, !alias.scope !5150, !noalias !5147, !nonnull !31, !align !368, !noundef !31
  %view.val2.i.i = load i64, ptr %40, align 8, !dbg !5152, !alias.scope !5150, !noalias !5147, !noundef !31
  %_5.i3.i.i = icmp ult i64 %42, %view.val2.i.i, !dbg !5153
  tail call void @llvm.assume(i1 %_5.i3.i.i), !dbg !5157, !noalias !5147
  %_4.i.i.i = getelementptr inbounds nuw i64, ptr %view.val.i.i, i64 %42, !dbg !5158
  br label %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, !dbg !5159

_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i: ; preds = %bb3.i1, %bb3.i.i
  %_0.sroa.0.0.in.i.i = phi ptr [ %_4.i.i.i, %bb3.i.i ], [ %43, %bb3.i1 ]
  %_0.sroa.0.0.i.i = load i64, ptr %_0.sroa.0.0.in.i.i, align 8, !dbg !5160, !noalias !5162, !noundef !31
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5163), !dbg !5145, !noalias !5147
  %44 = load ptr, ptr %_6.i, align 8, !dbg !5166, !alias.scope !5168, !noalias !5147, !noundef !31
  %.not.i1.i = icmp eq ptr %44, null, !dbg !5166
  br i1 %.not.i1.i, label %bb3.i8.i, label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit, !dbg !5169

bb3.i8.i:                                         ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i
  %view.val.i9.i = load ptr, ptr %view.i2.i, align 8, !dbg !5170, !alias.scope !5168, !noalias !5147, !nonnull !31, !align !368, !noundef !31
  %view.val2.i10.i = load i64, ptr %41, align 8, !dbg !5170, !alias.scope !5168, !noalias !5147, !noundef !31
  %_5.i3.i11.i = icmp ult i64 %42, %view.val2.i10.i, !dbg !5171
  tail call void @llvm.assume(i1 %_5.i3.i11.i), !dbg !5175, !noalias !5147
  %_4.i.i12.i = getelementptr inbounds nuw i64, ptr %view.val.i9.i, i64 %42, !dbg !5176
  br label %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit, !dbg !5177

_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit: ; preds = %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i, %bb3.i8.i
  %_0.sroa.0.0.in.i6.i = phi ptr [ %_4.i.i12.i, %bb3.i8.i ], [ %44, %_RNvXs0_NtCshZi9mpuUhIi_4rofl5tupleINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit.i ]
  %exitcond.not.i2 = icmp eq i64 %_0.i1.i.i68.i, %_17.1.i.i.i.i, !dbg !5178
  br i1 %exitcond.not.i2, label %panic.i.i.i.i, label %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3V_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5o_bKB5a_NCINvXs1_B4h_B4e_INtB5I_5RowFnB2X_E8dispatchB3V_Es4_0NCB6K_s5_0E0NCB5x_s_0B7z_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, !dbg !5178

panic.i.i.i.i:                                    ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_17.1.i.i.i.i, i64 noundef %_17.1.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d179419b0efea413e3bae0e1e9c82584) #21, !dbg !5178, !noalias !5147
  unreachable

_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3V_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5o_bKB5a_NCINvXs1_B4h_B4e_INtB5I_5RowFnB2X_E8dispatchB3V_Es4_0NCB6K_s5_0E0NCB5x_s_0B7z_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i: ; preds = %_RNvXsb_NtCshZi9mpuUhIi_4rofl5tupleINtB5_11TupleSourceTINtB5_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBQ_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels6source13IndexedSource13get_uncheckedCskkDzpO6M0zw_10boundaries.exit
  %_0.sroa.0.0.i7.i = load i64, ptr %_0.sroa.0.0.in.i6.i, align 8, !dbg !5179, !noalias !5181, !noundef !31
  %_0.i1.i.i.i = add nuw i64 %_0.i1.i.i68.i, 1, !dbg !5182
  %45 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i, i64 %_0.sroa.0.0.i7.i), !dbg !5185
  %_7.0.i.i.i.i.i.i = extractvalue { i64, i1 } %45, 0, !dbg !5185
  %_8.i.i.i.i.i.i = icmp sgt i64 %_7.0.i.i.i.i.i.i, 0, !dbg !5189
  %_7.1.i.i.i.i.i.i = extractvalue { i64, i1 } %45, 1, !dbg !5185
  %_9.i.i.i.i = getelementptr inbounds nuw i8, ptr %_18.0.i.i.i.i, i64 %_0.i1.i.i68.i, !dbg !5178
  %_21.i.i.i.i = zext i1 %_8.i.i.i.i.i.i to i8, !dbg !5190
  store i8 %_21.i.i.i.i, ptr %_9.i.i.i.i, align 1, !dbg !5193, !noalias !5147
  %46 = load i8, ptr %_19.i.i.i.i, align 1, !dbg !5194, !range !581, !alias.scope !5196, !noalias !5147, !noundef !31
  %47 = trunc nuw i8 %46 to i1, !dbg !5194
  %48 = or i1 %_7.1.i.i.i.i.i.i, %47, !dbg !5194
  %49 = zext i1 %48 to i8, !dbg !5194
  store i8 %49, ptr %_19.i.i.i.i, align 1, !dbg !5194, !alias.scope !5196, !noalias !5147
  %50 = add i64 %42, 1, !dbg !5199
  store i64 %50, ptr %1, align 8, !dbg !5199, !alias.scope !5114, !noalias !5125
  %exitcond10.not.i = icmp eq i64 %_0.i1.i.i.i, %_6, !dbg !5116
  br i1 %exitcond10.not.i, label %bb6, label %bb3.i1, !dbg !5124

bb6:                                              ; preds = %_RNCINvNvNtNtNtNtCslWxY2MhVcag_4core4iter6traits8iterator8Iterator12try_for_each4calljINtNtBe_6result6ResultuNtNtBe_7convert10InfallibleENCINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1I_NCINvMNtB2f_5ownedINtB2f_7ExecuteB2X_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3V_INtNtB2h_7visitor10RowVisitorB2X_E19visit_deferred_boolB5o_bKB5a_NCINvXs1_B4h_B4e_INtB5I_5RowFnB2X_E8dispatchB3V_Es4_0NCB6K_s5_0E0NCB5x_s_0B7z_Es_0Es_0E0CskkDzpO6M0zw_10boundaries.exit.i, %bb3, %_RINvXs_NtCshZi9mpuUhIi_4rofl4hostNtNtNtCs7tX4SdoNkTE_12rofl_kernels3bit4view10BitmapViewNtB5_9Selection12try_for_eachNtNtCslWxY2MhVcag_4core7convert10InfallibleQNCINvNtB7_7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostB1R_NCINvMNtB2E_5ownedINtB2E_7ExecuteB36_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB44_INtNtB7_7visitor10RowVisitorB36_E19visit_deferred_boolB5x_bKB5j_NCINvXs1_B4q_B4n_INtB5R_5RowFnB36_E8dispatchB44_Es4_0NCB6S_s5_0E0NCB5G_s_0B7H_Es_0Es_0ECskkDzpO6M0zw_10boundaries.exit
  ret void, !dbg !5201
}