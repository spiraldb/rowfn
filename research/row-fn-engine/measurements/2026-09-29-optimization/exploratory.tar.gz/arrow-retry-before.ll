; target/release/deps/boundaries-3c3a77a76c6fcdfa.boundaries.ecd45eb892372cfc-cgu.00.rcgu.ll
; <rofl::execute::Execute<rofl_arrow::ArrowHost, rofl_examples::functions::PositiveSum<true>> as rofl::visitor::RowVisitor<rofl_arrow::ArrowHost>>::visit_deferred_bool::<(i64, i64), bool, true, <rofl_examples::functions::PositiveSum<true> as rofl::visitor::RowFn<rofl_arrow::ArrowHost>>::dispatch<rofl::execute::Execute<rofl_arrow::ArrowHost, rofl_examples::functions::PositiveSum<true>>>::{closure#6}, <rofl_examples::functions::PositiveSum<true> as rofl::visitor::RowFn<rofl_arrow::ArrowHost>>::dispatch<rofl::execute::Execute<rofl_arrow::ArrowHost, rofl_examples::functions::PositiveSum<true>>>::{closure#7}>
define hidden void @_RINvYINtNtCshZi9mpuUhIi_4rofl7execute7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB8_7visitor10RowVisitorBH_E19visit_deferred_boolTxxEbKB2f_NCINvXs1_B1m_B1j_INtB2n_5RowFnBH_E8dispatchB3_Es4_0NCB3n_s5_0ECskkDzpO6M0zw_10boundaries(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([40 x i8]) align 8 captures(address) dereferenceable(40) %_0, ptr dead_on_return noalias nofree noundef align 8 captures(address) dereferenceable(192) %self) unnamed_addr #0 personality ptr @rust_eh_personality !dbg !22643 {
start:
  %prepared.i.i.i = alloca [0 x i8], align 1
  %_9.i.i.i = alloca [64 x i8], align 8
  %_9.i.i31.i.i = alloca [64 x i8], align 8
  %_39.i.i.i = alloca [32 x i8], align 8
  %_35.i.i.i = alloca [32 x i8], align 8
  %values.i.i.i = alloca [16 x i8], align 8
  %state.i.i.i = alloca [64 x i8], align 8
  %_21.i.i.i = alloca [64 x i8], align 8
  %_20.sroa.5.i.i.i = alloca [56 x i8], align 8
  %_18.i.i.i = alloca [32 x i8], align 8
  %_9.sroa.15.i.i.i = alloca [23 x i8], align 1
  %_8.sroa.6.sroa.9.i.i.i = alloca [23 x i8], align 1
  %columns.i35.i.i = alloca [64 x i8], align 8
  %_9.i.i.i.i = alloca [64 x i8], align 8
  %_8.i.i.i.i.i = alloca [8 x i8], align 8
  %len.i.i.i.i.i = alloca [8 x i8], align 8
  %_9.i.i.i.i.i = alloca [64 x i8], align 8
  %_74.i.i.i.i = alloca [24 x i8], align 8
  %_68.i.i.i.i = alloca [32 x i8], align 8
  %_44.i.i.i.i = alloca [64 x i8], align 8
  %_32.i.i.i.i = alloca [48 x i8], align 8
  %_22.i.i.i.i = alloca [32 x i8], align 8
  %_18.i.i.i.i = alloca [32 x i8], align 8
  %_9.sroa.15.i.i.i.i = alloca [23 x i8], align 1
  %_8.sroa.6.sroa.9.i.i.i.i = alloca [23 x i8], align 1
  %columns.i.i.i.i = alloca [64 x i8], align 8
  %_73.i.i.i = alloca [24 x i8], align 8
  %_67.i.i.i = alloca [32 x i8], align 8
  %_60.i.i.i = alloca [48 x i8], align 8
  %_56.i.i.i = alloca [32 x i8], align 8
  %failure6.i.i.i = alloca [1 x i8], align 1
  %_47.i.i.i = alloca [56 x i8], align 8
  %_37.i.i.i = alloca [32 x i8], align 8
  %_30.i.i.i = alloca [64 x i8], align 8
  %_29.sroa.5.i.i.i = alloca [56 x i8], align 8
  %source.i.i.i = alloca [56 x i8], align 8
  %_26.i.i.i = alloca [32 x i8], align 8
  %_18.sroa.15.i.i.i = alloca [23 x i8], align 1
  %_17.sroa.7.sroa.10.i.i.i = alloca [23 x i8], align 1
  %columns.i.i.i = alloca [64 x i8], align 8
  %_11.i.i.i = alloca [192 x i8], align 8
  %_8.i.i.i = alloca [112 x i8], align 8
  %_6.i.i.i = alloca [32 x i8], align 8
  %_55.i.i = alloca [32 x i8], align 8
  %_50.i.i = alloca [32 x i8], align 8
  %values.i.i = alloca [16 x i8], align 8
  %collect.i.i = alloca [32 x i8], align 8
  %failure.i.i = alloca [1 x i8], align 1
  %_37.i.i = alloca [64 x i8], align 8
  %_36.sroa.5.i.i = alloca [56 x i8], align 8
  %source.i.i = alloca [56 x i8], align 8
  %_33.i.i = alloca [32 x i8], align 8
  %_24.sroa.15.i.i = alloca [23 x i8], align 1
  %_23.sroa.6.sroa.9.i.i = alloca [23 x i8], align 1
  %columns.i.i = alloca [64 x i8], align 8
  %_16.i.i = alloca [192 x i8], align 8
  %_13.i.i = alloca [112 x i8], align 8
  %_11.i.i = alloca [32 x i8], align 8
  %_6.i.i = alloca [192 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22644), !dbg !22647
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22648), !dbg !22647
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22650), !dbg !22653
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22656), !dbg !22653
  call void @llvm.lifetime.start.p0(ptr nonnull %_23.sroa.6.sroa.9.i.i), !dbg !22658
  %_5.i.i = load i64, ptr %self, align 8, !dbg !22658, !range !5768, !alias.scope !22663, !noalias !22664, !noundef !37
  %switch.not.i.i = icmp samesign ult i64 %_5.i.i, 2, !dbg !22665
  br i1 %switch.not.i.i, label %bb1.i.i, label %bb2.i.i, !dbg !22665

bb1.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_11.i.i), !dbg !22666, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %_13.i.i), !dbg !22668, !noalias !22667
; invoke <rofl_arrow::ArrowHost as rofl::output::OutputBinding<bool>>::output_type
  invoke void @_RNvXs1_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB7_9ArrowHostINtNtCshZi9mpuUhIi_4rofl6output13OutputBindingbE11output_type(ptr noalias nofree noundef nonnull sret([112 x i8]) align 8 captures(address) dereferenceable(112) %_13.i.i)
          to label %bb4.i.i unwind label %bb35.thread160.i.i, !dbg !22668

bb2.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.i.i), !dbg !22669, !noalias !22667
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(192) %_6.i.i, ptr noundef nonnull align 8 dereferenceable(192) %self, i64 192, i1 false), !dbg !22669, !noalias !22664
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22670), !dbg !22673
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22674), !dbg !22673
  call void @llvm.lifetime.start.p0(ptr nonnull %_17.sroa.7.sroa.10.i.i.i), !dbg !22676
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.i.i.i), !dbg !22676, !noalias !22679
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i.i), !dbg !22680, !noalias !22679
; invoke <rofl_arrow::ArrowHost as rofl::output::OutputBinding<bool>>::output_type
  invoke void @_RNvXs1_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB7_9ArrowHostINtNtCshZi9mpuUhIi_4rofl6output13OutputBindingbE11output_type(ptr noalias nofree noundef nonnull sret([112 x i8]) align 8 captures(address) dereferenceable(112) %_8.i.i.i)
          to label %bb1.i.i.i unwind label %bb42.thread91.i.i.i, !dbg !22680, !noalias !22681

bb1.i.i.i:                                        ; preds = %bb2.i.i
; invoke <rofl::execute::Execute<rofl_arrow::ArrowHost, rofl_examples::functions::PositiveSum<true>>>::validate::<(i64, i64)>
  invoke fastcc void @_RINvMs_NtCshZi9mpuUhIi_4rofl7executeINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8validateTxxEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 captures(address) dereferenceable(32) %_6.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(192) %_6.i.i, ptr noalias nofree noundef align 8 captures(address) dereferenceable(112) %_8.i.i.i)
          to label %bb2.i.i.i unwind label %bb42.thread91.i.i.i, !dbg !22682

bb2.i.i.i:                                        ; preds = %bb1.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i.i), !dbg !22683, !noalias !22679
  %0 = load i64, ptr %_6.i.i.i, align 8, !dbg !22684, !range !53, !noalias !22679, !noundef !37
  %.not.i.i.i = icmp eq i64 %0, -1, !dbg !22684
  br i1 %.not.i.i.i, label %bb62.i.i.i, label %bb61.i.i.i, !dbg !22687

bb61.i.i.i:                                       ; preds = %bb2.i.i.i
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !22688
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %1, ptr noundef nonnull align 8 dereferenceable(32) %_6.i.i.i, i64 32, i1 false), !dbg !22695, !noalias !22696
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i.i.i), !dbg !22697, !noalias !22679
  store i64 1, ptr %_0, align 8, !dbg !22688, !alias.scope !22698, !noalias !22696
  br label %bb49.critedge.i.i.i, !dbg !22699

bb62.i.i.i:                                       ; preds = %bb2.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i.i.i), !dbg !22697, !noalias !22679
  %_10.i.i.i = load i64, ptr %_6.i.i, align 8, !dbg !22701, !range !5768, !alias.scope !22674, !noalias !22704, !noundef !37
  %2 = icmp eq i64 %_10.i.i.i, 1, !dbg !22705
  br i1 %2, label %bb4.i.i.i, label %bb6.i.i.i, !dbg !22705

bb4.i.i.i:                                        ; preds = %bb62.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_11.i.i.i), !dbg !22706, !noalias !22679
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(192) %_11.i.i.i, ptr noundef nonnull align 8 dereferenceable(192) %_6.i.i, i64 192, i1 false), !dbg !22706, !noalias !22704
  call void @llvm.experimental.noalias.scope.decl(metadata !22707), !dbg !22710
  call void @llvm.experimental.noalias.scope.decl(metadata !22711), !dbg !22710
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.6.sroa.9.i.i.i.i), !dbg !22713
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i.i.i.i), !dbg !22713, !noalias !22716
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.sroa.15.i.i.i.i), !dbg !22717
  call void @llvm.experimental.noalias.scope.decl(metadata !22718), !dbg !22721
  %_3.i.i.i.i.i = load i64, ptr %_11.i.i.i, align 8, !dbg !22722, !range !5768, !alias.scope !22727, !noalias !22728, !noundef !37
  %tolerant.i.i.i.i.i = icmp eq i64 %_3.i.i.i.i.i, 2, !dbg !22730
  br i1 %tolerant.i.i.i.i.i, label %bb1.i.i.i.i.i, label %start.bb4_crit_edge.i.i.i.i.i, !dbg !22731

start.bb4_crit_edge.i.i.i.i.i:                    ; preds = %bb4.i.i.i
  %.phi.trans.insert.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 128
  %_11.0.pre.i.i.i.i.i = load ptr, ptr %.phi.trans.insert.i.i.i.i.i, align 8, !dbg !22733, !alias.scope !22727, !noalias !22728
  %.phi.trans.insert4.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 136
  %_11.1.pre.i.i.i.i.i = load i64, ptr %.phi.trans.insert4.i.i.i.i.i, align 8, !dbg !22733, !alias.scope !22727, !noalias !22728
  br label %bb4.i.i.i.i.i, !dbg !22731

bb4.i.i.i.i.i:                                    ; preds = %bb11.i.i.i.i.i, %start.bb4_crit_edge.i.i.i.i.i
  %_11.1.i.i.i.i.i = phi i64 [ %_11.1.pre.i.i.i.i.i, %start.bb4_crit_edge.i.i.i.i.i ], [ %_10.1.i.i.i.i.i, %bb11.i.i.i.i.i ], !dbg !22733
  %_11.0.i.i.i.i.i = phi ptr [ %_11.0.pre.i.i.i.i.i, %start.bb4_crit_edge.i.i.i.i.i ], [ %_10.0.i.i.i.i.i, %bb11.i.i.i.i.i ], !dbg !22733
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i.i.i), !dbg !22734, !noalias !22735
  %3 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 168, !dbg !22736
  %_12.i.i.i.i.i = load ptr, ptr %3, align 8, !dbg !22736, !alias.scope !22727, !noalias !22728, !nonnull !37, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_9.i.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i.i.i.i, i64 noundef %_11.1.i.i.i.i.i, i1 noundef zeroext %tolerant.i.i.i.i.i, ptr noalias nofree noundef nonnull %_12.i.i.i.i.i)
          to label %.noexc.i.i.i.i unwind label %cleanup.i.i.i.i, !dbg !22734, !noalias !22737

.noexc.i.i.i.i:                                   ; preds = %bb4.i.i.i.i.i
  %4 = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 24, !dbg !22738
  %5 = load i8, ptr %4, align 8, !dbg !22738, !range !248, !noalias !22735, !noundef !37
  %6 = icmp eq i8 %5, 2, !dbg !22738
  br i1 %6, label %bb33.i.i.i.i, label %bb58.i.i.i.i, !dbg !22741

bb1.i.i.i.i.i:                                    ; preds = %bb4.i.i.i
  %7 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 136, !dbg !22742
  %_10.1.i.i.i.i.i = load i64, ptr %7, align 8, !dbg !22742, !alias.scope !22727, !noalias !22728, !noundef !37
  %switch = icmp ult i64 %_10.1.i.i.i.i.i, 2, !dbg !22743
  br i1 %switch, label %panic3.i.invoke, label %bb11.i.i.i.i.i, !dbg !22743

panic3.i.invoke:                                  ; preds = %bb1.i.i.i.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i.i.i.i, i64 noundef %_10.1.i.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i.cont unwind label %cleanup.i.i.i.i, !dbg !22743

panic3.i.cont:                                    ; preds = %panic3.i.invoke
  unreachable

bb11.i.i.i.i.i:                                   ; preds = %bb1.i.i.i.i.i
  %8 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 128, !dbg !22742
  %_10.0.i.i.i.i.i = load ptr, ptr %8, align 8, !dbg !22742, !alias.scope !22727, !noalias !22728, !nonnull !37, !align !40, !noundef !37
  br label %bb4.i.i.i.i.i, !dbg !22746

bb52.i.i.i.i:                                     ; preds = %bb40.i.i.i.i, %bb2.i.i.i.i.i3.i73.i.i.i.i, %cleanup.i69.i.i.i.i, %bb2.i.i.i.i.i3.i.i.i.i.i, %cleanup.i.i.i.i.i, %cleanup.i.i.i.i
  %.pn35.i.i.i.i = phi { ptr, i32 } [ %.pn33.i.i.i.i, %bb40.i.i.i.i ], [ %96, %cleanup.i.i.i.i.i ], [ %12, %cleanup.i.i.i.i ], [ %96, %bb2.i.i.i.i.i3.i.i.i.i.i ], [ %113, %bb2.i.i.i.i.i3.i73.i.i.i.i ], [ %113, %cleanup.i69.i.i.i.i ]
  %9 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 16, !dbg !22747
  %10 = load i64, ptr %9, align 8, !dbg !22749, !range !127, !alias.scope !22751, !noalias !22756, !noundef !37
  %11 = icmp eq i64 %10, -1, !dbg !22749
  br i1 %11, label %common.resume, label %bb2.i.i.i.i.i.i, !dbg !22749

bb2.i.i.i.i.i.i:                                  ; preds = %bb52.i.i.i.i
; invoke core::ptr::drop_glue::<arrow_schema::field::Field>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(112) %9)
          to label %common.resume unwind label %terminate.i.i.i.i, !dbg !22749, !noalias !22757

cleanup.i.i.i.i:                                  ; preds = %panic3.i.invoke, %bb2.i.i.i.i.i8.i67.i.i.i.i, %bb2.i.i.i.i.i8.i.i.i.i.i, %bb4.i.i.i.i.i
  %12 = landingpad { ptr, i32 }
          cleanup
  br label %bb52.i.i.i.i

bb58.i.i.i.i:                                     ; preds = %.noexc.i.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %columns.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(24) %_9.i.i.i.i.i, i64 24, i1 false), !dbg !22758, !noalias !22716
  %_9.sroa.10.0._9.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 25, !dbg !22758
  %val2.sroa.5.0.columns.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 25, !dbg !22759
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %val2.sroa.5.0.columns.sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(7) %_9.sroa.10.0._9.i.sroa_idx.i.i.i.i, i64 7, i1 false), !dbg !22758, !noalias !22716
  %_9.sroa.11.0._9.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 32, !dbg !22758
  %_9.sroa.11.0.copyload.i.i.i.i = load i64, ptr %_9.sroa.11.0._9.i.sroa_idx.i.i.i.i, align 8, !dbg !22758, !noalias !22762
  %_9.sroa.14.0._9.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 40, !dbg !22758
  %_9.sroa.14.0.copyload.i.i.i.i = load i8, ptr %_9.sroa.14.0._9.i.sroa_idx.i.i.i.i, align 8, !dbg !22758, !noalias !22762
  %_9.sroa.15.0._9.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 41, !dbg !22758
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.0._9.i.sroa_idx.i.i.i.i, i64 23, i1 false), !dbg !22758, !noalias !22762
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i.i), !dbg !22763, !noalias !22735
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i.i, i64 23, i1 false), !dbg !22764, !noalias !22716
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.15.i.i.i.i), !dbg !22767
  %val2.sroa.5.sroa.6.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 41, !dbg !22759
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val2.sroa.5.sroa.6.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i.i, i64 23, i1 false), !dbg !22717, !noalias !22716
  %val2.sroa.4.0.columns.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 24, !dbg !22759
  store i8 %5, ptr %val2.sroa.4.0.columns.sroa_idx.i.i.i.i, align 8, !dbg !22759, !noalias !22716
  %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 32, !dbg !22759
  store i64 %_9.sroa.11.0.copyload.i.i.i.i, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i, align 8, !dbg !22759, !noalias !22716
  %val2.sroa.5.sroa.5.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i.i, i64 40, !dbg !22759
  store i8 %_9.sroa.14.0.copyload.i.i.i.i, ptr %val2.sroa.5.sroa.5.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i, align 8, !dbg !22759, !noalias !22716
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.i.i.i.i), !dbg !22768, !noalias !22716
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_18.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i.i.i.i)
          to label %bb4.i.i.i.i unwind label %cleanup11.i.i.i.i, !dbg !22768, !noalias !22737

bb33.i.i.i.i:                                     ; preds = %.noexc.i.i.i.i
  %13 = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 32, !dbg !22770
  %_9.sroa.11.32.copyload81.i.i.i.i = load i64, ptr %13, align 8, !dbg !22770, !noalias !22762
  %_9.sroa.14.32..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 40, !dbg !22770
  %_9.sroa.14.32.copyload82.i.i.i.i = load i8, ptr %_9.sroa.14.32..sroa_idx.i.i.i.i, align 8, !dbg !22770, !noalias !22762
  %_9.sroa.15.32..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i.i, i64 41, !dbg !22770
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.32..sroa_idx.i.i.i.i, i64 23, i1 false), !dbg !22770, !noalias !22762
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i.i), !dbg !22763, !noalias !22735
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i.i, i64 23, i1 false), !dbg !22771, !noalias !22716
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.15.i.i.i.i), !dbg !22767
  %_91.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !22772
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_91.sroa.5.0..sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i.i, i64 23, i1 false), !dbg !22767, !noalias !22779
  %14 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !22780
  store i64 %_9.sroa.11.32.copyload81.i.i.i.i, ptr %14, align 8, !dbg !22780, !alias.scope !22782, !noalias !22779
  %_97.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !22780
  store i8 %_9.sroa.14.32.copyload82.i.i.i.i, ptr %_97.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !22780, !alias.scope !22782, !noalias !22779
  store i64 1, ptr %_0, align 8, !dbg !22783, !alias.scope !22782, !noalias !22779
  br label %bb34.i.i.i.i, !dbg !22785

cleanup11.i.i.i.i:                                ; preds = %bb58.i.i.i.i
  %15 = landingpad { ptr, i32 }
          cleanup
  br label %bb40.i.i.i.i, !dbg !22787

bb4.i.i.i.i:                                      ; preds = %bb58.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.i.i.i.i), !dbg !22787, !noalias !22716
  call void @llvm.lifetime.start.p0(ptr nonnull %_22.i.i.i.i), !dbg !22788, !noalias !22716
  %16 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 184, !dbg !22790
  %_23.i.i.i.i = load i64, ptr %16, align 8, !dbg !22790, !alias.scope !22711, !noalias !22756, !noundef !37
; invoke <rofl_arrow::ArrowHost as rofl::output::OutputBinding<bool>>::allocate
  invoke void @_RNvXs1_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB7_9ArrowHostINtNtCshZi9mpuUhIi_4rofl6output13OutputBindingbE8allocate(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_22.i.i.i.i, i64 noundef %_23.i.i.i.i, ptr noalias nofree noundef nonnull %_12.i.i.i.i.i)
          to label %bb5.i.i.i.i unwind label %cleanup12.i.i.i.i, !dbg !22788, !noalias !22737

cleanup12.i.i.i.i:                                ; preds = %bb4.i.i.i.i
  %17 = landingpad { ptr, i32 }
          cleanup
  br label %bb40.i.i.i.i

bb5.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %18 = load i64, ptr %_22.i.i.i.i, align 8, !dbg !22791, !range !53, !noalias !22716, !noundef !37
  %.not27.i.i.i.i = icmp eq i64 %18, -1, !dbg !22791
  %19 = getelementptr inbounds nuw i8, ptr %_22.i.i.i.i, i64 8, !dbg !22794
  %_21.sroa.6.i.i.i.i.sroa.0.0.copyload = load i64, ptr %19, align 8, !dbg !22794, !noalias !22716
  %_21.sroa.6.i.i.i.i.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_22.i.i.i.i, i64 16, !dbg !22794
  %_21.sroa.6.i.i.i.i.sroa.6.0.copyload = load ptr, ptr %_21.sroa.6.i.i.i.i.sroa.6.0..sroa_idx, align 8, !dbg !22794, !noalias !22716
  %_21.sroa.6.i.i.i.i.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_22.i.i.i.i, i64 24, !dbg !22794
  %_21.sroa.6.i.i.i.i.sroa.7.0.copyload = load i64, ptr %_21.sroa.6.i.i.i.i.sroa.7.0..sroa_idx, align 8, !dbg !22794, !noalias !22716
  call void @llvm.lifetime.end.p0(ptr nonnull %_22.i.i.i.i), !dbg !22795, !noalias !22716
  br i1 %.not27.i.i.i.i, label %bb6.i.i.i.i, label %bb60.i.i.i.i, !dbg !22796

bb60.i.i.i.i:                                     ; preds = %bb5.i.i.i.i
  %_104.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !22797
  store i64 %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, ptr %_104.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !22795, !noalias !22779
  %_21.sroa.6.i.i.i.i.sroa.6.0._104.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !22795
  store ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, ptr %_21.sroa.6.i.i.i.i.sroa.6.0._104.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !22795, !noalias !22779
  %_21.sroa.6.i.i.i.i.sroa.7.0._104.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !22795
  store i64 %_21.sroa.6.i.i.i.i.sroa.7.0.copyload, ptr %_21.sroa.6.i.i.i.i.sroa.7.0._104.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !22795, !noalias !22779
  %20 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !22797
  store i64 %18, ptr %20, align 8, !dbg !22797, !alias.scope !22782, !noalias !22779
  store i64 1, ptr %_0, align 8, !dbg !22797, !alias.scope !22782, !noalias !22779
  br label %bb31.i.i.i.i, !dbg !22803

bb48.thread109.loopexit.split-lp.i.i.i.i:         ; preds = %bb1.i44.i.i.i.i, %bb8.i.i.i.i, %bb3.i.i.i.i.i, %bb64.i.i.i.i, %bb62.i.i.i.i
  %lpad.loopexit.split-lp.i.i.i.i = landingpad { ptr, i32 }
          cleanup
  %21 = icmp eq i64 %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, 0
  br i1 %21, label %bb40.i.i.i.i, label %bb2.i.i.i18, !dbg !22805

bb2.i.i.i18:                                      ; preds = %bb48.thread109.loopexit.split-lp.i.i.i.i
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 noundef %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !22812, !noalias !22817
  br label %bb40.i.i.i.i, !dbg !22820

bb48.i.i.i.i:                                     ; preds = %bb24.i.i.i.i
  %lpad.thr_comm.split-lp.i.i.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb40.i.i.i.i, !dbg !22821

bb6.i.i.i.i:                                      ; preds = %bb5.i.i.i.i
  %22 = icmp ne ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, null
  call void @llvm.assume(i1 %22)
  %_106.not.i.i.i.i = icmp ugt i64 %_23.i.i.i.i, %_21.sroa.6.i.i.i.i.sroa.7.0.copyload
  br i1 %_106.not.i.i.i.i, label %bb64.i.i.i.i, label %bb62.i.i.i.i, !dbg !22822, !prof !11657

bb62.i.i.i.i:                                     ; preds = %bb6.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_32.i.i.i.i), !dbg !22832, !noalias !22716
  %23 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 176, !dbg !22835
  %_34.i.i.i.i = load i64, ptr %23, align 8, !dbg !22835, !alias.scope !22711, !noalias !22756, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::rows_source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE11rows_sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_32.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i.i.i.i, i64 noundef %_34.i.i.i.i)
          to label %bb7.i.i.i.i unwind label %bb48.thread109.loopexit.split-lp.i.i.i.i, !dbg !22832, !noalias !22737

bb64.i.i.i.i:                                     ; preds = %bb6.i.i.i.i
; invoke core::slice::index::slice_index_fail
  invoke void @_RNvNtNtCslWxY2MhVcag_4core5slice5index16slice_index_fail(i64 noundef 0, i64 noundef %_23.i.i.i.i, i64 noundef %_21.sroa.6.i.i.i.i.sroa.7.0.copyload, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_252cd9d951382406ba1527cf23875b08) #22
          to label %unreachable.i.i.i.i unwind label %bb48.thread109.loopexit.split-lp.i.i.i.i, !dbg !22836, !noalias !22737

bb7.i.i.i.i:                                      ; preds = %bb62.i.i.i.i
  %_114.i.i.i.i = load i64, ptr %_32.i.i.i.i, align 8, !dbg !22837, !range !4730, !noalias !22716, !noundef !37
  %24 = trunc nuw i64 %_114.i.i.i.i to i1, !dbg !22840
  %25 = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 8, !dbg !22841
  %_116.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 16, !dbg !22841
  %_116.sroa.0.0.copyload.i.i.i.i = load ptr, ptr %25, align 8, !dbg !22841, !noalias !22716
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.0.0.copyload103 = load i64, ptr %_116.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !22841, !noalias !22716
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0._116.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx105 = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 24, !dbg !22841
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106 = load ptr, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0._116.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx105, align 8, !dbg !22841, !noalias !22716
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0._116.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx108 = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 32, !dbg !22841
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109 = load i64, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0._116.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx108, align 8, !dbg !22841, !noalias !22716
  br i1 %24, label %bb67.i.i.i.i, label %bb68.i.i.i.i, !dbg !22840

bb67.i.i.i.i:                                     ; preds = %bb7.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_32.i.i.i.i), !dbg !22842, !noalias !22716
  %_119.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !22843
  store i64 %_31.sroa.6.sroa.8.i.i.i.i.sroa.0.0.copyload103, ptr %_119.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !22842, !noalias !22779
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0._119.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !22842
  store ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0._119.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !22842, !noalias !22779
  br label %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecINtNtNtB4_3mem12maybe_uninit11MaybeUninitbEEECskkDzpO6M0zw_10boundaries.exit.i57.i.i.i.i, !dbg !22849

bb68.i.i.i.i:                                     ; preds = %bb7.i.i.i.i
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.8.0._116.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_32.i.i.i.i, i64 40, !dbg !22851
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.8.0.copyload = load i64, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.8.0._116.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !22851, !noalias !22716
  call void @llvm.lifetime.end.p0(ptr nonnull %_32.i.i.i.i), !dbg !22842, !noalias !22716
  %.not28.i.i.i.i = icmp eq ptr %_116.sroa.0.0.copyload.i.i.i.i, null, !dbg !22832
  br i1 %.not28.i.i.i.i, label %bb8.i.i.i.i, label %bb9.i.i.i.i, !dbg !22852

bb9.i.i.i.i:                                      ; preds = %bb68.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !22853), !dbg !22856
  call void @llvm.lifetime.start.p0(ptr nonnull %len.i.i.i.i.i), !dbg !22857, !noalias !22861
  store i64 %_31.sroa.6.sroa.8.i.i.i.i.sroa.8.0.copyload, ptr %len.i.i.i.i.i, align 8, !dbg !22863, !noalias !22861
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.i.i.i.i.i), !dbg !22864, !noalias !22861
  store i64 %_23.i.i.i.i, ptr %_8.i.i.i.i.i, align 8, !dbg !22864, !noalias !22861
  %_10.i.i.i.i.i = icmp eq i64 %_23.i.i.i.i, %_31.sroa.6.sroa.8.i.i.i.i.sroa.8.0.copyload, !dbg !22866
  br i1 %_10.i.i.i.i.i, label %bb2.i.i.i.i.i, label %bb3.i.i.i.i.i, !dbg !22866, !prof !10472

bb3.i.i.i.i.i:                                    ; preds = %bb9.i.i.i.i
; invoke core::panicking::assert_failed::<usize, usize>
  invoke void @_RINvNtCslWxY2MhVcag_4core9panicking13assert_failedjjEB4_(i8 noundef 0, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_8.i.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %len.i.i.i.i.i, ptr noundef nonnull @alloc_f0da620865384e74e3a64c84279d94d6, ptr nonnull inttoptr (i64 79 to ptr), ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_663aae77909ce95fdbc532a547f60383) #22
          to label %.noexc40.i.i.i.i unwind label %bb48.thread109.loopexit.split-lp.i.i.i.i, !dbg !22869, !noalias !22737

.noexc40.i.i.i.i:                                 ; preds = %bb3.i.i.i.i.i
  unreachable

bb2.i.i.i.i.i:                                    ; preds = %bb9.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.i.i.i.i.i), !dbg !22872, !noalias !22861
  %_365.not.i.i.i.i.i = icmp eq i64 %_23.i.i.i.i, 0, !dbg !22873
  br i1 %_365.not.i.i.i.i.i, label %bb10.thread.i.i.i.i, label %bb15.i.i.i.i.i.preheader, !dbg !22883

bb15.i.i.i.i.i.preheader:                         ; preds = %bb2.i.i.i.i.i
  %26 = icmp ne ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106, null
  call void @llvm.assume(i1 %26)
  %xtraiter = and i64 %_23.i.i.i.i, 3, !dbg !22883
  %27 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !22883
  br i1 %27, label %bb15.i.i.i.i.i.epil.preheader, label %bb15.i.i.i.i.i.preheader.new, !dbg !22883

bb15.i.i.i.i.i.preheader.new:                     ; preds = %bb15.i.i.i.i.i.preheader
  %unroll_iter = and i64 %_23.i.i.i.i, -4, !dbg !22883
  br label %bb15.i.i.i.i.i, !dbg !22883

bb10.thread.i.i.i.i:                              ; preds = %bb2.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %len.i.i.i.i.i), !dbg !22884, !noalias !22861
  br label %bb22.thread.sink.split.i.i.i.i, !dbg !22885

bb15.i.i.i.i.i:                                   ; preds = %bb15.i.i.i.i.i, %bb15.i.i.i.i.i.preheader.new
  %iter.sroa.0.07.i.i.i.i.i = phi i64 [ 0, %bb15.i.i.i.i.i.preheader.new ], [ %37, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i.1 = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %33, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i.2 = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %36, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i.3 = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %39, %bb15.i.i.i.i.i ]
  %failed.sroa.0.0.off06.i.i.i.i.i = phi i1 [ false, %bb15.i.i.i.i.i.preheader.new ], [ %30, %bb15.i.i.i.i.i ]
  %niter = phi i64 [ 0, %bb15.i.i.i.i.i.preheader.new ], [ %niter.next.3, %bb15.i.i.i.i.i ]
  %_5.i.i.i19 = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i, %_31.sroa.6.sroa.8.i.i.i.i.sroa.0.0.copyload103, !dbg !22889
  call void @llvm.assume(i1 %_5.i.i.i19), !dbg !22898, !noalias !22737
  %_4.i.i.i = getelementptr inbounds nuw i64, ptr %_116.sroa.0.0.copyload.i.i.i.i, i64 %iter.sroa.0.07.i.i.i.i.i, !dbg !22899
  %_0.i.i.i = load i64, ptr %_4.i.i.i, align 8, !dbg !22900, !noalias !22901, !noundef !37
  %_5.i.i3.i = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i, %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109, !dbg !22904
  call void @llvm.assume(i1 %_5.i.i3.i), !dbg !22909, !noalias !22737
  %_4.i.i4.i = getelementptr inbounds nuw i64, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106, i64 %iter.sroa.0.07.i.i.i.i.i, !dbg !22910
  %_0.i.i5.i = load i64, ptr %_4.i.i4.i, align 8, !dbg !22911, !noalias !22901, !noundef !37
  %28 = or disjoint i64 %iter.sroa.0.07.i.i.i.i.i, 1, !dbg !22912
  %29 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i, i64 %_0.i.i5.i), !dbg !22918
  %_7.0.i.i.i.i.i.i.i.i = extractvalue { i64, i1 } %29, 0, !dbg !22918
  %_7.1.i.i.i.i.i.i.i.i = extractvalue { i64, i1 } %29, 1, !dbg !22918
  %_8.i.i.i.i.i.i.i.i = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i, 0, !dbg !22925
  %30 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i, %_7.1.i.i.i.i.i.i.i.i, !dbg !22926
  %_40.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 %iter.sroa.0.07.i.i.i.i.i, !dbg !22929
  %_41.i.i.i.i.i = zext i1 %_8.i.i.i.i.i.i.i.i to i8, !dbg !22934
  store i8 %_41.i.i.i.i.i, ptr %_40.i.i.i.i.i, align 1, !dbg !22939, !alias.scope !22853, !noalias !22940
  %_5.i.i.i19.1 = icmp ult i64 %28, %_31.sroa.6.sroa.8.i.i.i.i.sroa.0.0.copyload103, !dbg !22889
  call void @llvm.assume(i1 %_5.i.i.i19.1), !dbg !22898, !noalias !22737
  %_4.i.i.i.1 = getelementptr inbounds nuw i64, ptr %_116.sroa.0.0.copyload.i.i.i.i, i64 %28, !dbg !22899
  %_0.i.i.i.1 = load i64, ptr %_4.i.i.i.1, align 8, !dbg !22900, !noalias !22901, !noundef !37
  %_5.i.i3.i.1 = icmp ult i64 %28, %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109, !dbg !22904
  call void @llvm.assume(i1 %_5.i.i3.i.1), !dbg !22909, !noalias !22737
  %_4.i.i4.i.1 = getelementptr inbounds nuw i64, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106, i64 %28, !dbg !22910
  %_0.i.i5.i.1 = load i64, ptr %_4.i.i4.i.1, align 8, !dbg !22911, !noalias !22901, !noundef !37
  %31 = or disjoint i64 %iter.sroa.0.07.i.i.i.i.i, 2, !dbg !22912
  %32 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.1, i64 %_0.i.i5.i.1), !dbg !22918
  %_7.0.i.i.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %32, 0, !dbg !22918
  %_7.1.i.i.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %32, 1, !dbg !22918
  %_8.i.i.i.i.i.i.i.i.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.1, 0, !dbg !22925
  %33 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.1, %_7.1.i.i.i.i.i.i.i.i.1, !dbg !22926
  %_40.i.i.i.i.i.1 = getelementptr inbounds nuw i8, ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 %28, !dbg !22929
  %_41.i.i.i.i.i.1 = zext i1 %_8.i.i.i.i.i.i.i.i.1 to i8, !dbg !22934
  store i8 %_41.i.i.i.i.i.1, ptr %_40.i.i.i.i.i.1, align 1, !dbg !22939, !alias.scope !22853, !noalias !22940
  %_5.i.i.i19.2 = icmp ult i64 %31, %_31.sroa.6.sroa.8.i.i.i.i.sroa.0.0.copyload103, !dbg !22889
  call void @llvm.assume(i1 %_5.i.i.i19.2), !dbg !22898, !noalias !22737
  %_4.i.i.i.2 = getelementptr inbounds nuw i64, ptr %_116.sroa.0.0.copyload.i.i.i.i, i64 %31, !dbg !22899
  %_0.i.i.i.2 = load i64, ptr %_4.i.i.i.2, align 8, !dbg !22900, !noalias !22901, !noundef !37
  %_5.i.i3.i.2 = icmp ult i64 %31, %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109, !dbg !22904
  call void @llvm.assume(i1 %_5.i.i3.i.2), !dbg !22909, !noalias !22737
  %_4.i.i4.i.2 = getelementptr inbounds nuw i64, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106, i64 %31, !dbg !22910
  %_0.i.i5.i.2 = load i64, ptr %_4.i.i4.i.2, align 8, !dbg !22911, !noalias !22901, !noundef !37
  %34 = or disjoint i64 %iter.sroa.0.07.i.i.i.i.i, 3, !dbg !22912
  %35 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.2, i64 %_0.i.i5.i.2), !dbg !22918
  %_7.0.i.i.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %35, 0, !dbg !22918
  %_7.1.i.i.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %35, 1, !dbg !22918
  %_8.i.i.i.i.i.i.i.i.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.2, 0, !dbg !22925
  %36 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.2, %_7.1.i.i.i.i.i.i.i.i.2, !dbg !22926
  %_40.i.i.i.i.i.2 = getelementptr inbounds nuw i8, ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 %31, !dbg !22929
  %_41.i.i.i.i.i.2 = zext i1 %_8.i.i.i.i.i.i.i.i.2 to i8, !dbg !22934
  store i8 %_41.i.i.i.i.i.2, ptr %_40.i.i.i.i.i.2, align 1, !dbg !22939, !alias.scope !22853, !noalias !22940
  %_5.i.i.i19.3 = icmp ult i64 %34, %_31.sroa.6.sroa.8.i.i.i.i.sroa.0.0.copyload103, !dbg !22889
  call void @llvm.assume(i1 %_5.i.i.i19.3), !dbg !22898, !noalias !22737
  %_4.i.i.i.3 = getelementptr inbounds nuw i64, ptr %_116.sroa.0.0.copyload.i.i.i.i, i64 %34, !dbg !22899
  %_0.i.i.i.3 = load i64, ptr %_4.i.i.i.3, align 8, !dbg !22900, !noalias !22901, !noundef !37
  %_5.i.i3.i.3 = icmp ult i64 %34, %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109, !dbg !22904
  call void @llvm.assume(i1 %_5.i.i3.i.3), !dbg !22909, !noalias !22737
  %_4.i.i4.i.3 = getelementptr inbounds nuw i64, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106, i64 %34, !dbg !22910
  %_0.i.i5.i.3 = load i64, ptr %_4.i.i4.i.3, align 8, !dbg !22911, !noalias !22901, !noundef !37
  %37 = add nuw i64 %iter.sroa.0.07.i.i.i.i.i, 4, !dbg !22912
  %38 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.3, i64 %_0.i.i5.i.3), !dbg !22918
  %_7.0.i.i.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %38, 0, !dbg !22918
  %_7.1.i.i.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %38, 1, !dbg !22918
  %_8.i.i.i.i.i.i.i.i.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.3, 0, !dbg !22925
  %39 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.3, %_7.1.i.i.i.i.i.i.i.i.3, !dbg !22926
  %_40.i.i.i.i.i.3 = getelementptr inbounds nuw i8, ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 %34, !dbg !22929
  %_41.i.i.i.i.i.3 = zext i1 %_8.i.i.i.i.i.i.i.i.3 to i8, !dbg !22934
  store i8 %_41.i.i.i.i.i.3, ptr %_40.i.i.i.i.i.3, align 1, !dbg !22939, !alias.scope !22853, !noalias !22940
  %niter.next.3 = add i64 %niter, 4, !dbg !22883
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter, !dbg !22883
  br i1 %niter.ncmp.3, label %bb10.i.i.i.i.unr-lcssa, label %bb15.i.i.i.i.i, !dbg !22883

bb8.i.i.i.i:                                      ; preds = %bb68.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_44.i.i.i.i), !dbg !22941, !noalias !22716
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_44.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i.i.i.i, i64 noundef %_34.i.i.i.i)
          to label %bb11.i.i.i.i unwind label %bb48.thread109.loopexit.split-lp.i.i.i.i, !dbg !22941, !noalias !22737

bb10.i.i.i.i.unr-lcssa:                           ; preds = %bb15.i.i.i.i.i
  %bin.rdx = or i1 %33, %30, !dbg !22883
  %bin.rdx180 = or i1 %36, %bin.rdx, !dbg !22883
  %bin.rdx181 = or i1 %39, %bin.rdx180, !dbg !22883
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0, !dbg !22883
  br i1 %lcmp.mod.not, label %bb10.i.i.i.i, label %bb15.i.i.i.i.i.epil.preheader, !dbg !22883

bb15.i.i.i.i.i.epil.preheader:                    ; preds = %bb10.i.i.i.i.unr-lcssa, %bb15.i.i.i.i.i.preheader
  %iter.sroa.0.07.i.i.i.i.i.epil.init = phi i64 [ 0, %bb15.i.i.i.i.i.preheader ], [ %37, %bb10.i.i.i.i.unr-lcssa ]
  %failed.sroa.0.0.off06.i.i.i.i.i.epil.init = phi i1 [ false, %bb15.i.i.i.i.i.preheader ], [ %bin.rdx181, %bb10.i.i.i.i.unr-lcssa ]
  %lcmp.mod179 = icmp ne i64 %xtraiter, 0, !dbg !22883
  call void @llvm.assume(i1 %lcmp.mod179), !dbg !22883
  br label %bb15.i.i.i.i.i.epil, !dbg !22883

bb15.i.i.i.i.i.epil:                              ; preds = %bb15.i.i.i.i.i.epil, %bb15.i.i.i.i.i.epil.preheader
  %iter.sroa.0.07.i.i.i.i.i.epil = phi i64 [ %40, %bb15.i.i.i.i.i.epil ], [ %iter.sroa.0.07.i.i.i.i.i.epil.init, %bb15.i.i.i.i.i.epil.preheader ]
  %failed.sroa.0.0.off06.i.i.i.i.i.epil = phi i1 [ %42, %bb15.i.i.i.i.i.epil ], [ %failed.sroa.0.0.off06.i.i.i.i.i.epil.init, %bb15.i.i.i.i.i.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %bb15.i.i.i.i.i.epil ], [ 0, %bb15.i.i.i.i.i.epil.preheader ]
  %_5.i.i.i19.epil = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i.epil, %_31.sroa.6.sroa.8.i.i.i.i.sroa.0.0.copyload103, !dbg !22889
  call void @llvm.assume(i1 %_5.i.i.i19.epil), !dbg !22898, !noalias !22737
  %_4.i.i.i.epil = getelementptr inbounds nuw i64, ptr %_116.sroa.0.0.copyload.i.i.i.i, i64 %iter.sroa.0.07.i.i.i.i.i.epil, !dbg !22899
  %_0.i.i.i.epil = load i64, ptr %_4.i.i.i.epil, align 8, !dbg !22900, !noalias !22901, !noundef !37
  %_5.i.i3.i.epil = icmp ult i64 %iter.sroa.0.07.i.i.i.i.i.epil, %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109, !dbg !22904
  call void @llvm.assume(i1 %_5.i.i3.i.epil), !dbg !22909, !noalias !22737
  %_4.i.i4.i.epil = getelementptr inbounds nuw i64, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.6.0.copyload106, i64 %iter.sroa.0.07.i.i.i.i.i.epil, !dbg !22910
  %_0.i.i5.i.epil = load i64, ptr %_4.i.i4.i.epil, align 8, !dbg !22911, !noalias !22901, !noundef !37
  %40 = add nuw i64 %iter.sroa.0.07.i.i.i.i.i.epil, 1, !dbg !22912
  %41 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.i.i.i.epil, i64 %_0.i.i5.i.epil), !dbg !22918
  %_7.0.i.i.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %41, 0, !dbg !22918
  %_7.1.i.i.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %41, 1, !dbg !22918
  %_8.i.i.i.i.i.i.i.i.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.i.i.epil, 0, !dbg !22925
  %42 = or i1 %failed.sroa.0.0.off06.i.i.i.i.i.epil, %_7.1.i.i.i.i.i.i.i.i.epil, !dbg !22926
  %_40.i.i.i.i.i.epil = getelementptr inbounds nuw i8, ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 %iter.sroa.0.07.i.i.i.i.i.epil, !dbg !22929
  %_41.i.i.i.i.i.epil = zext i1 %_8.i.i.i.i.i.i.i.i.epil to i8, !dbg !22934
  store i8 %_41.i.i.i.i.i.epil, ptr %_40.i.i.i.i.i.epil, align 1, !dbg !22939, !alias.scope !22853, !noalias !22940
  %epil.iter.next = add i64 %epil.iter, 1, !dbg !22883
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter, !dbg !22883
  br i1 %epil.iter.cmp.not, label %bb10.i.i.i.i, label %bb15.i.i.i.i.i.epil, !dbg !22883, !llvm.loop !22942

bb10.i.i.i.i:                                     ; preds = %bb15.i.i.i.i.i.epil, %bb10.i.i.i.i.unr-lcssa
  %.lcssa177 = phi i1 [ %bin.rdx181, %bb10.i.i.i.i.unr-lcssa ], [ %42, %bb15.i.i.i.i.i.epil ], !dbg !22926
  call void @llvm.lifetime.end.p0(ptr nonnull %len.i.i.i.i.i), !dbg !22884, !noalias !22861
  call void @llvm.lifetime.start.p0(ptr nonnull %_68.i.i.i.i), !dbg !22943, !noalias !22716
  br i1 %.lcssa177, label %bb1.i44.i.i.i.i, label %bb24.i.i.i.i, !dbg !22885, !prof !11773

bb21.i.i.i.i.loopexit.unr-lcssa:                  ; preds = %bb15.i.i.i.i.us.us
  %bin.rdx219 = or i1 %60, %58, !dbg !22944
  %bin.rdx220 = or i1 %62, %bin.rdx219, !dbg !22944
  %bin.rdx221 = or i1 %64, %bin.rdx220, !dbg !22944
  %lcmp.mod214.not = icmp eq i64 %xtraiter212, 0, !dbg !22944
  br i1 %lcmp.mod214.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.us.us.epil.preheader, !dbg !22944

bb15.i.i.i.i.us.us.epil.preheader:                ; preds = %bb21.i.i.i.i.loopexit.unr-lcssa, %bb15.i.i.i.i.us.us.preheader
  %failure10.sroa.0.0.off0123.i.i.i.i.us.us.epil.init = phi i1 [ false, %bb15.i.i.i.i.us.us.preheader ], [ %bin.rdx221, %bb21.i.i.i.i.loopexit.unr-lcssa ]
  %iter.sroa.0.0122.i.i.i.i.us.us.epil.init = phi ptr [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.us.us.preheader ], [ %_17.i.i.i.i.i.i.us.us.3, %bb21.i.i.i.i.loopexit.unr-lcssa ]
  %iter.sroa.7.0121.i.i.i.i.us.us.epil.init = phi i64 [ 0, %bb15.i.i.i.i.us.us.preheader ], [ %_9.0.i.i.i.i.i.us.us.3, %bb21.i.i.i.i.loopexit.unr-lcssa ]
  %lcmp.mod216 = icmp ne i64 %xtraiter212, 0, !dbg !22944
  call void @llvm.assume(i1 %lcmp.mod216), !dbg !22944
  br label %bb15.i.i.i.i.us.us.epil, !dbg !22944

bb15.i.i.i.i.us.us.epil:                          ; preds = %bb15.i.i.i.i.us.us.epil, %bb15.i.i.i.i.us.us.epil.preheader
  %failure10.sroa.0.0.off0123.i.i.i.i.us.us.epil = phi i1 [ %44, %bb15.i.i.i.i.us.us.epil ], [ %failure10.sroa.0.0.off0123.i.i.i.i.us.us.epil.init, %bb15.i.i.i.i.us.us.epil.preheader ]
  %iter.sroa.0.0122.i.i.i.i.us.us.epil = phi ptr [ %_17.i.i.i.i.i.i.us.us.epil, %bb15.i.i.i.i.us.us.epil ], [ %iter.sroa.0.0122.i.i.i.i.us.us.epil.init, %bb15.i.i.i.i.us.us.epil.preheader ]
  %iter.sroa.7.0121.i.i.i.i.us.us.epil = phi i64 [ %_9.0.i.i.i.i.i.us.us.epil, %bb15.i.i.i.i.us.us.epil ], [ %iter.sroa.7.0121.i.i.i.i.us.us.epil.init, %bb15.i.i.i.i.us.us.epil.preheader ]
  %epil.iter213 = phi i64 [ %epil.iter213.next, %bb15.i.i.i.i.us.us.epil ], [ 0, %bb15.i.i.i.i.us.us.epil.preheader ]
  %_5.i3.i.i.us.us.epil = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us.us.epil, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.epil), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.us.epil = getelementptr inbounds nuw i64, ptr %54, i64 %iter.sroa.7.0121.i.i.i.i.us.us.epil, !dbg !22958
  %_0.sroa.0.0.i.i.us.us.epil = load i64, ptr %_4.i.i.i25.us.us.epil, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us.us.epil = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us.us.epil, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.epil), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us.us.epil = getelementptr inbounds nuw i64, ptr %55, i64 %iter.sroa.7.0121.i.i.i.i.us.us.epil, !dbg !22972
  %_0.sroa.0.0.i7.i.us.us.epil = load i64, ptr %_4.i.i12.i.us.us.epil, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.us.epil = add nuw i64 %iter.sroa.7.0121.i.i.i.i.us.us.epil, 1, !dbg !22978
  %_17.i.i.i.i.i.i.us.us.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us.us.epil, i64 1, !dbg !22979
  %43 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.epil, i64 %_0.sroa.0.0.i7.i.us.us.epil), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.us.epil = extractvalue { i64, i1 } %43, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.us.epil = extractvalue { i64, i1 } %43, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.us.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.epil, 0, !dbg !22985
  %_135.i.i.i.i.us.us.epil = zext i1 %_8.i.i.i.i.i.i.us.us.epil to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.us.epil, ptr %iter.sroa.0.0122.i.i.i.i.us.us.epil, align 1, !dbg !22992, !noalias !22737
  %44 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.us.epil, %_7.1.i.i.i.i.i.i.us.us.epil, !dbg !22993
  %epil.iter213.next = add i64 %epil.iter213, 1, !dbg !22944
  %epil.iter213.cmp.not = icmp eq i64 %epil.iter213.next, %xtraiter212, !dbg !22944
  br i1 %epil.iter213.cmp.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.us.us.epil, !dbg !22944, !llvm.loop !22995

bb21.i.i.i.i.loopexit171.unr-lcssa:               ; preds = %bb15.i.i.i.i.us
  %bin.rdx209 = or i1 %69, %67, !dbg !22944
  %bin.rdx210 = or i1 %71, %bin.rdx209, !dbg !22944
  %bin.rdx211 = or i1 %73, %bin.rdx210, !dbg !22944
  %lcmp.mod204.not = icmp eq i64 %xtraiter202, 0, !dbg !22944
  br i1 %lcmp.mod204.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.us.epil.preheader, !dbg !22944

bb15.i.i.i.i.us.epil.preheader:                   ; preds = %bb21.i.i.i.i.loopexit171.unr-lcssa, %bb15.i.i.i.i.preheader.split.us.split
  %failure10.sroa.0.0.off0123.i.i.i.i.us.epil.init = phi i1 [ false, %bb15.i.i.i.i.preheader.split.us.split ], [ %bin.rdx211, %bb21.i.i.i.i.loopexit171.unr-lcssa ]
  %iter.sroa.0.0122.i.i.i.i.us.epil.init = phi ptr [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.preheader.split.us.split ], [ %_17.i.i.i.i.i.i.us.3, %bb21.i.i.i.i.loopexit171.unr-lcssa ]
  %iter.sroa.7.0121.i.i.i.i.us.epil.init = phi i64 [ 0, %bb15.i.i.i.i.preheader.split.us.split ], [ %_9.0.i.i.i.i.i.us.3, %bb21.i.i.i.i.loopexit171.unr-lcssa ]
  %lcmp.mod206 = icmp ne i64 %xtraiter202, 0, !dbg !22944
  call void @llvm.assume(i1 %lcmp.mod206), !dbg !22944
  br label %bb15.i.i.i.i.us.epil, !dbg !22944

bb15.i.i.i.i.us.epil:                             ; preds = %bb15.i.i.i.i.us.epil, %bb15.i.i.i.i.us.epil.preheader
  %failure10.sroa.0.0.off0123.i.i.i.i.us.epil = phi i1 [ %46, %bb15.i.i.i.i.us.epil ], [ %failure10.sroa.0.0.off0123.i.i.i.i.us.epil.init, %bb15.i.i.i.i.us.epil.preheader ]
  %iter.sroa.0.0122.i.i.i.i.us.epil = phi ptr [ %_17.i.i.i.i.i.i.us.epil, %bb15.i.i.i.i.us.epil ], [ %iter.sroa.0.0122.i.i.i.i.us.epil.init, %bb15.i.i.i.i.us.epil.preheader ]
  %iter.sroa.7.0121.i.i.i.i.us.epil = phi i64 [ %_9.0.i.i.i.i.i.us.epil, %bb15.i.i.i.i.us.epil ], [ %iter.sroa.7.0121.i.i.i.i.us.epil.init, %bb15.i.i.i.i.us.epil.preheader ]
  %epil.iter203 = phi i64 [ %epil.iter203.next, %bb15.i.i.i.i.us.epil ], [ 0, %bb15.i.i.i.i.us.epil.preheader ]
  %_5.i3.i.i.us.epil = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us.epil, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.epil), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.epil = getelementptr inbounds nuw i64, ptr %54, i64 %iter.sroa.7.0121.i.i.i.i.us.epil, !dbg !22958
  %_0.sroa.0.0.i.i.us.epil = load i64, ptr %_4.i.i.i25.us.epil, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.us.epil = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.epil = add nuw i64 %iter.sroa.7.0121.i.i.i.i.us.epil, 1, !dbg !22978
  %_17.i.i.i.i.i.i.us.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us.epil, i64 1, !dbg !22979
  %45 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.epil, i64 %_0.sroa.0.0.i7.i.us.epil), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.epil = extractvalue { i64, i1 } %45, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.epil = extractvalue { i64, i1 } %45, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.epil, 0, !dbg !22985
  %_135.i.i.i.i.us.epil = zext i1 %_8.i.i.i.i.i.i.us.epil to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.epil, ptr %iter.sroa.0.0122.i.i.i.i.us.epil, align 1, !dbg !22992, !noalias !22737
  %46 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.epil, %_7.1.i.i.i.i.i.i.us.epil, !dbg !22993
  %epil.iter203.next = add i64 %epil.iter203, 1, !dbg !22944
  %epil.iter203.cmp.not = icmp eq i64 %epil.iter203.next, %xtraiter202, !dbg !22944
  br i1 %epil.iter203.cmp.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.us.epil, !dbg !22944, !llvm.loop !22996

bb21.i.i.i.i.loopexit173.unr-lcssa:               ; preds = %bb15.i.i.i.i.us112
  %bin.rdx199 = or i1 %78, %76, !dbg !22944
  %bin.rdx200 = or i1 %80, %bin.rdx199, !dbg !22944
  %bin.rdx201 = or i1 %82, %bin.rdx200, !dbg !22944
  %lcmp.mod194.not = icmp eq i64 %xtraiter192, 0, !dbg !22944
  br i1 %lcmp.mod194.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.us112.epil.preheader, !dbg !22944

bb15.i.i.i.i.us112.epil.preheader:                ; preds = %bb21.i.i.i.i.loopexit173.unr-lcssa, %bb15.i.i.i.i.us112.preheader
  %failure10.sroa.0.0.off0123.i.i.i.i.us113.epil.init = phi i1 [ false, %bb15.i.i.i.i.us112.preheader ], [ %bin.rdx201, %bb21.i.i.i.i.loopexit173.unr-lcssa ]
  %iter.sroa.0.0122.i.i.i.i.us114.epil.init = phi ptr [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.us112.preheader ], [ %_17.i.i.i.i.i.i.us124.3, %bb21.i.i.i.i.loopexit173.unr-lcssa ]
  %iter.sroa.7.0121.i.i.i.i.us115.epil.init = phi i64 [ 0, %bb15.i.i.i.i.us112.preheader ], [ %_9.0.i.i.i.i.i.us123.3, %bb21.i.i.i.i.loopexit173.unr-lcssa ]
  %lcmp.mod196 = icmp ne i64 %xtraiter192, 0, !dbg !22944
  call void @llvm.assume(i1 %lcmp.mod196), !dbg !22944
  br label %bb15.i.i.i.i.us112.epil, !dbg !22944

bb15.i.i.i.i.us112.epil:                          ; preds = %bb15.i.i.i.i.us112.epil, %bb15.i.i.i.i.us112.epil.preheader
  %failure10.sroa.0.0.off0123.i.i.i.i.us113.epil = phi i1 [ %48, %bb15.i.i.i.i.us112.epil ], [ %failure10.sroa.0.0.off0123.i.i.i.i.us113.epil.init, %bb15.i.i.i.i.us112.epil.preheader ]
  %iter.sroa.0.0122.i.i.i.i.us114.epil = phi ptr [ %_17.i.i.i.i.i.i.us124.epil, %bb15.i.i.i.i.us112.epil ], [ %iter.sroa.0.0122.i.i.i.i.us114.epil.init, %bb15.i.i.i.i.us112.epil.preheader ]
  %iter.sroa.7.0121.i.i.i.i.us115.epil = phi i64 [ %_9.0.i.i.i.i.i.us123.epil, %bb15.i.i.i.i.us112.epil ], [ %iter.sroa.7.0121.i.i.i.i.us115.epil.init, %bb15.i.i.i.i.us112.epil.preheader ]
  %epil.iter193 = phi i64 [ %epil.iter193.next, %bb15.i.i.i.i.us112.epil ], [ 0, %bb15.i.i.i.i.us112.epil.preheader ]
  %_0.sroa.0.0.i.i.us116.epil = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us118.epil = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us115.epil, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us118.epil), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us119.epil = getelementptr inbounds nuw i64, ptr %55, i64 %iter.sroa.7.0121.i.i.i.i.us115.epil, !dbg !22972
  %_0.sroa.0.0.i7.i.us122.epil = load i64, ptr %_4.i.i12.i.us119.epil, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us123.epil = add nuw i64 %iter.sroa.7.0121.i.i.i.i.us115.epil, 1, !dbg !22978
  %_17.i.i.i.i.i.i.us124.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us114.epil, i64 1, !dbg !22979
  %47 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us116.epil, i64 %_0.sroa.0.0.i7.i.us122.epil), !dbg !22981
  %_7.0.i.i.i.i.i.i.us125.epil = extractvalue { i64, i1 } %47, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us126.epil = extractvalue { i64, i1 } %47, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us127.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.us125.epil, 0, !dbg !22985
  %_135.i.i.i.i.us128.epil = zext i1 %_8.i.i.i.i.i.i.us127.epil to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us128.epil, ptr %iter.sroa.0.0122.i.i.i.i.us114.epil, align 1, !dbg !22992, !noalias !22737
  %48 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us113.epil, %_7.1.i.i.i.i.i.i.us126.epil, !dbg !22993
  %epil.iter193.next = add i64 %epil.iter193, 1, !dbg !22944
  %epil.iter193.cmp.not = icmp eq i64 %epil.iter193.next, %xtraiter192, !dbg !22944
  br i1 %epil.iter193.cmp.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.us112.epil, !dbg !22944, !llvm.loop !22997

bb21.i.i.i.i.loopexit175.unr-lcssa:               ; preds = %bb15.i.i.i.i
  %bin.rdx189 = or i1 %87, %85, !dbg !22944
  %bin.rdx190 = or i1 %89, %bin.rdx189, !dbg !22944
  %bin.rdx191 = or i1 %91, %bin.rdx190, !dbg !22944
  %lcmp.mod184.not = icmp eq i64 %xtraiter182, 0, !dbg !22944
  br i1 %lcmp.mod184.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.epil.preheader, !dbg !22944

bb15.i.i.i.i.epil.preheader:                      ; preds = %bb21.i.i.i.i.loopexit175.unr-lcssa, %bb15.i.i.i.i.preheader.split.split
  %failure10.sroa.0.0.off0123.i.i.i.i.epil.init = phi i1 [ false, %bb15.i.i.i.i.preheader.split.split ], [ %bin.rdx191, %bb21.i.i.i.i.loopexit175.unr-lcssa ]
  %iter.sroa.0.0122.i.i.i.i.epil.init = phi ptr [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.preheader.split.split ], [ %_17.i.i.i.i.i.i.3, %bb21.i.i.i.i.loopexit175.unr-lcssa ]
  %lcmp.mod186 = icmp ne i64 %xtraiter182, 0, !dbg !22944
  call void @llvm.assume(i1 %lcmp.mod186), !dbg !22944
  br label %bb15.i.i.i.i.epil, !dbg !22944

bb15.i.i.i.i.epil:                                ; preds = %bb15.i.i.i.i.epil, %bb15.i.i.i.i.epil.preheader
  %failure10.sroa.0.0.off0123.i.i.i.i.epil = phi i1 [ %50, %bb15.i.i.i.i.epil ], [ %failure10.sroa.0.0.off0123.i.i.i.i.epil.init, %bb15.i.i.i.i.epil.preheader ]
  %iter.sroa.0.0122.i.i.i.i.epil = phi ptr [ %_17.i.i.i.i.i.i.epil, %bb15.i.i.i.i.epil ], [ %iter.sroa.0.0122.i.i.i.i.epil.init, %bb15.i.i.i.i.epil.preheader ]
  %epil.iter183 = phi i64 [ %epil.iter183.next, %bb15.i.i.i.i.epil ], [ 0, %bb15.i.i.i.i.epil.preheader ]
  %_0.sroa.0.0.i.i.epil = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.epil = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_17.i.i.i.i.i.i.epil = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.epil, i64 1, !dbg !22979
  %49 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.epil, i64 %_0.sroa.0.0.i7.i.epil), !dbg !22981
  %_7.0.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %49, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.epil = extractvalue { i64, i1 } %49, 1, !dbg !22981
  %_8.i.i.i.i.i.i.epil = icmp sgt i64 %_7.0.i.i.i.i.i.i.epil, 0, !dbg !22985
  %_135.i.i.i.i.epil = zext i1 %_8.i.i.i.i.i.i.epil to i8, !dbg !22986
  store i8 %_135.i.i.i.i.epil, ptr %iter.sroa.0.0122.i.i.i.i.epil, align 1, !dbg !22992, !noalias !22737
  %50 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.epil, %_7.1.i.i.i.i.i.i.epil, !dbg !22993
  %epil.iter183.next = add i64 %epil.iter183, 1, !dbg !22944
  %epil.iter183.cmp.not = icmp eq i64 %epil.iter183.next, %xtraiter182, !dbg !22944
  br i1 %epil.iter183.cmp.not, label %bb21.i.i.i.i, label %bb15.i.i.i.i.epil, !dbg !22944, !llvm.loop !22998

bb21.i.i.i.i:                                     ; preds = %bb21.i.i.i.i.loopexit175.unr-lcssa, %bb15.i.i.i.i.epil, %bb21.i.i.i.i.loopexit173.unr-lcssa, %bb15.i.i.i.i.us112.epil, %bb21.i.i.i.i.loopexit171.unr-lcssa, %bb15.i.i.i.i.us.epil, %bb21.i.i.i.i.loopexit.unr-lcssa, %bb15.i.i.i.i.us.us.epil
  %.us-phi = phi i1 [ %46, %bb15.i.i.i.i.us.epil ], [ %48, %bb15.i.i.i.i.us112.epil ], [ %44, %bb15.i.i.i.i.us.us.epil ], [ %bin.rdx221, %bb21.i.i.i.i.loopexit.unr-lcssa ], [ %bin.rdx211, %bb21.i.i.i.i.loopexit171.unr-lcssa ], [ %bin.rdx201, %bb21.i.i.i.i.loopexit173.unr-lcssa ], [ %bin.rdx191, %bb21.i.i.i.i.loopexit175.unr-lcssa ], [ %50, %bb15.i.i.i.i.epil ], !dbg !22943
  call void @llvm.lifetime.start.p0(ptr nonnull %_68.i.i.i.i), !dbg !22943, !noalias !22716
  br i1 %.us-phi, label %bb1.i44.i.i.i.i, label %bb24.i.i.i.i, !dbg !22885, !prof !11822

bb22.thread.sink.split.i.i.i.i:                   ; preds = %bb12.i.i.i.i, %bb10.thread.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_68.i.i.i.i), !dbg !22943, !noalias !22716
  br label %bb24.i.i.i.i, !dbg !22999

bb1.i44.i.i.i.i:                                  ; preds = %bb21.i.i.i.i, %bb10.i.i.i.i
; invoke rofl_examples::functions::row_error::<rofl_arrow::ArrowHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(address) dereferenceable(32) %_68.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb22.i.i.i.i unwind label %bb48.thread109.loopexit.split-lp.i.i.i.i, !dbg !23000, !noalias !22737

bb11.i.i.i.i:                                     ; preds = %bb8.i.i.i.i
  %_121.i.i.i.i = load i64, ptr %_44.i.i.i.i, align 8, !dbg !23001, !range !4730, !noalias !22716, !noundef !37
  %51 = trunc nuw i64 %_121.i.i.i.i to i1, !dbg !23004
  %52 = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 8, !dbg !23005
  %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89 = load ptr, ptr %52, align 8, !dbg !23005, !noalias !22716
  %_43.sroa.5.i.i.i.i.sroa.7.0..sroa_idx91 = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 16, !dbg !23005
  %_43.sroa.5.i.i.i.i.sroa.7.0.copyload92 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.7.0..sroa_idx91, align 8, !dbg !23005, !noalias !22716
  %_43.sroa.5.i.i.i.i.sroa.8.0..sroa_idx95 = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 24, !dbg !23005
  %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.8.0..sroa_idx95, align 8, !dbg !23005, !noalias !22716
  %_43.sroa.5.i.i.i.i.sroa.9.0..sroa_idx99 = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 32, !dbg !23005
  %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100 = load ptr, ptr %_43.sroa.5.i.i.i.i.sroa.9.0..sroa_idx99, align 8, !dbg !23005, !noalias !22716
  br i1 %51, label %bb69.i.i.i.i, label %bb12.i.i.i.i, !dbg !23004

bb69.i.i.i.i:                                     ; preds = %bb11.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_44.i.i.i.i), !dbg !23006, !noalias !22716
  %53 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23007
  store ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, ptr %53, align 8, !dbg !23006, !noalias !22779
  %_43.sroa.5.i.i.i.i.sroa.7.0..sroa_idx93 = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23006
  store i64 %_43.sroa.5.i.i.i.i.sroa.7.0.copyload92, ptr %_43.sroa.5.i.i.i.i.sroa.7.0..sroa_idx93, align 8, !dbg !23006, !noalias !22779
  br label %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecINtNtNtB4_3mem12maybe_uninit11MaybeUninitbEEECskkDzpO6M0zw_10boundaries.exit.i57.i.i.i.i, !dbg !22849

bb12.i.i.i.i:                                     ; preds = %bb11.i.i.i.i
  %_43.sroa.5.i.i.i.i.sroa.10.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 40, !dbg !23013
  %_43.sroa.5.i.i.i.i.sroa.10.0.copyload = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.10.0..sroa_idx, align 8, !dbg !23013, !noalias !22716
  %_43.sroa.5.i.i.i.i.sroa.11.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_44.i.i.i.i, i64 48, !dbg !23013
  %_43.sroa.5.i.i.i.i.sroa.11.0.copyload = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.11.0..sroa_idx, align 8, !dbg !23013, !noalias !22716
  call void @llvm.lifetime.end.p0(ptr nonnull %_44.i.i.i.i), !dbg !23006, !noalias !22716
  %_7.i.i120.i.i.i.i = icmp samesign eq i64 %_23.i.i.i.i, 0, !dbg !23014
  br i1 %_7.i.i120.i.i.i.i, label %bb22.thread.sink.split.i.i.i.i, label %bb15.i.i.i.i.preheader, !dbg !22944

bb15.i.i.i.i.preheader:                           ; preds = %bb12.i.i.i.i
  %.not.i.i20 = icmp eq ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, null
  %.not.i1.i = icmp eq ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, null
  %_5.i.i.i22 = icmp ne i64 %_43.sroa.5.i.i.i.i.sroa.7.0.copyload92, 0
  %54 = inttoptr i64 %_43.sroa.5.i.i.i.i.sroa.7.0.copyload92 to ptr
  %_5.i.i5.i = icmp ne i64 %_43.sroa.5.i.i.i.i.sroa.10.0.copyload, 0
  %55 = inttoptr i64 %_43.sroa.5.i.i.i.i.sroa.10.0.copyload to ptr
  br i1 %.not.i.i20, label %bb15.i.i.i.i.preheader.split.us, label %bb15.i.i.i.i.preheader.split

bb15.i.i.i.i.preheader.split.us:                  ; preds = %bb15.i.i.i.i.preheader
  br i1 %.not.i1.i, label %bb15.i.i.i.i.us.us.preheader, label %bb15.i.i.i.i.preheader.split.us.split

bb15.i.i.i.i.us.us.preheader:                     ; preds = %bb15.i.i.i.i.preheader.split.us
  %xtraiter212 = and i64 %_23.i.i.i.i, 3, !dbg !22944
  %56 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !22944
  br i1 %56, label %bb15.i.i.i.i.us.us.epil.preheader, label %bb15.i.i.i.i.us.us.preheader.new, !dbg !22944

bb15.i.i.i.i.us.us.preheader.new:                 ; preds = %bb15.i.i.i.i.us.us.preheader
  %unroll_iter217 = and i64 %_23.i.i.i.i, -4, !dbg !22944
  br label %bb15.i.i.i.i.us.us, !dbg !22944

bb15.i.i.i.i.us.us:                               ; preds = %bb15.i.i.i.i.us.us, %bb15.i.i.i.i.us.us.preheader.new
  %failure10.sroa.0.0.off0123.i.i.i.i.us.us.1 = phi i1 [ %60, %bb15.i.i.i.i.us.us ], [ false, %bb15.i.i.i.i.us.us.preheader.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us.us.2 = phi i1 [ %62, %bb15.i.i.i.i.us.us ], [ false, %bb15.i.i.i.i.us.us.preheader.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us.us.3 = phi i1 [ %64, %bb15.i.i.i.i.us.us ], [ false, %bb15.i.i.i.i.us.us.preheader.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us.us = phi i1 [ %58, %bb15.i.i.i.i.us.us ], [ false, %bb15.i.i.i.i.us.us.preheader.new ]
  %iter.sroa.0.0122.i.i.i.i.us.us = phi ptr [ %_17.i.i.i.i.i.i.us.us.3, %bb15.i.i.i.i.us.us ], [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.us.us.preheader.new ]
  %iter.sroa.7.0121.i.i.i.i.us.us = phi i64 [ %_9.0.i.i.i.i.i.us.us.3, %bb15.i.i.i.i.us.us ], [ 0, %bb15.i.i.i.i.us.us.preheader.new ]
  %niter218 = phi i64 [ %niter218.next.3, %bb15.i.i.i.i.us.us ], [ 0, %bb15.i.i.i.i.us.us.preheader.new ]
  %_5.i3.i.i.us.us = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us.us, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.us), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.us = getelementptr inbounds nuw i64, ptr %54, i64 %iter.sroa.7.0121.i.i.i.i.us.us, !dbg !22958
  %_0.sroa.0.0.i.i.us.us = load i64, ptr %_4.i.i.i25.us.us, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us.us = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us.us, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us.us = getelementptr inbounds nuw i64, ptr %55, i64 %iter.sroa.7.0121.i.i.i.i.us.us, !dbg !22972
  %_0.sroa.0.0.i7.i.us.us = load i64, ptr %_4.i.i12.i.us.us, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.us = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us.us, 1, !dbg !22978
  %_17.i.i.i.i.i.i.us.us = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us.us, i64 1, !dbg !22979
  %57 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us, i64 %_0.sroa.0.0.i7.i.us.us), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.us = extractvalue { i64, i1 } %57, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.us = extractvalue { i64, i1 } %57, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.us = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us, 0, !dbg !22985
  %_135.i.i.i.i.us.us = zext i1 %_8.i.i.i.i.i.i.us.us to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.us, ptr %iter.sroa.0.0122.i.i.i.i.us.us, align 1, !dbg !22992, !noalias !22737
  %58 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.us, %_7.1.i.i.i.i.i.i.us.us, !dbg !22993
  %_5.i3.i.i.us.us.1 = icmp ult i64 %_9.0.i.i.i.i.i.us.us, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.1), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.us.1 = getelementptr inbounds nuw i64, ptr %54, i64 %_9.0.i.i.i.i.i.us.us, !dbg !22958
  %_0.sroa.0.0.i.i.us.us.1 = load i64, ptr %_4.i.i.i25.us.us.1, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us.us.1 = icmp ult i64 %_9.0.i.i.i.i.i.us.us, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.1), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us.us.1 = getelementptr inbounds nuw i64, ptr %55, i64 %_9.0.i.i.i.i.i.us.us, !dbg !22972
  %_0.sroa.0.0.i7.i.us.us.1 = load i64, ptr %_4.i.i12.i.us.us.1, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.us.1 = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us.us, 2, !dbg !22978
  %_17.i.i.i.i.i.i.us.us.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us.us, i64 2, !dbg !22979
  %59 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.1, i64 %_0.sroa.0.0.i7.i.us.us.1), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.us.1 = extractvalue { i64, i1 } %59, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.us.1 = extractvalue { i64, i1 } %59, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.us.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.1, 0, !dbg !22985
  %_135.i.i.i.i.us.us.1 = zext i1 %_8.i.i.i.i.i.i.us.us.1 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.us.1, ptr %_17.i.i.i.i.i.i.us.us, align 1, !dbg !22992, !noalias !22737
  %60 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.us.1, %_7.1.i.i.i.i.i.i.us.us.1, !dbg !22993
  %_5.i3.i.i.us.us.2 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.1, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.2), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.us.2 = getelementptr inbounds nuw i64, ptr %54, i64 %_9.0.i.i.i.i.i.us.us.1, !dbg !22958
  %_0.sroa.0.0.i.i.us.us.2 = load i64, ptr %_4.i.i.i25.us.us.2, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us.us.2 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.1, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.2), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us.us.2 = getelementptr inbounds nuw i64, ptr %55, i64 %_9.0.i.i.i.i.i.us.us.1, !dbg !22972
  %_0.sroa.0.0.i7.i.us.us.2 = load i64, ptr %_4.i.i12.i.us.us.2, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.us.2 = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us.us, 3, !dbg !22978
  %_17.i.i.i.i.i.i.us.us.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us.us, i64 3, !dbg !22979
  %61 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.2, i64 %_0.sroa.0.0.i7.i.us.us.2), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.us.2 = extractvalue { i64, i1 } %61, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.us.2 = extractvalue { i64, i1 } %61, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.us.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.2, 0, !dbg !22985
  %_135.i.i.i.i.us.us.2 = zext i1 %_8.i.i.i.i.i.i.us.us.2 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.us.2, ptr %_17.i.i.i.i.i.i.us.us.1, align 1, !dbg !22992, !noalias !22737
  %62 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.us.2, %_7.1.i.i.i.i.i.i.us.us.2, !dbg !22993
  %_5.i3.i.i.us.us.3 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.2, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.us.3), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.us.3 = getelementptr inbounds nuw i64, ptr %54, i64 %_9.0.i.i.i.i.i.us.us.2, !dbg !22958
  %_0.sroa.0.0.i.i.us.us.3 = load i64, ptr %_4.i.i.i25.us.us.3, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us.us.3 = icmp ult i64 %_9.0.i.i.i.i.i.us.us.2, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us.us.3), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us.us.3 = getelementptr inbounds nuw i64, ptr %55, i64 %_9.0.i.i.i.i.i.us.us.2, !dbg !22972
  %_0.sroa.0.0.i7.i.us.us.3 = load i64, ptr %_4.i.i12.i.us.us.3, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.us.3 = add nuw i64 %iter.sroa.7.0121.i.i.i.i.us.us, 4, !dbg !22978
  %_17.i.i.i.i.i.i.us.us.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us.us, i64 4, !dbg !22979
  %63 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.us.3, i64 %_0.sroa.0.0.i7.i.us.us.3), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.us.3 = extractvalue { i64, i1 } %63, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.us.3 = extractvalue { i64, i1 } %63, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.us.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.us.3, 0, !dbg !22985
  %_135.i.i.i.i.us.us.3 = zext i1 %_8.i.i.i.i.i.i.us.us.3 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.us.3, ptr %_17.i.i.i.i.i.i.us.us.2, align 1, !dbg !22992, !noalias !22737
  %64 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.us.3, %_7.1.i.i.i.i.i.i.us.us.3, !dbg !22993
  %niter218.next.3 = add i64 %niter218, 4, !dbg !22944
  %niter218.ncmp.3 = icmp eq i64 %niter218.next.3, %unroll_iter217, !dbg !22944
  br i1 %niter218.ncmp.3, label %bb21.i.i.i.i.loopexit.unr-lcssa, label %bb15.i.i.i.i.us.us, !dbg !22944

bb15.i.i.i.i.preheader.split.us.split:            ; preds = %bb15.i.i.i.i.preheader.split.us
  call void @llvm.assume(i1 %_5.i.i5.i), !noalias !22737
  %xtraiter202 = and i64 %_23.i.i.i.i, 3, !dbg !23016
  %65 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !23016
  br i1 %65, label %bb15.i.i.i.i.us.epil.preheader, label %bb15.i.i.i.i.preheader.split.us.split.new, !dbg !23016

bb15.i.i.i.i.preheader.split.us.split.new:        ; preds = %bb15.i.i.i.i.preheader.split.us.split
  %unroll_iter207 = and i64 %_23.i.i.i.i, -4, !dbg !23016
  br label %bb15.i.i.i.i.us, !dbg !23016

bb15.i.i.i.i.us:                                  ; preds = %bb15.i.i.i.i.us, %bb15.i.i.i.i.preheader.split.us.split.new
  %failure10.sroa.0.0.off0123.i.i.i.i.us.1 = phi i1 [ %69, %bb15.i.i.i.i.us ], [ false, %bb15.i.i.i.i.preheader.split.us.split.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us.2 = phi i1 [ %71, %bb15.i.i.i.i.us ], [ false, %bb15.i.i.i.i.preheader.split.us.split.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us.3 = phi i1 [ %73, %bb15.i.i.i.i.us ], [ false, %bb15.i.i.i.i.preheader.split.us.split.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us = phi i1 [ %67, %bb15.i.i.i.i.us ], [ false, %bb15.i.i.i.i.preheader.split.us.split.new ]
  %iter.sroa.0.0122.i.i.i.i.us = phi ptr [ %_17.i.i.i.i.i.i.us.3, %bb15.i.i.i.i.us ], [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.preheader.split.us.split.new ]
  %iter.sroa.7.0121.i.i.i.i.us = phi i64 [ %_9.0.i.i.i.i.i.us.3, %bb15.i.i.i.i.us ], [ 0, %bb15.i.i.i.i.preheader.split.us.split.new ]
  %niter208 = phi i64 [ %niter208.next.3, %bb15.i.i.i.i.us ], [ 0, %bb15.i.i.i.i.preheader.split.us.split.new ]
  %_5.i3.i.i.us = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us = getelementptr inbounds nuw i64, ptr %54, i64 %iter.sroa.7.0121.i.i.i.i.us, !dbg !22958
  %_0.sroa.0.0.i.i.us = load i64, ptr %_4.i.i.i25.us, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.us = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us, 1, !dbg !22978
  %_17.i.i.i.i.i.i.us = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us, i64 1, !dbg !22979
  %66 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us, i64 %_0.sroa.0.0.i7.i.us), !dbg !22981
  %_7.0.i.i.i.i.i.i.us = extractvalue { i64, i1 } %66, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us = extractvalue { i64, i1 } %66, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us = icmp sgt i64 %_7.0.i.i.i.i.i.i.us, 0, !dbg !22985
  %_135.i.i.i.i.us = zext i1 %_8.i.i.i.i.i.i.us to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us, ptr %iter.sroa.0.0122.i.i.i.i.us, align 1, !dbg !22992, !noalias !22737
  %67 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us, %_7.1.i.i.i.i.i.i.us, !dbg !22993
  %_5.i3.i.i.us.1 = icmp ult i64 %_9.0.i.i.i.i.i.us, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.1), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.1 = getelementptr inbounds nuw i64, ptr %54, i64 %_9.0.i.i.i.i.i.us, !dbg !22958
  %_0.sroa.0.0.i.i.us.1 = load i64, ptr %_4.i.i.i25.us.1, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.us.1 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.1 = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us, 2, !dbg !22978
  %_17.i.i.i.i.i.i.us.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us, i64 2, !dbg !22979
  %68 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.1, i64 %_0.sroa.0.0.i7.i.us.1), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.1 = extractvalue { i64, i1 } %68, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.1 = extractvalue { i64, i1 } %68, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.1, 0, !dbg !22985
  %_135.i.i.i.i.us.1 = zext i1 %_8.i.i.i.i.i.i.us.1 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.1, ptr %_17.i.i.i.i.i.i.us, align 1, !dbg !22992, !noalias !22737
  %69 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.1, %_7.1.i.i.i.i.i.i.us.1, !dbg !22993
  %_5.i3.i.i.us.2 = icmp ult i64 %_9.0.i.i.i.i.i.us.1, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.2), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.2 = getelementptr inbounds nuw i64, ptr %54, i64 %_9.0.i.i.i.i.i.us.1, !dbg !22958
  %_0.sroa.0.0.i.i.us.2 = load i64, ptr %_4.i.i.i25.us.2, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.us.2 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.2 = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us, 3, !dbg !22978
  %_17.i.i.i.i.i.i.us.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us, i64 3, !dbg !22979
  %70 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.2, i64 %_0.sroa.0.0.i7.i.us.2), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.2 = extractvalue { i64, i1 } %70, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.2 = extractvalue { i64, i1 } %70, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.2, 0, !dbg !22985
  %_135.i.i.i.i.us.2 = zext i1 %_8.i.i.i.i.i.i.us.2 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.2, ptr %_17.i.i.i.i.i.i.us.1, align 1, !dbg !22992, !noalias !22737
  %71 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.2, %_7.1.i.i.i.i.i.i.us.2, !dbg !22993
  %_5.i3.i.i.us.3 = icmp ult i64 %_9.0.i.i.i.i.i.us.2, %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, !dbg !22950
  call void @llvm.assume(i1 %_5.i3.i.i.us.3), !dbg !22957, !noalias !22737
  %_4.i.i.i25.us.3 = getelementptr inbounds nuw i64, ptr %54, i64 %_9.0.i.i.i.i.i.us.2, !dbg !22958
  %_0.sroa.0.0.i.i.us.3 = load i64, ptr %_4.i.i.i25.us.3, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.us.3 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us.3 = add nuw i64 %iter.sroa.7.0121.i.i.i.i.us, 4, !dbg !22978
  %_17.i.i.i.i.i.i.us.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us, i64 4, !dbg !22979
  %72 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us.3, i64 %_0.sroa.0.0.i7.i.us.3), !dbg !22981
  %_7.0.i.i.i.i.i.i.us.3 = extractvalue { i64, i1 } %72, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us.3 = extractvalue { i64, i1 } %72, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us.3, 0, !dbg !22985
  %_135.i.i.i.i.us.3 = zext i1 %_8.i.i.i.i.i.i.us.3 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us.3, ptr %_17.i.i.i.i.i.i.us.2, align 1, !dbg !22992, !noalias !22737
  %73 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us.3, %_7.1.i.i.i.i.i.i.us.3, !dbg !22993
  %niter208.next.3 = add i64 %niter208, 4, !dbg !22944
  %niter208.ncmp.3 = icmp eq i64 %niter208.next.3, %unroll_iter207, !dbg !22944
  br i1 %niter208.ncmp.3, label %bb21.i.i.i.i.loopexit171.unr-lcssa, label %bb15.i.i.i.i.us, !dbg !22944

bb15.i.i.i.i.preheader.split:                     ; preds = %bb15.i.i.i.i.preheader
  call void @llvm.assume(i1 %_5.i.i.i22), !noalias !22737
  br i1 %.not.i1.i, label %bb15.i.i.i.i.us112.preheader, label %bb15.i.i.i.i.preheader.split.split

bb15.i.i.i.i.us112.preheader:                     ; preds = %bb15.i.i.i.i.preheader.split
  %xtraiter192 = and i64 %_23.i.i.i.i, 3, !dbg !22944
  %74 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !22944
  br i1 %74, label %bb15.i.i.i.i.us112.epil.preheader, label %bb15.i.i.i.i.us112.preheader.new, !dbg !22944

bb15.i.i.i.i.us112.preheader.new:                 ; preds = %bb15.i.i.i.i.us112.preheader
  %unroll_iter197 = and i64 %_23.i.i.i.i, -4, !dbg !22944
  br label %bb15.i.i.i.i.us112, !dbg !22944

bb15.i.i.i.i.us112:                               ; preds = %bb15.i.i.i.i.us112, %bb15.i.i.i.i.us112.preheader.new
  %failure10.sroa.0.0.off0123.i.i.i.i.us113.1 = phi i1 [ %78, %bb15.i.i.i.i.us112 ], [ false, %bb15.i.i.i.i.us112.preheader.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us113.2 = phi i1 [ %80, %bb15.i.i.i.i.us112 ], [ false, %bb15.i.i.i.i.us112.preheader.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us113.3 = phi i1 [ %82, %bb15.i.i.i.i.us112 ], [ false, %bb15.i.i.i.i.us112.preheader.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.us113 = phi i1 [ %76, %bb15.i.i.i.i.us112 ], [ false, %bb15.i.i.i.i.us112.preheader.new ]
  %iter.sroa.0.0122.i.i.i.i.us114 = phi ptr [ %_17.i.i.i.i.i.i.us124.3, %bb15.i.i.i.i.us112 ], [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.us112.preheader.new ]
  %iter.sroa.7.0121.i.i.i.i.us115 = phi i64 [ %_9.0.i.i.i.i.i.us123.3, %bb15.i.i.i.i.us112 ], [ 0, %bb15.i.i.i.i.us112.preheader.new ]
  %niter198 = phi i64 [ %niter198.next.3, %bb15.i.i.i.i.us112 ], [ 0, %bb15.i.i.i.i.us112.preheader.new ]
  %_0.sroa.0.0.i.i.us116 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us118 = icmp ult i64 %iter.sroa.7.0121.i.i.i.i.us115, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us118), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us119 = getelementptr inbounds nuw i64, ptr %55, i64 %iter.sroa.7.0121.i.i.i.i.us115, !dbg !22972
  %_0.sroa.0.0.i7.i.us122 = load i64, ptr %_4.i.i12.i.us119, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us123 = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us115, 1, !dbg !22978
  %_17.i.i.i.i.i.i.us124 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us114, i64 1, !dbg !22979
  %75 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us116, i64 %_0.sroa.0.0.i7.i.us122), !dbg !22981
  %_7.0.i.i.i.i.i.i.us125 = extractvalue { i64, i1 } %75, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us126 = extractvalue { i64, i1 } %75, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us127 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us125, 0, !dbg !22985
  %_135.i.i.i.i.us128 = zext i1 %_8.i.i.i.i.i.i.us127 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us128, ptr %iter.sroa.0.0122.i.i.i.i.us114, align 1, !dbg !22992, !noalias !22737
  %76 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us113, %_7.1.i.i.i.i.i.i.us126, !dbg !22993
  %_0.sroa.0.0.i.i.us116.1 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us118.1 = icmp ult i64 %_9.0.i.i.i.i.i.us123, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us118.1), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us119.1 = getelementptr inbounds nuw i64, ptr %55, i64 %_9.0.i.i.i.i.i.us123, !dbg !22972
  %_0.sroa.0.0.i7.i.us122.1 = load i64, ptr %_4.i.i12.i.us119.1, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us123.1 = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us115, 2, !dbg !22978
  %_17.i.i.i.i.i.i.us124.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us114, i64 2, !dbg !22979
  %77 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us116.1, i64 %_0.sroa.0.0.i7.i.us122.1), !dbg !22981
  %_7.0.i.i.i.i.i.i.us125.1 = extractvalue { i64, i1 } %77, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us126.1 = extractvalue { i64, i1 } %77, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us127.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us125.1, 0, !dbg !22985
  %_135.i.i.i.i.us128.1 = zext i1 %_8.i.i.i.i.i.i.us127.1 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us128.1, ptr %_17.i.i.i.i.i.i.us124, align 1, !dbg !22992, !noalias !22737
  %78 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us113.1, %_7.1.i.i.i.i.i.i.us126.1, !dbg !22993
  %_0.sroa.0.0.i.i.us116.2 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us118.2 = icmp ult i64 %_9.0.i.i.i.i.i.us123.1, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us118.2), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us119.2 = getelementptr inbounds nuw i64, ptr %55, i64 %_9.0.i.i.i.i.i.us123.1, !dbg !22972
  %_0.sroa.0.0.i7.i.us122.2 = load i64, ptr %_4.i.i12.i.us119.2, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us123.2 = or disjoint i64 %iter.sroa.7.0121.i.i.i.i.us115, 3, !dbg !22978
  %_17.i.i.i.i.i.i.us124.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us114, i64 3, !dbg !22979
  %79 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us116.2, i64 %_0.sroa.0.0.i7.i.us122.2), !dbg !22981
  %_7.0.i.i.i.i.i.i.us125.2 = extractvalue { i64, i1 } %79, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us126.2 = extractvalue { i64, i1 } %79, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us127.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us125.2, 0, !dbg !22985
  %_135.i.i.i.i.us128.2 = zext i1 %_8.i.i.i.i.i.i.us127.2 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us128.2, ptr %_17.i.i.i.i.i.i.us124.1, align 1, !dbg !22992, !noalias !22737
  %80 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us113.2, %_7.1.i.i.i.i.i.i.us126.2, !dbg !22993
  %_0.sroa.0.0.i.i.us116.3 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_5.i3.i11.i.us118.3 = icmp ult i64 %_9.0.i.i.i.i.i.us123.2, %_43.sroa.5.i.i.i.i.sroa.11.0.copyload, !dbg !22966
  call void @llvm.assume(i1 %_5.i3.i11.i.us118.3), !dbg !22971, !noalias !22737
  %_4.i.i12.i.us119.3 = getelementptr inbounds nuw i64, ptr %55, i64 %_9.0.i.i.i.i.i.us123.2, !dbg !22972
  %_0.sroa.0.0.i7.i.us122.3 = load i64, ptr %_4.i.i12.i.us119.3, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_9.0.i.i.i.i.i.us123.3 = add nuw i64 %iter.sroa.7.0121.i.i.i.i.us115, 4, !dbg !22978
  %_17.i.i.i.i.i.i.us124.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i.us114, i64 4, !dbg !22979
  %81 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.us116.3, i64 %_0.sroa.0.0.i7.i.us122.3), !dbg !22981
  %_7.0.i.i.i.i.i.i.us125.3 = extractvalue { i64, i1 } %81, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.us126.3 = extractvalue { i64, i1 } %81, 1, !dbg !22981
  %_8.i.i.i.i.i.i.us127.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.us125.3, 0, !dbg !22985
  %_135.i.i.i.i.us128.3 = zext i1 %_8.i.i.i.i.i.i.us127.3 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.us128.3, ptr %_17.i.i.i.i.i.i.us124.2, align 1, !dbg !22992, !noalias !22737
  %82 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.us113.3, %_7.1.i.i.i.i.i.i.us126.3, !dbg !22993
  %niter198.next.3 = add i64 %niter198, 4, !dbg !22944
  %niter198.ncmp.3 = icmp eq i64 %niter198.next.3, %unroll_iter197, !dbg !22944
  br i1 %niter198.ncmp.3, label %bb21.i.i.i.i.loopexit173.unr-lcssa, label %bb15.i.i.i.i.us112, !dbg !22944

bb15.i.i.i.i.preheader.split.split:               ; preds = %bb15.i.i.i.i.preheader.split
  call void @llvm.assume(i1 %_5.i.i5.i), !noalias !22737
  %xtraiter182 = and i64 %_23.i.i.i.i, 3, !dbg !23016
  %83 = icmp ult i64 %_23.i.i.i.i, 4, !dbg !23016
  br i1 %83, label %bb15.i.i.i.i.epil.preheader, label %bb15.i.i.i.i.preheader.split.split.new, !dbg !23016

bb15.i.i.i.i.preheader.split.split.new:           ; preds = %bb15.i.i.i.i.preheader.split.split
  %unroll_iter187 = and i64 %_23.i.i.i.i, -4, !dbg !23016
  br label %bb15.i.i.i.i, !dbg !23016

bb15.i.i.i.i:                                     ; preds = %bb15.i.i.i.i, %bb15.i.i.i.i.preheader.split.split.new
  %failure10.sroa.0.0.off0123.i.i.i.i.1 = phi i1 [ %87, %bb15.i.i.i.i ], [ false, %bb15.i.i.i.i.preheader.split.split.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.2 = phi i1 [ %89, %bb15.i.i.i.i ], [ false, %bb15.i.i.i.i.preheader.split.split.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i.3 = phi i1 [ %91, %bb15.i.i.i.i ], [ false, %bb15.i.i.i.i.preheader.split.split.new ]
  %failure10.sroa.0.0.off0123.i.i.i.i = phi i1 [ %85, %bb15.i.i.i.i ], [ false, %bb15.i.i.i.i.preheader.split.split.new ]
  %iter.sroa.0.0122.i.i.i.i = phi ptr [ %_17.i.i.i.i.i.i.3, %bb15.i.i.i.i ], [ %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, %bb15.i.i.i.i.preheader.split.split.new ]
  %niter188 = phi i64 [ %niter188.next.3, %bb15.i.i.i.i ], [ 0, %bb15.i.i.i.i.preheader.split.split.new ]
  %_0.sroa.0.0.i.i = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_17.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i, i64 1, !dbg !22979
  %84 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i, i64 %_0.sroa.0.0.i7.i), !dbg !22981
  %_7.0.i.i.i.i.i.i = extractvalue { i64, i1 } %84, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i = extractvalue { i64, i1 } %84, 1, !dbg !22981
  %_8.i.i.i.i.i.i = icmp sgt i64 %_7.0.i.i.i.i.i.i, 0, !dbg !22985
  %_135.i.i.i.i = zext i1 %_8.i.i.i.i.i.i to i8, !dbg !22986
  store i8 %_135.i.i.i.i, ptr %iter.sroa.0.0122.i.i.i.i, align 1, !dbg !22992, !noalias !22737
  %85 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i, %_7.1.i.i.i.i.i.i, !dbg !22993
  %_0.sroa.0.0.i.i.1 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.1 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_17.i.i.i.i.i.i.1 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i, i64 2, !dbg !22979
  %86 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.1, i64 %_0.sroa.0.0.i7.i.1), !dbg !22981
  %_7.0.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %86, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.1 = extractvalue { i64, i1 } %86, 1, !dbg !22981
  %_8.i.i.i.i.i.i.1 = icmp sgt i64 %_7.0.i.i.i.i.i.i.1, 0, !dbg !22985
  %_135.i.i.i.i.1 = zext i1 %_8.i.i.i.i.i.i.1 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.1, ptr %_17.i.i.i.i.i.i, align 1, !dbg !22992, !noalias !22737
  %87 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.1, %_7.1.i.i.i.i.i.i.1, !dbg !22993
  %_0.sroa.0.0.i.i.2 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.2 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_17.i.i.i.i.i.i.2 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i, i64 3, !dbg !22979
  %88 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.2, i64 %_0.sroa.0.0.i7.i.2), !dbg !22981
  %_7.0.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %88, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.2 = extractvalue { i64, i1 } %88, 1, !dbg !22981
  %_8.i.i.i.i.i.i.2 = icmp sgt i64 %_7.0.i.i.i.i.i.i.2, 0, !dbg !22985
  %_135.i.i.i.i.2 = zext i1 %_8.i.i.i.i.i.i.2 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.2, ptr %_17.i.i.i.i.i.i.1, align 1, !dbg !22992, !noalias !22737
  %89 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.2, %_7.1.i.i.i.i.i.i.2, !dbg !22993
  %_0.sroa.0.0.i.i.3 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.0.0.copyload89, align 8, !dbg !22959, !noalias !22961, !noundef !37
  %_0.sroa.0.0.i7.i.3 = load i64, ptr %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, align 8, !dbg !22973, !noalias !22975, !noundef !37
  %_17.i.i.i.i.i.i.3 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0122.i.i.i.i, i64 4, !dbg !22979
  %90 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %_0.sroa.0.0.i.i.3, i64 %_0.sroa.0.0.i7.i.3), !dbg !22981
  %_7.0.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %90, 0, !dbg !22981
  %_7.1.i.i.i.i.i.i.3 = extractvalue { i64, i1 } %90, 1, !dbg !22981
  %_8.i.i.i.i.i.i.3 = icmp sgt i64 %_7.0.i.i.i.i.i.i.3, 0, !dbg !22985
  %_135.i.i.i.i.3 = zext i1 %_8.i.i.i.i.i.i.3 to i8, !dbg !22986
  store i8 %_135.i.i.i.i.3, ptr %_17.i.i.i.i.i.i.2, align 1, !dbg !22992, !noalias !22737
  %91 = or i1 %failure10.sroa.0.0.off0123.i.i.i.i.3, %_7.1.i.i.i.i.i.i.3, !dbg !22993
  %niter188.next.3 = add i64 %niter188, 4, !dbg !22944
  %niter188.ncmp.3 = icmp eq i64 %niter188.next.3, %unroll_iter187, !dbg !22944
  br i1 %niter188.ncmp.3, label %bb21.i.i.i.i.loopexit175.unr-lcssa, label %bb15.i.i.i.i, !dbg !22944

bb22.i.i.i.i:                                     ; preds = %bb1.i44.i.i.i.i
  %.pr.i.i.i.i = load i64, ptr %_68.i.i.i.i, align 8, !dbg !22943, !noalias !22716
  %.not31.i.i.i.i = icmp eq i64 %.pr.i.i.i.i, -1, !dbg !22943
  br i1 %.not31.i.i.i.i, label %bb24.i.i.i.i, label %bb23.i.i.i.i, !dbg !22999

bb23.i.i.i.i:                                     ; preds = %bb22.i.i.i.i
  %92 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23017
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %92, ptr noundef nonnull align 8 dereferenceable(32) %_68.i.i.i.i, i64 32, i1 false), !dbg !23019, !noalias !22779
  store i64 0, ptr %_0, align 8, !dbg !23017, !alias.scope !22782, !noalias !22779
  call void @llvm.lifetime.end.p0(ptr nonnull %_68.i.i.i.i), !dbg !23020, !noalias !22716
  %93 = icmp eq i64 %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, 0
  br i1 %93, label %bb26.i.i.i.i, label %bb2.i.i27, !dbg !23021

bb2.i.i27:                                        ; preds = %bb23.i.i.i.i
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 noundef %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !23028, !noalias !23033
  br label %bb26.i.i.i.i, !dbg !23036

bb24.i.i.i.i:                                     ; preds = %bb22.i.i.i.i, %bb22.thread.sink.split.i.i.i.i, %bb21.i.i.i.i, %bb10.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_74.i.i.i.i), !dbg !23037, !noalias !22716
  store i64 %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, ptr %_74.i.i.i.i, align 8, !dbg !23037, !noalias !22716
  %output.i.i.i.i.sroa.8.0._74.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_74.i.i.i.i, i64 8, !dbg !23037
  store ptr %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, ptr %output.i.i.i.i.sroa.8.0._74.i.i.i.i.sroa_idx, align 8, !dbg !23037, !noalias !22716
  %output.i.i.i.i.sroa.12.0._74.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_74.i.i.i.i, i64 16, !dbg !23037
  store i64 %_21.sroa.6.i.i.i.i.sroa.7.0.copyload, ptr %output.i.i.i.i.sroa.12.0._74.i.i.i.i.sroa_idx, align 8, !dbg !23037, !noalias !22716
; invoke <rofl_arrow::output::BooleanOutputBuffer as rofl::output::OutputBuffer<bool>>::finish
  %94 = invoke { ptr, ptr } @_RNvXs0_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB5_19BooleanOutputBufferINtNtCshZi9mpuUhIi_4rofl6output12OutputBufferbE6finish(ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(24) %_74.i.i.i.i, i64 noundef %_23.i.i.i.i)
          to label %bb25.i.i.i.i unwind label %bb48.i.i.i.i, !dbg !23038, !noalias !22737

bb25.i.i.i.i:                                     ; preds = %bb24.i.i.i.i
  %_73.0.i.i.i.i = extractvalue { ptr, ptr } %94, 0, !dbg !23037
  %_73.1.i.i.i.i = extractvalue { ptr, ptr } %94, 1, !dbg !23037
  call void @llvm.lifetime.end.p0(ptr nonnull %_74.i.i.i.i), !dbg !23039, !noalias !22716
  %_72.sroa.4.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23040
  store ptr %_73.0.i.i.i.i, ptr %_72.sroa.4.0..sroa_idx.i.i.i.i, align 8, !dbg !23040, !alias.scope !22782, !noalias !22779
  %_72.sroa.5.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !23040
  store ptr %_73.1.i.i.i.i, ptr %_72.sroa.5.0..sroa_idx.i.i.i.i, align 8, !dbg !23040, !alias.scope !22782, !noalias !22779
  store <2 x i64> <i64 0, i64 -9223372036854775788>, ptr %_0, align 8, !dbg !23040, !alias.scope !22782, !noalias !22779
  call void @llvm.lifetime.end.p0(ptr nonnull %_68.i.i.i.i), !dbg !23020, !noalias !22716
  br label %bb26.i.i.i.i, !dbg !22821

bb26.i.i.i.i:                                     ; preds = %bb2.i.i27, %bb23.i.i.i.i, %bb25.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !23041), !dbg !23044
  call void @llvm.experimental.noalias.scope.decl(metadata !23045), !dbg !23048
  call void @llvm.experimental.noalias.scope.decl(metadata !23051), !dbg !23054
  call void @llvm.experimental.noalias.scope.decl(metadata !23057), !dbg !23060
  call void @llvm.experimental.noalias.scope.decl(metadata !23063), !dbg !23066
  call void @llvm.experimental.noalias.scope.decl(metadata !23068), !dbg !23071
  %_10.i.i.i.i.i.i.i.i.i.i = load ptr, ptr %columns.i.i.i.i, align 8, !dbg !23073, !alias.scope !23077, !noalias !22716, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i.i.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i.i.i.i.i.i, i64 1 release, align 8, !dbg !23078, !noalias !23081
  %95 = icmp eq i64 %_2.i.i.i.i.i.i.i.i.i.i, 1, !dbg !23082
  br i1 %95, label %bb2.i.i.i.i.i.i.i.i.i.i, label %bb4.i48.i.i.i.i, !dbg !23082

bb2.i.i.i.i.i.i.i.i.i.i:                          ; preds = %bb26.i.i.i.i
  fence acquire, !dbg !23083
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %columns.i.i.i.i) #23
          to label %bb4.i48.i.i.i.i unwind label %cleanup.i.i.i.i.i, !dbg !23085, !noalias !22737

cleanup.i.i.i.i.i:                                ; preds = %bb2.i.i.i.i.i.i.i.i.i.i
  %96 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !23086), !dbg !23048
  call void @llvm.experimental.noalias.scope.decl(metadata !23089), !dbg !23092
  call void @llvm.experimental.noalias.scope.decl(metadata !23094), !dbg !23097
  call void @llvm.experimental.noalias.scope.decl(metadata !23099), !dbg !23102
  call void @llvm.experimental.noalias.scope.decl(metadata !23104), !dbg !23107
  %_10.i.i.i.i.i1.i.i.i.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i, align 8, !dbg !23109, !alias.scope !23113, !noalias !22716, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i2.i.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i1.i.i.i.i.i, i64 1 release, align 8, !dbg !23114, !noalias !23117
  %97 = icmp eq i64 %_2.i.i.i.i.i2.i.i.i.i.i, 1, !dbg !23118
  br i1 %97, label %bb2.i.i.i.i.i3.i.i.i.i.i, label %bb52.i.i.i.i, !dbg !23118

bb2.i.i.i.i.i3.i.i.i.i.i:                         ; preds = %cleanup.i.i.i.i.i
  fence acquire, !dbg !23119
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i) #23
          to label %bb52.i.i.i.i unwind label %terminate.i.i.i.i.i, !dbg !23121, !noalias !22737

bb4.i48.i.i.i.i:                                  ; preds = %bb2.i.i.i.i.i.i.i.i.i.i, %bb26.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !23122), !dbg !23048
  call void @llvm.experimental.noalias.scope.decl(metadata !23125), !dbg !23128
  call void @llvm.experimental.noalias.scope.decl(metadata !23130), !dbg !23133
  call void @llvm.experimental.noalias.scope.decl(metadata !23135), !dbg !23138
  call void @llvm.experimental.noalias.scope.decl(metadata !23140), !dbg !23143
  %_10.i.i.i.i.i6.i.i.i.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i, align 8, !dbg !23145, !alias.scope !23149, !noalias !22716, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i7.i.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i6.i.i.i.i.i, i64 1 release, align 8, !dbg !23150, !noalias !23153
  %98 = icmp eq i64 %_2.i.i.i.i.i7.i.i.i.i.i, 1, !dbg !23154
  br i1 %98, label %bb2.i.i.i.i.i8.i.i.i.i.i, label %bb28.i.i.i.i, !dbg !23154

bb2.i.i.i.i.i8.i.i.i.i.i:                         ; preds = %bb4.i48.i.i.i.i
  fence acquire, !dbg !23155
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i) #23
          to label %bb28.i.i.i.i unwind label %cleanup.i.i.i.i, !dbg !23157, !noalias !22737

terminate.i.i.i.i.i:                              ; preds = %bb2.i.i.i.i.i3.i.i.i.i.i
  %99 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23048, !noalias !22737
  unreachable, !dbg !23048

bb28.i.i.i.i:                                     ; preds = %bb2.i.i.i.i.i8.i.i.i.i.i, %bb4.i48.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i.i), !dbg !23044, !noalias !22716
  %100 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 16, !dbg !23158
  %101 = load i64, ptr %100, align 8, !dbg !23160
  %102 = icmp eq i64 %101, -1, !dbg !23160
  br i1 %102, label %bb5.i.i.i, label %bb37.sink.split.i.i.i.i, !dbg !23160

bb37.sink.split.i.i.i.i:                          ; preds = %bb34.i.i.i.i, %bb28.i.i.i.i
  %self.val.i.i = phi i64 [ %119, %bb34.i.i.i.i ], [ %101, %bb28.i.i.i.i ], !dbg !23162
  call void @llvm.experimental.noalias.scope.decl(metadata !23170), !dbg !23173
  call void @llvm.experimental.noalias.scope.decl(metadata !23174), !dbg !23177
  %103 = icmp eq i64 %self.val.i.i, 0
  br i1 %103, label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i, label %bb2.i.i.i28, !dbg !23178

bb2.i.i.i28:                                      ; preds = %bb37.sink.split.i.i.i.i
  %104 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 24, !dbg !23162
  %self.val1.i.i29 = load ptr, ptr %104, align 8, !dbg !23162, !alias.scope !23181, !nonnull !37, !noundef !37
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %self.val1.i.i29, i64 noundef %self.val.i.i, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !23182, !noalias !23181
  br label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i, !dbg !23187

_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i: ; preds = %bb2.i.i.i28, %bb37.sink.split.i.i.i.i
  %105 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 40, !dbg !23188
; invoke core::ptr::drop_glue::<arrow_schema::datatype::DataType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema8datatype8DataTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(24) %105)
          to label %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit unwind label %cleanup1.i, !dbg !23188

cleanup1.i:                                       ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i
  %106 = landingpad { ptr, i32 }
          cleanup
  %107 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 64, !dbg !23188
; invoke <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %107)
          to label %common.resume unwind label %terminate.i, !dbg !23189

terminate.i:                                      ; preds = %cleanup1.i
  %108 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23188
  unreachable, !dbg !23188

common.resume:                                    ; preds = %bb52.i.i.i.i, %bb2.i.i.i.i.i.i, %bb60.i.i.i, %bb2.i.i53.i.i.i, %bb27.i46.i.i, %bb2.i.i58.i.i.i, %bb46.i.i, %bb2.i.i122.i.i, %cleanup1.i73, %cleanup1.i60, %cleanup1.i47, %cleanup1.i
  %common.resume.op = phi { ptr, i32 } [ %276, %cleanup1.i73 ], [ %106, %cleanup1.i ], [ %170, %cleanup1.i47 ], [ %218, %cleanup1.i60 ], [ %.pn27158.i.i, %bb46.i.i ], [ %.pn35.i.i.i.i, %bb2.i.i.i.i.i.i ], [ %.pn27158.i.i, %bb2.i.i122.i.i ], [ %.pn23.i.i.i, %bb2.i.i58.i.i.i ], [ %.pn23.i.i.i, %bb27.i46.i.i ], [ %.pn2583.i.i.i, %bb2.i.i53.i.i.i ], [ %.pn35.i.i.i.i, %bb52.i.i.i.i ], [ %.pn2583.i.i.i, %bb60.i.i.i ]
  resume { ptr, i32 } %common.resume.op, !dbg !23193

_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit: ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i
  %109 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 64, !dbg !23188
; call <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  call void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %109), !dbg !23194
  br label %bb5.i.i.i, !dbg !23173

_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecINtNtNtB4_3mem12maybe_uninit11MaybeUninitbEEECskkDzpO6M0zw_10boundaries.exit.i57.i.i.i.i: ; preds = %bb67.i.i.i.i, %bb69.i.i.i.i
  %.sink = phi i64 [ 32, %bb67.i.i.i.i ], [ 24, %bb69.i.i.i.i ]
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109.sink = phi i64 [ %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109, %bb67.i.i.i.i ], [ %_43.sroa.5.i.i.i.i.sroa.8.0.copyload96, %bb69.i.i.i.i ]
  %.sink160 = phi i64 [ 8, %bb67.i.i.i.i ], [ 32, %bb69.i.i.i.i ]
  %_116.sroa.0.0.copyload.i.i.i.i.sink = phi ptr [ %_116.sroa.0.0.copyload.i.i.i.i, %bb67.i.i.i.i ], [ %_43.sroa.5.i.i.i.i.sroa.9.0.copyload100, %bb69.i.i.i.i ]
  %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0._119.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink, !dbg !23198
  store i64 %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0.copyload109.sink, ptr %_31.sroa.6.sroa.8.i.i.i.i.sroa.7.0._119.sroa.4.0..sroa_idx.i.i.i.i.sroa_idx, align 8, !dbg !23198, !noalias !22779
  %110 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink160, !dbg !23198
  store ptr %_116.sroa.0.0.copyload.i.i.i.i.sink, ptr %110, align 8, !dbg !23198, !noalias !22779
  store i64 1, ptr %_0, align 8, !dbg !23199, !alias.scope !22782, !noalias !22779
  %111 = icmp eq i64 %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, 0
  br i1 %111, label %bb31.i.i.i.i, label %bb2.i.i31, !dbg !23200

bb2.i.i31:                                        ; preds = %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecINtNtNtB4_3mem12maybe_uninit11MaybeUninitbEEECskkDzpO6M0zw_10boundaries.exit.i57.i.i.i.i
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %_21.sroa.6.i.i.i.i.sroa.6.0.copyload, i64 noundef %_21.sroa.6.i.i.i.i.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !23207, !noalias !23212
  br label %bb31.i.i.i.i, !dbg !23215

bb31.i.i.i.i:                                     ; preds = %bb2.i.i31, %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueINtNtCs6KVRSXc8uZF_5alloc3vec3VecINtNtNtB4_3mem12maybe_uninit11MaybeUninitbEEECskkDzpO6M0zw_10boundaries.exit.i57.i.i.i.i, %bb60.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !23216), !dbg !23044
  call void @llvm.experimental.noalias.scope.decl(metadata !23219), !dbg !23222
  call void @llvm.experimental.noalias.scope.decl(metadata !23224), !dbg !23227
  call void @llvm.experimental.noalias.scope.decl(metadata !23229), !dbg !23232
  call void @llvm.experimental.noalias.scope.decl(metadata !23234), !dbg !23237
  call void @llvm.experimental.noalias.scope.decl(metadata !23239), !dbg !23242
  %_10.i.i.i.i.i.i62.i.i.i.i = load ptr, ptr %columns.i.i.i.i, align 8, !dbg !23244, !alias.scope !23248, !noalias !22716, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i.i63.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i.i62.i.i.i.i, i64 1 release, align 8, !dbg !23249, !noalias !23252
  %112 = icmp eq i64 %_2.i.i.i.i.i.i63.i.i.i.i, 1, !dbg !23253
  br i1 %112, label %bb2.i.i.i.i.i.i68.i.i.i.i, label %bb4.i64.i.i.i.i, !dbg !23253

bb2.i.i.i.i.i.i68.i.i.i.i:                        ; preds = %bb31.i.i.i.i
  fence acquire, !dbg !23254
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %columns.i.i.i.i) #23
          to label %bb4.i64.i.i.i.i unwind label %cleanup.i69.i.i.i.i, !dbg !23256, !noalias !22737

cleanup.i69.i.i.i.i:                              ; preds = %bb2.i.i.i.i.i.i68.i.i.i.i
  %113 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !23257), !dbg !23222
  call void @llvm.experimental.noalias.scope.decl(metadata !23260), !dbg !23263
  call void @llvm.experimental.noalias.scope.decl(metadata !23265), !dbg !23268
  call void @llvm.experimental.noalias.scope.decl(metadata !23270), !dbg !23273
  call void @llvm.experimental.noalias.scope.decl(metadata !23275), !dbg !23278
  %_10.i.i.i.i.i1.i70.i.i.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i, align 8, !dbg !23280, !alias.scope !23284, !noalias !22716, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i2.i71.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i1.i70.i.i.i.i, i64 1 release, align 8, !dbg !23285, !noalias !23288
  %114 = icmp eq i64 %_2.i.i.i.i.i2.i71.i.i.i.i, 1, !dbg !23289
  br i1 %114, label %bb2.i.i.i.i.i3.i73.i.i.i.i, label %bb52.i.i.i.i, !dbg !23289

bb2.i.i.i.i.i3.i73.i.i.i.i:                       ; preds = %cleanup.i69.i.i.i.i
  fence acquire, !dbg !23290
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i) #23
          to label %bb52.i.i.i.i unwind label %terminate.i74.i.i.i.i, !dbg !23292, !noalias !22737

bb4.i64.i.i.i.i:                                  ; preds = %bb2.i.i.i.i.i.i68.i.i.i.i, %bb31.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !23293), !dbg !23222
  call void @llvm.experimental.noalias.scope.decl(metadata !23296), !dbg !23299
  call void @llvm.experimental.noalias.scope.decl(metadata !23301), !dbg !23304
  call void @llvm.experimental.noalias.scope.decl(metadata !23306), !dbg !23309
  call void @llvm.experimental.noalias.scope.decl(metadata !23311), !dbg !23314
  %_10.i.i.i.i.i6.i65.i.i.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i, align 8, !dbg !23316, !alias.scope !23320, !noalias !22716, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i7.i66.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i6.i65.i.i.i.i, i64 1 release, align 8, !dbg !23321, !noalias !23324
  %115 = icmp eq i64 %_2.i.i.i.i.i7.i66.i.i.i.i, 1, !dbg !23325
  br i1 %115, label %bb2.i.i.i.i.i8.i67.i.i.i.i, label %bb34.i.i.i.i, !dbg !23325

bb2.i.i.i.i.i8.i67.i.i.i.i:                       ; preds = %bb4.i64.i.i.i.i
  fence acquire, !dbg !23326
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i.i) #23
          to label %bb34.i.i.i.i unwind label %cleanup.i.i.i.i, !dbg !23328, !noalias !22737

terminate.i74.i.i.i.i:                            ; preds = %bb2.i.i.i.i.i3.i73.i.i.i.i
  %116 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23222, !noalias !22737
  unreachable, !dbg !23222

unreachable.i.i.i.i:                              ; preds = %bb64.i.i.i.i
  unreachable

terminate.i.i.i.i:                                ; preds = %bb40.i.i.i.i, %bb2.i.i.i.i.i.i
  %117 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23329, !noalias !22757
  unreachable, !dbg !23329

bb34.i.i.i.i:                                     ; preds = %bb2.i.i.i.i.i8.i67.i.i.i.i, %bb4.i64.i.i.i.i, %bb33.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i.i), !dbg !23044, !noalias !22716
  %118 = getelementptr inbounds nuw i8, ptr %_11.i.i.i, i64 16, !dbg !23330
  %119 = load i64, ptr %118, align 8, !dbg !23332
  %120 = icmp eq i64 %119, -1, !dbg !23332
  br i1 %120, label %bb5.i.i.i, label %bb37.sink.split.i.i.i.i, !dbg !23332

bb40.i.i.i.i:                                     ; preds = %bb2.i.i.i18, %bb48.thread109.loopexit.split-lp.i.i.i.i, %bb48.i.i.i.i, %cleanup12.i.i.i.i, %cleanup11.i.i.i.i
  %.pn33.i.i.i.i = phi { ptr, i32 } [ %15, %cleanup11.i.i.i.i ], [ %17, %cleanup12.i.i.i.i ], [ %lpad.thr_comm.split-lp.i.i.i.i, %bb48.i.i.i.i ], [ %lpad.loopexit.split-lp.i.i.i.i, %bb48.thread109.loopexit.split-lp.i.i.i.i ], [ %lpad.loopexit.split-lp.i.i.i.i, %bb2.i.i.i18 ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<rofl_arrow::ArrowHost, i8>, rofl::tuple::Column<rofl_arrow::ArrowHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(64) %columns.i.i.i.i) #21
          to label %bb52.i.i.i.i unwind label %terminate.i.i.i.i, !dbg !23044, !noalias !22737

bb6.i.i.i:                                        ; preds = %bb62.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.sroa.15.i.i.i), !dbg !23334
  call void @llvm.experimental.noalias.scope.decl(metadata !23335), !dbg !23338
  %tolerant.i.i.i.i = icmp eq i64 %_10.i.i.i, 2, !dbg !23339
  br i1 %tolerant.i.i.i.i, label %bb1.i32.i.i.i, label %start.bb4_crit_edge.i.i.i.i, !dbg !23341

start.bb4_crit_edge.i.i.i.i:                      ; preds = %bb6.i.i.i
  %.phi.trans.insert.i.i.i.i = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 128
  %_11.0.pre.i.i.i.i = load ptr, ptr %.phi.trans.insert.i.i.i.i, align 8, !dbg !23342, !alias.scope !23343, !noalias !23344
  %.phi.trans.insert4.i.i.i.i = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 136
  %_11.1.pre.i.i.i.i = load i64, ptr %.phi.trans.insert4.i.i.i.i, align 8, !dbg !23342, !alias.scope !23343, !noalias !23344
  br label %bb4.i29.i.i.i, !dbg !23341

bb4.i29.i.i.i:                                    ; preds = %bb11.i35.i.i.i, %start.bb4_crit_edge.i.i.i.i
  %_11.1.i.i.i.i = phi i64 [ %_11.1.pre.i.i.i.i, %start.bb4_crit_edge.i.i.i.i ], [ %_10.1.i.i.i.i, %bb11.i35.i.i.i ], !dbg !23342
  %_11.0.i.i.i.i = phi ptr [ %_11.0.pre.i.i.i.i, %start.bb4_crit_edge.i.i.i.i ], [ %_10.0.i.i.i.i, %bb11.i35.i.i.i ], !dbg !23342
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i.i), !dbg !23346, !noalias !23347
  %121 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 168, !dbg !23348
  %_12.i.i.i.i = load ptr, ptr %121, align 8, !dbg !23348, !alias.scope !23343, !noalias !23344, !nonnull !37, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_9.i.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i.i.i, i64 noundef %_11.1.i.i.i.i, i1 noundef zeroext %tolerant.i.i.i.i, ptr noalias nofree noundef nonnull %_12.i.i.i.i)
          to label %.noexc37.i.i.i unwind label %bb42.thread91.i.i.i, !dbg !23346, !noalias !22670

.noexc37.i.i.i:                                   ; preds = %bb4.i29.i.i.i
  %122 = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 24, !dbg !23349
  %123 = load i8, ptr %122, align 8, !dbg !23349, !range !248, !noalias !23347, !noundef !37
  %124 = icmp eq i8 %123, 2, !dbg !23349
  br i1 %124, label %bb63.i.i.i, label %bb9.i.i.i, !dbg !23351

bb1.i32.i.i.i:                                    ; preds = %bb6.i.i.i
  %125 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 136, !dbg !23352
  %_10.1.i.i.i.i = load i64, ptr %125, align 8, !dbg !23352, !alias.scope !23343, !noalias !23344, !noundef !37
  %switch168 = icmp ult i64 %_10.1.i.i.i.i, 2, !dbg !23353
  br i1 %switch168, label %panic3.i34.invoke, label %bb11.i35.i.i.i, !dbg !23353

panic3.i34.invoke:                                ; preds = %bb1.i32.i.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i.i.i, i64 noundef %_10.1.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i34.cont unwind label %bb42.thread91.i.i.i, !dbg !23353

panic3.i34.cont:                                  ; preds = %panic3.i34.invoke
  unreachable

bb11.i35.i.i.i:                                   ; preds = %bb1.i32.i.i.i
  %126 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 128, !dbg !23352
  %_10.0.i.i.i.i = load ptr, ptr %126, align 8, !dbg !23352, !alias.scope !23343, !noalias !23344, !nonnull !37, !align !40, !noundef !37
  br label %bb4.i29.i.i.i, !dbg !23355

bb5.i.i.i:                                        ; preds = %bb34.i.i.i.i, %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit, %bb28.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.6.sroa.9.i.i.i.i), !dbg !23356
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i.i), !dbg !23357, !noalias !22679
  br label %bb3.i.i, !dbg !23358

bb63.i.i.i:                                       ; preds = %.noexc37.i.i.i
  %127 = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 32, !dbg !23359
  %_18.sroa.11.32.copyload56.i.i.i = load i64, ptr %127, align 8, !dbg !23359, !noalias !23360
  %_18.sroa.14.32..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 40, !dbg !23359
  %_18.sroa.14.32.copyload57.i.i.i = load i8, ptr %_18.sroa.14.32..sroa_idx.i.i.i, align 8, !dbg !23359, !noalias !23360
  %_18.sroa.15.32..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 41, !dbg !23359
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.15.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.15.32..sroa_idx.i.i.i, i64 23, i1 false), !dbg !23359, !noalias !23360
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i), !dbg !23361, !noalias !23347
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_17.sroa.7.sroa.10.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.15.i.i.i, i64 23, i1 false), !dbg !23362, !noalias !22679
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.sroa.15.i.i.i), !dbg !23365
  %_94.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !23366
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_94.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_17.sroa.7.sroa.10.i.i.i, i64 23, i1 false), !dbg !23365, !noalias !22696
  %128 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23366
  store i64 %_18.sroa.11.32.copyload56.i.i.i, ptr %128, align 8, !dbg !23366, !alias.scope !22698, !noalias !22696
  %_94.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23366
  store i8 %_18.sroa.14.32.copyload57.i.i.i, ptr %_94.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !23366, !alias.scope !22698, !noalias !22696
  store i64 1, ptr %_0, align 8, !dbg !23366, !alias.scope !22698, !noalias !22696
  br label %bb49.critedge.i.i.i, !dbg !22699

bb9.i.i.i:                                        ; preds = %.noexc37.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i.i.i), !dbg !23372, !noalias !22679
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %columns.i.i.i, ptr noundef nonnull align 8 dereferenceable(24) %_9.i.i.i.i, i64 24, i1 false), !dbg !23373, !noalias !22679
  %_18.sroa.10.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 25, !dbg !23373
  %val.sroa.4.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 25, !dbg !23372
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %val.sroa.4.0.columns.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(7) %_18.sroa.10.0._9.i.sroa_idx.i.i.i, i64 7, i1 false), !dbg !23373, !noalias !22679
  %_18.sroa.11.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 32, !dbg !23373
  %_18.sroa.11.0.copyload.i.i.i = load i64, ptr %_18.sroa.11.0._9.i.sroa_idx.i.i.i, align 8, !dbg !23373, !noalias !23360
  %_18.sroa.14.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 40, !dbg !23373
  %_18.sroa.14.0.copyload.i.i.i = load i8, ptr %_18.sroa.14.0._9.i.sroa_idx.i.i.i, align 8, !dbg !23373, !noalias !23360
  %_18.sroa.15.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i.i, i64 41, !dbg !23373
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.15.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.15.0._9.i.sroa_idx.i.i.i, i64 23, i1 false), !dbg !23373, !noalias !23360
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i), !dbg !23361, !noalias !23347
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_17.sroa.7.sroa.10.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_18.sroa.15.i.i.i, i64 23, i1 false), !dbg !23374, !noalias !22679
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.sroa.15.i.i.i), !dbg !23365
  %val.sroa.2.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 24, !dbg !23372
  store i8 %123, ptr %val.sroa.2.0.columns.sroa_idx.i.i.i, align 8, !dbg !23372, !noalias !22679
  %val.sroa.4.sroa.2.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 32, !dbg !23372
  store i64 %_18.sroa.11.0.copyload.i.i.i, ptr %val.sroa.4.sroa.2.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23372, !noalias !22679
  %val.sroa.4.sroa.3.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 40, !dbg !23372
  store i8 %_18.sroa.14.0.copyload.i.i.i, ptr %val.sroa.4.sroa.3.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23372, !noalias !22679
  %val.sroa.4.sroa.4.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i.i, i64 41, !dbg !23372
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val.sroa.4.sroa.4.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_17.sroa.7.sroa.10.i.i.i, i64 23, i1 false), !dbg !23372, !noalias !22679
  call void @llvm.lifetime.start.p0(ptr nonnull %_26.i.i.i), !dbg !23375, !noalias !22679
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_26.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i.i.i)
          to label %bb11.i.i.i unwind label %cleanup10.i.i.i, !dbg !23375, !noalias !22670

cleanup10.i.i.i:                                  ; preds = %bb9.i.i.i
  %129 = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i, !dbg !23377

bb11.i.i.i:                                       ; preds = %bb9.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i.i.i), !dbg !23377, !noalias !22679
  call void @llvm.lifetime.start.p0(ptr nonnull %source.i.i.i), !dbg !23378, !noalias !22679
  call void @llvm.lifetime.start.p0(ptr nonnull %_29.sroa.5.i.i.i), !dbg !23380
  call void @llvm.lifetime.start.p0(ptr nonnull %_30.i.i.i), !dbg !23380, !noalias !22679
  %130 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 176, !dbg !23381
  %_32.i.i.i = load i64, ptr %130, align 8, !dbg !23381, !alias.scope !22674, !noalias !22704, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_30.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i.i.i, i64 noundef %_32.i.i.i)
          to label %bb12.i.i.i unwind label %cleanup11.i.i.i, !dbg !23380, !noalias !22670

cleanup11.i.i.i:                                  ; preds = %bb11.i.i.i
  %131 = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i

bb12.i.i.i:                                       ; preds = %bb11.i.i.i
  %_96.i.i.i = load i64, ptr %_30.i.i.i, align 8, !dbg !23382, !range !4730, !noalias !22679, !noundef !37
  %132 = trunc nuw i64 %_96.i.i.i to i1, !dbg !23385
  %133 = getelementptr inbounds nuw i8, ptr %_30.i.i.i, i64 8, !dbg !23386
  br i1 %132, label %bb65.i.i.i, label %bb66.i.i.i, !dbg !23385

bb65.i.i.i:                                       ; preds = %bb12.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_29.sroa.5.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %133, i64 32, i1 false), !dbg !23387, !noalias !22679
  call void @llvm.lifetime.end.p0(ptr nonnull %_30.i.i.i), !dbg !23388, !noalias !22679
  %134 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23389
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %134, ptr noundef nonnull align 8 dereferenceable(32) %_29.sroa.5.i.i.i, i64 32, i1 false), !dbg !23388, !noalias !22696
  store i64 1, ptr %_0, align 8, !dbg !23389, !alias.scope !22698, !noalias !22696
  call void @llvm.lifetime.end.p0(ptr nonnull %_29.sroa.5.i.i.i), !dbg !23395
  br label %bb31.i.i.i, !dbg !23396

bb66.i.i.i:                                       ; preds = %bb12.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_29.sroa.5.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %133, i64 56, i1 false), !dbg !23398, !noalias !22679
  call void @llvm.lifetime.end.p0(ptr nonnull %_30.i.i.i), !dbg !23388, !noalias !22679
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %source.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_29.sroa.5.i.i.i, i64 56, i1 false), !dbg !23380, !noalias !22679
  call void @llvm.lifetime.end.p0(ptr nonnull %_29.sroa.5.i.i.i), !dbg !23395
  call void @llvm.lifetime.start.p0(ptr nonnull %_37.i.i.i), !dbg !23399, !noalias !22679
  %135 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 184, !dbg !23401
  %_38.i.i.i = load i64, ptr %135, align 8, !dbg !23401, !alias.scope !22674, !noalias !22704, !noundef !37
  %_75.i.i.i = load ptr, ptr %121, align 8, !dbg !23402, !alias.scope !22674, !noalias !22704, !nonnull !37, !noundef !37
; invoke <rofl_arrow::ArrowHost as rofl::output::OutputBinding<bool>>::allocate
  invoke void @_RNvXs1_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB7_9ArrowHostINtNtCshZi9mpuUhIi_4rofl6output13OutputBindingbE8allocate(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_37.i.i.i, i64 noundef %_38.i.i.i, ptr noalias nofree noundef nonnull %_75.i.i.i)
          to label %bb13.i.i.i unwind label %cleanup12.i.i.i, !dbg !23399, !noalias !22670

cleanup12.i.i.i:                                  ; preds = %bb66.i.i.i
  %136 = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i

bb13.i.i.i:                                       ; preds = %bb66.i.i.i
  %137 = load i64, ptr %_37.i.i.i, align 8, !dbg !23403, !range !53, !noalias !22679, !noundef !37
  %.not19.i.i.i = icmp eq i64 %137, -1, !dbg !23403
  %138 = getelementptr inbounds nuw i8, ptr %_37.i.i.i, i64 8, !dbg !23406
  %_36.sroa.6.i.i.i.sroa.0.0.copyload = load i64, ptr %138, align 8, !dbg !23406, !noalias !22679
  %_36.sroa.6.i.i.i.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_37.i.i.i, i64 16, !dbg !23406
  %_36.sroa.6.i.i.i.sroa.6.0.copyload = load ptr, ptr %_36.sroa.6.i.i.i.sroa.6.0..sroa_idx, align 8, !dbg !23406, !noalias !22679
  %_36.sroa.6.i.i.i.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_37.i.i.i, i64 24, !dbg !23406
  %_36.sroa.6.i.i.i.sroa.7.0.copyload = load i64, ptr %_36.sroa.6.i.i.i.sroa.7.0..sroa_idx, align 8, !dbg !23406, !noalias !22679
  call void @llvm.lifetime.end.p0(ptr nonnull %_37.i.i.i), !dbg !23407, !noalias !22679
  br i1 %.not19.i.i.i, label %bb14.i.i.i, label %bb67.i.i.i, !dbg !23408

bb67.i.i.i:                                       ; preds = %bb13.i.i.i
  %_108.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23409
  store i64 %_36.sroa.6.i.i.i.sroa.0.0.copyload, ptr %_108.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !23407, !noalias !22696
  %_36.sroa.6.i.i.i.sroa.6.0._108.sroa.4.0..sroa_idx.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !23407
  store ptr %_36.sroa.6.i.i.i.sroa.6.0.copyload, ptr %_36.sroa.6.i.i.i.sroa.6.0._108.sroa.4.0..sroa_idx.i.i.i.sroa_idx, align 8, !dbg !23407, !noalias !22696
  %_36.sroa.6.i.i.i.sroa.7.0._108.sroa.4.0..sroa_idx.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !23407
  store i64 %_36.sroa.6.i.i.i.sroa.7.0.copyload, ptr %_36.sroa.6.i.i.i.sroa.7.0._108.sroa.4.0..sroa_idx.i.i.i.sroa_idx, align 8, !dbg !23407, !noalias !22696
  %139 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23409
  store i64 %137, ptr %139, align 8, !dbg !23409, !alias.scope !22698, !noalias !22696
  store i64 1, ptr %_0, align 8, !dbg !23409, !alias.scope !22698, !noalias !22696
  br label %bb31.i.i.i, !dbg !23415

cleanup13.i.i.i:                                  ; preds = %bb89.i.i.i
  %lpad.thr_comm.split-lp.i.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb39.i.i.i, !dbg !23416

bb14.i.i.i:                                       ; preds = %bb13.i.i.i
  %140 = icmp ne ptr %_36.sroa.6.i.i.i.sroa.6.0.copyload, null
  call void @llvm.assume(i1 %140)
  %_44.i.i.i = load i64, ptr %135, align 8, !dbg !23417, !alias.scope !22674, !noalias !22704, !noundef !37
  %_110.not.i.i.i = icmp ugt i64 %_44.i.i.i, %_36.sroa.6.i.i.i.sroa.7.0.copyload
  br i1 %_110.not.i.i.i, label %bb71.i.i.i, label %bb69.i.i.i, !dbg !23419, !prof !11657

bb69.i.i.i:                                       ; preds = %bb14.i.i.i
  %_46.i.i.i = load i64, ptr %_6.i.i, align 8, !dbg !23428, !range !5768, !alias.scope !22674, !noalias !22704, !noundef !37
  %switch.i.i.i = icmp samesign ult i64 %_46.i.i.i, 2, !dbg !23430
  br i1 %switch.i.i.i, label %bb16.i.i.i, label %bb15.i.i.i, !dbg !23430

bb71.i.i.i:                                       ; preds = %bb14.i.i.i
; invoke core::slice::index::slice_index_fail
  invoke void @_RNvNtNtCslWxY2MhVcag_4core5slice5index16slice_index_fail(i64 noundef 0, i64 noundef %_44.i.i.i, i64 noundef %_36.sroa.6.i.i.i.sroa.7.0.copyload, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_c36786f282933a289f505b54550b5c03) #22
          to label %unreachable.i.i.i unwind label %bb50.i.i.i, !dbg !23431, !noalias !22670

bb15.i.i.i:                                       ; preds = %bb69.i.i.i
  %_12895.i.i.i = icmp samesign eq i64 %_44.i.i.i, 0, !dbg !23432
  br i1 %_12895.i.i.i, label %bb20.i.i.i, label %bb19.preheader.i.i.i, !dbg !23441

bb19.preheader.i.i.i:                             ; preds = %bb15.i.i.i
  call void @llvm.memset.p0.i64(ptr nonnull align 1 %_36.sroa.6.i.i.i.sroa.6.0.copyload, i8 0, i64 %_44.i.i.i, i1 false), !dbg !23442, !noalias !22670
  %_59.pre.i.i.i = load i64, ptr %135, align 8, !dbg !23446, !alias.scope !22674, !noalias !22704
  %self.val.pre.i.i.i = load i64, ptr %_6.i.i, align 8, !dbg !23448, !range !5768, !alias.scope !22674, !noalias !22704
  br label %bb20.i.i.i, !dbg !23449

bb16.i.i.i:                                       ; preds = %bb69.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_47.i.i.i), !dbg !23450, !noalias !22679
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_47.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %source.i.i.i, i64 56, i1 false), !dbg !23450, !noalias !22679
  %141 = invoke fastcc noundef zeroext i1 @_RINvYINtNtCshZi9mpuUhIi_4rofl5tuple11TupleSourceTINtB6_6SourceNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostxEBL_EENtNtNtCs7tX4SdoNkTE_12rofl_kernels12lane_kernels8map_into16IndexedSourceExt16map_checked_intobbNCINvMNtNtB8_7execute5ownedINtB3m_7ExecuteBY_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB3F_INtNtB8_7visitor10RowVisitorBY_E19visit_deferred_boolB57_bKB4T_NCINvXs1_B40_B3X_INtB5r_5RowFnBY_E8dispatchB3F_Es4_0NCB6r_s5_0E0NCB5g_s_0B7f_E0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(56) %_47.i.i.i, ptr noalias nofree noundef nonnull %_36.sroa.6.i.i.i.sroa.6.0.copyload, i64 noundef %_44.i.i.i)
          to label %bb22.i.i.i unwind label %bb50.i.i.i, !dbg !23451

bb22.i.i.i:                                       ; preds = %bb16.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_47.i.i.i), !dbg !23452, !noalias !22679
  call void @llvm.lifetime.start.p0(ptr nonnull %_67.i.i.i), !dbg !23453, !noalias !22679
  br i1 %141, label %bb1.i40.i.i.i, label %bb89.i.i.i, !dbg !23455, !prof !11822

bb1.i40.i.i.i:                                    ; preds = %bb87.i.i.i, %bb22.i.i.i
; invoke rofl_examples::functions::row_error::<rofl_arrow::ArrowHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(address) dereferenceable(32) %_67.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb23.i.i.i unwind label %bb50.i.i.i, !dbg !23457, !noalias !22670

bb20.i.i.i:                                       ; preds = %bb19.preheader.i.i.i, %bb15.i.i.i
  %self.val.i.i.i = phi i64 [ %self.val.pre.i.i.i, %bb19.preheader.i.i.i ], [ %_46.i.i.i, %bb15.i.i.i ], !dbg !23448
  %_59.i.i.i = phi i64 [ %_59.pre.i.i.i, %bb19.preheader.i.i.i ], [ 0, %bb15.i.i.i ], !dbg !23446
  call void @llvm.lifetime.start.p0(ptr nonnull %failure6.i.i.i), !dbg !23449, !noalias !22679
  store i8 0, ptr %failure6.i.i.i, align 1, !dbg !23458, !noalias !22679
  call void @llvm.lifetime.start.p0(ptr nonnull %_56.i.i.i), !dbg !23448, !noalias !22679
  %_58.i.i.i = load i64, ptr %130, align 8, !dbg !23459, !alias.scope !22674, !noalias !22704, !noundef !37
  call void @llvm.lifetime.start.p0(ptr nonnull %_60.i.i.i), !dbg !23460, !noalias !22679
  store ptr %prepared.i.i.i, ptr %_60.i.i.i, align 8, !dbg !23460, !noalias !22679
  %142 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 8, !dbg !23460
  store ptr %prepared.i.i.i, ptr %142, align 8, !dbg !23460, !noalias !22679
  %143 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 16, !dbg !23460
  store ptr %source.i.i.i, ptr %143, align 8, !dbg !23460, !noalias !22679
  %144 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 24, !dbg !23460
  store ptr %_36.sroa.6.i.i.i.sroa.6.0.copyload, ptr %144, align 8, !dbg !23460, !noalias !22679
  %145 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 32, !dbg !23460
  store i64 %_44.i.i.i, ptr %145, align 8, !dbg !23460, !noalias !22679
  %146 = getelementptr inbounds nuw i8, ptr %_60.i.i.i, i64 40, !dbg !23460
  store ptr %failure6.i.i.i, ptr %146, align 8, !dbg !23460, !noalias !22679
  %147 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 8, !dbg !23448
  %self.val28.i.i.i = load ptr, ptr %147, align 8, !dbg !23448, !alias.scope !22674, !noalias !22704
  invoke fastcc void @_RINvNtCshZi9mpuUhIi_4rofl7execute13selected_rowsNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostNCINvMNtB2_5ownedINtB2_7ExecuteBK_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8deferredTxxEbubNCINvYB1D_INtNtB4_7visitor10RowVisitorBK_E19visit_deferred_boolB34_bKB2Q_NCINvXs1_B1X_B1U_INtB3o_5RowFnBK_E8dispatchB1D_Es4_0NCB4o_s5_0E0NCB3d_s_0B5c_Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 captures(address) dereferenceable(32) %_56.i.i.i, i64 %self.val.i.i.i, ptr %self.val28.i.i.i, i64 noundef %_58.i.i.i, i64 noundef %_59.i.i.i, ptr noalias nofree noundef align 8 captures(address) dereferenceable(48) %_60.i.i.i)
          to label %bb21.i.i.i unwind label %bb50.i.i.i, !dbg !23448, !noalias !22670

bb21.i.i.i:                                       ; preds = %bb20.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_60.i.i.i), !dbg !23461, !noalias !22679
  %148 = load i64, ptr %_56.i.i.i, align 8, !dbg !23462, !range !53, !noalias !22679, !noundef !37
  %.not20.i.i.i = icmp eq i64 %148, -1, !dbg !23462
  br i1 %.not20.i.i.i, label %bb87.i.i.i, label %bb86.i.i.i, !dbg !23464

bb86.i.i.i:                                       ; preds = %bb21.i.i.i
  %149 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23465
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %149, ptr noundef nonnull align 8 dereferenceable(32) %_56.i.i.i, i64 32, i1 false), !dbg !23471, !noalias !22696
  call void @llvm.lifetime.end.p0(ptr nonnull %_56.i.i.i), !dbg !23472, !noalias !22679
  store i64 1, ptr %_0, align 8, !dbg !23465, !alias.scope !22698, !noalias !22696
  call void @llvm.lifetime.end.p0(ptr nonnull %failure6.i.i.i), !dbg !23473, !noalias !22679
  br label %bb29.i.i.i, !dbg !23474

bb87.i.i.i:                                       ; preds = %bb21.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_56.i.i.i), !dbg !23472, !noalias !22679
  %150 = load i8, ptr %failure6.i.i.i, align 1, !dbg !23476, !range !168, !noalias !22679, !noundef !37
  call void @llvm.lifetime.end.p0(ptr nonnull %failure6.i.i.i), !dbg !23473, !noalias !22679
  %extract.t.i.i.i = trunc nuw i8 %150 to i1, !dbg !23473
  call void @llvm.lifetime.start.p0(ptr nonnull %_67.i.i.i), !dbg !23453, !noalias !22679
  br i1 %extract.t.i.i.i, label %bb1.i40.i.i.i, label %bb89.i.i.i, !dbg !23455, !prof !11822

bb23.i.i.i:                                       ; preds = %bb1.i40.i.i.i
  %.pr.i.i.i = load i64, ptr %_67.i.i.i, align 8, !dbg !23477, !noalias !22679
  %.not22.i.i.i = icmp eq i64 %.pr.i.i.i, -1, !dbg !23477
  br i1 %.not22.i.i.i, label %bb89.i.i.i, label %bb88.i.i.i, !dbg !23479

bb88.i.i.i:                                       ; preds = %bb23.i.i.i
  %151 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23480
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %151, ptr noundef nonnull align 8 dereferenceable(32) %_67.i.i.i, i64 32, i1 false), !dbg !23486, !noalias !22696
  call void @llvm.lifetime.end.p0(ptr nonnull %_67.i.i.i), !dbg !23487, !noalias !22679
  store i64 1, ptr %_0, align 8, !dbg !23480, !alias.scope !22698, !noalias !22696
  br label %bb29.i.i.i, !dbg !23488

bb89.i.i.i:                                       ; preds = %bb23.i.i.i, %bb87.i.i.i, %bb22.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_67.i.i.i), !dbg !23487, !noalias !22679
  call void @llvm.lifetime.start.p0(ptr nonnull %_73.i.i.i), !dbg !23490, !noalias !22679
  store i64 %_36.sroa.6.i.i.i.sroa.0.0.copyload, ptr %_73.i.i.i, align 8, !dbg !23490, !noalias !22679
  %output.i.i.i.sroa.8.0._73.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_73.i.i.i, i64 8, !dbg !23490
  store ptr %_36.sroa.6.i.i.i.sroa.6.0.copyload, ptr %output.i.i.i.sroa.8.0._73.i.i.i.sroa_idx, align 8, !dbg !23490, !noalias !22679
  %output.i.i.i.sroa.11.0._73.i.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_73.i.i.i, i64 16, !dbg !23490
  store i64 %_36.sroa.6.i.i.i.sroa.7.0.copyload, ptr %output.i.i.i.sroa.11.0._73.i.i.i.sroa_idx, align 8, !dbg !23490, !noalias !22679
  %_74.i.i.i = load i64, ptr %135, align 8, !dbg !23491, !alias.scope !22674, !noalias !22704, !noundef !37
; invoke <rofl_arrow::output::BooleanOutputBuffer as rofl::output::OutputBuffer<bool>>::finish
  %152 = invoke { ptr, ptr } @_RNvXs0_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB5_19BooleanOutputBufferINtNtCshZi9mpuUhIi_4rofl6output12OutputBufferbE6finish(ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(24) %_73.i.i.i, i64 noundef %_74.i.i.i)
          to label %bb24.i.i.i unwind label %cleanup13.i.i.i, !dbg !23492, !noalias !22670

bb24.i.i.i:                                       ; preds = %bb89.i.i.i
  %_72.0.i.i.i = extractvalue { ptr, ptr } %152, 0, !dbg !23490
  %_72.1.i.i.i = extractvalue { ptr, ptr } %152, 1, !dbg !23490
  call void @llvm.lifetime.end.p0(ptr nonnull %_73.i.i.i), !dbg !23493, !noalias !22679
  %_71.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23494
  store ptr %_72.0.i.i.i, ptr %_71.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !23494, !alias.scope !22698, !noalias !22696
  %_71.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !23494
  store ptr %_72.1.i.i.i, ptr %_71.sroa.5.0..sroa_idx.i.i.i, align 8, !dbg !23494, !alias.scope !22698, !noalias !22696
  store <2 x i64> <i64 0, i64 -9223372036854775788>, ptr %_0, align 8, !dbg !23494, !alias.scope !22698, !noalias !22696
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i.i), !dbg !23415, !noalias !22679
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<rofl_arrow::ArrowHost, i8>, rofl::tuple::Column<rofl_arrow::ArrowHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(64) %columns.i.i.i)
          to label %bb27.i.i.i unwind label %bb42.thread91.i.i.i, !dbg !23358, !noalias !22670

bb27.i.i.i:                                       ; preds = %bb24.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i), !dbg !23358, !noalias !22679
  %153 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 16, !dbg !23495
  %154 = load i64, ptr %153, align 8, !dbg !23497, !range !127, !alias.scope !23499, !noalias !22704, !noundef !37
  %155 = icmp eq i64 %154, -1, !dbg !23497
  br i1 %155, label %bb3.i.i, label %bb2.i.i42.i.i.i, !dbg !23497

bb2.i.i42.i.i.i:                                  ; preds = %bb27.i.i.i
; call core::ptr::drop_glue::<arrow_schema::field::Field>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(112) %153), !dbg !23497
  br label %bb3.i.i, !dbg !23497

bb29.i.i.i:                                       ; preds = %bb88.i.i.i, %bb86.i.i.i
  %156 = icmp eq i64 %_36.sroa.6.i.i.i.sroa.0.0.copyload, 0
  br i1 %156, label %bb31.i.i.i, label %bb2.i.i.i39, !dbg !23504

bb2.i.i.i39:                                      ; preds = %bb29.i.i.i
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %_36.sroa.6.i.i.i.sroa.6.0.copyload, i64 noundef %_36.sroa.6.i.i.i.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !23511, !noalias !23516
  br label %bb31.i.i.i, !dbg !23519

bb31.i.i.i:                                       ; preds = %bb29.i.i.i, %bb2.i.i.i39, %bb67.i.i.i, %bb65.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i.i), !dbg !23415, !noalias !22679
  call void @llvm.experimental.noalias.scope.decl(metadata !23520), !dbg !23358
  call void @llvm.experimental.noalias.scope.decl(metadata !23523), !dbg !23526
  call void @llvm.experimental.noalias.scope.decl(metadata !23528), !dbg !23531
  call void @llvm.experimental.noalias.scope.decl(metadata !23533), !dbg !23536
  call void @llvm.experimental.noalias.scope.decl(metadata !23538), !dbg !23541
  call void @llvm.experimental.noalias.scope.decl(metadata !23543), !dbg !23546
  %_10.i.i.i.i.i.i.i.i.i = load ptr, ptr %columns.i.i.i, align 8, !dbg !23548, !alias.scope !23552, !noalias !22679, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i.i.i.i.i, i64 1 release, align 8, !dbg !23553, !noalias !23556
  %157 = icmp eq i64 %_2.i.i.i.i.i.i.i.i.i, 1, !dbg !23557
  br i1 %157, label %bb2.i.i.i.i.i.i.i.i.i, label %bb4.i43.i.i.i, !dbg !23557

bb2.i.i.i.i.i.i.i.i.i:                            ; preds = %bb31.i.i.i
  fence acquire, !dbg !23558
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %columns.i.i.i) #23
          to label %bb4.i43.i.i.i unwind label %cleanup.i44.i.i.i, !dbg !23560, !noalias !22670

cleanup.i44.i.i.i:                                ; preds = %bb2.i.i.i.i.i.i.i.i.i
  %158 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !23561), !dbg !23526
  call void @llvm.experimental.noalias.scope.decl(metadata !23564), !dbg !23567
  call void @llvm.experimental.noalias.scope.decl(metadata !23569), !dbg !23572
  call void @llvm.experimental.noalias.scope.decl(metadata !23574), !dbg !23577
  call void @llvm.experimental.noalias.scope.decl(metadata !23579), !dbg !23582
  %_10.i.i.i.i.i1.i.i.i.i = load ptr, ptr %val.sroa.4.sroa.2.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23584, !alias.scope !23588, !noalias !22679, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i2.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i1.i.i.i.i, i64 1 release, align 8, !dbg !23589, !noalias !23592
  %159 = icmp eq i64 %_2.i.i.i.i.i2.i.i.i.i, 1, !dbg !23593
  br i1 %159, label %bb2.i.i.i.i.i3.i.i.i.i, label %bb60.i.i.i, !dbg !23593

bb2.i.i.i.i.i3.i.i.i.i:                           ; preds = %cleanup.i44.i.i.i
  fence acquire, !dbg !23594
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val.sroa.4.sroa.2.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i) #23
          to label %bb60.i.i.i unwind label %terminate.i46.i.i.i, !dbg !23596, !noalias !22670

bb4.i43.i.i.i:                                    ; preds = %bb2.i.i.i.i.i.i.i.i.i, %bb31.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !23597), !dbg !23526
  call void @llvm.experimental.noalias.scope.decl(metadata !23600), !dbg !23603
  call void @llvm.experimental.noalias.scope.decl(metadata !23605), !dbg !23608
  call void @llvm.experimental.noalias.scope.decl(metadata !23610), !dbg !23613
  call void @llvm.experimental.noalias.scope.decl(metadata !23615), !dbg !23618
  %_10.i.i.i.i.i6.i.i.i.i = load ptr, ptr %val.sroa.4.sroa.2.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23620, !alias.scope !23624, !noalias !22679, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i7.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i6.i.i.i.i, i64 1 release, align 8, !dbg !23625, !noalias !23628
  %160 = icmp eq i64 %_2.i.i.i.i.i7.i.i.i.i, 1, !dbg !23629
  br i1 %160, label %bb2.i.i.i.i.i8.i.i.i.i, label %bb33.i.i.i, !dbg !23629

bb2.i.i.i.i.i8.i.i.i.i:                           ; preds = %bb4.i43.i.i.i
  fence acquire, !dbg !23630
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val.sroa.4.sroa.2.0.val.sroa.4.0.columns.sroa_idx.sroa_idx.i.i.i) #23
          to label %bb33.i.i.i unwind label %bb42.thread91.i.i.i, !dbg !23632, !noalias !22670

terminate.i46.i.i.i:                              ; preds = %bb2.i.i.i.i.i3.i.i.i.i
  %161 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23526, !noalias !22670
  unreachable, !dbg !23526

unreachable.i.i.i:                                ; preds = %bb71.i.i.i
  unreachable

bb50.i.i.i:                                       ; preds = %bb20.i.i.i, %bb1.i40.i.i.i, %bb16.i.i.i, %bb71.i.i.i
  %lpad.thr_comm.i.i.i = landingpad { ptr, i32 }
          cleanup
  %162 = icmp eq i64 %_36.sroa.6.i.i.i.sroa.0.0.copyload, 0
  br i1 %162, label %bb39.i.i.i, label %bb2.i.i.i41, !dbg !23633

bb2.i.i.i41:                                      ; preds = %bb50.i.i.i
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %_36.sroa.6.i.i.i.sroa.6.0.copyload, i64 noundef %_36.sroa.6.i.i.i.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !23640, !noalias !23645
  br label %bb39.i.i.i, !dbg !23648

terminate.i.i.i:                                  ; preds = %bb2.i.i53.i.i.i, %bb39.i.i.i
  %163 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23649, !noalias !22670
  unreachable, !dbg !23649

bb33.i.i.i:                                       ; preds = %bb2.i.i.i.i.i8.i.i.i.i, %bb4.i43.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i.i), !dbg !23358, !noalias !22679
  br label %bb49.critedge.i.i.i, !dbg !23358

bb39.i.i.i:                                       ; preds = %bb2.i.i.i41, %bb50.i.i.i, %cleanup13.i.i.i, %cleanup12.i.i.i, %cleanup11.i.i.i, %cleanup10.i.i.i
  %.pn.i.i.i = phi { ptr, i32 } [ %136, %cleanup12.i.i.i ], [ %129, %cleanup10.i.i.i ], [ %lpad.thr_comm.split-lp.i.i.i, %cleanup13.i.i.i ], [ %131, %cleanup11.i.i.i ], [ %lpad.thr_comm.i.i.i, %bb50.i.i.i ], [ %lpad.thr_comm.i.i.i, %bb2.i.i.i41 ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<rofl_arrow::ArrowHost, i8>, rofl::tuple::Column<rofl_arrow::ArrowHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(64) %columns.i.i.i) #21
          to label %bb60.i.i.i unwind label %terminate.i.i.i, !dbg !23358, !noalias !22670

bb49.critedge.i.i.i:                              ; preds = %bb33.i.i.i, %bb63.i.i.i, %bb61.i.i.i
  %164 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 16, !dbg !23650
  %165 = load i64, ptr %164, align 8, !dbg !23652, !range !127, !alias.scope !23654, !noalias !22704, !noundef !37
  %166 = icmp eq i64 %165, -1, !dbg !23652
  br i1 %166, label %bb3.i.i, label %bb2.i.i51.i.i.i, !dbg !23652

bb2.i.i51.i.i.i:                                  ; preds = %bb49.critedge.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !23659), !dbg !23652
  call void @llvm.experimental.noalias.scope.decl(metadata !23662), !dbg !23665
  %167 = icmp eq i64 %165, 0
  br i1 %167, label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i46, label %bb2.i.i.i44, !dbg !23670

bb2.i.i.i44:                                      ; preds = %bb2.i.i51.i.i.i
  %168 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 24, !dbg !23674
  %self.val1.i.i45 = load ptr, ptr %168, align 8, !dbg !23674, !alias.scope !23675, !nonnull !37, !noundef !37
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %self.val1.i.i45, i64 noundef %165, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !23676, !noalias !23675
  br label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i46, !dbg !23681

_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i46: ; preds = %bb2.i.i.i44, %bb2.i.i51.i.i.i
  %169 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 40, !dbg !23682
; invoke core::ptr::drop_glue::<arrow_schema::datatype::DataType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema8datatype8DataTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(24) %169)
          to label %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit50 unwind label %cleanup1.i47, !dbg !23682

cleanup1.i47:                                     ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i46
  %170 = landingpad { ptr, i32 }
          cleanup
  %171 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 64, !dbg !23682
; invoke <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %171)
          to label %common.resume unwind label %terminate.i48, !dbg !23683

terminate.i48:                                    ; preds = %cleanup1.i47
  %172 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23682
  unreachable, !dbg !23682

_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit50: ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i46
  %173 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 64, !dbg !23682
; call <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  call void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %173), !dbg !23687
  br label %bb3.i.i, !dbg !23652

bb42.thread91.i.i.i:                              ; preds = %panic3.i34.invoke, %bb2.i.i.i.i.i8.i.i.i.i, %bb24.i.i.i, %bb4.i29.i.i.i, %bb1.i.i.i, %bb2.i.i
  %lpad.thr_comm89.i.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb60.i.i.i, !dbg !23358

bb60.i.i.i:                                       ; preds = %bb42.thread91.i.i.i, %bb39.i.i.i, %bb2.i.i.i.i.i3.i.i.i.i, %cleanup.i44.i.i.i
  %.pn2583.i.i.i = phi { ptr, i32 } [ %lpad.thr_comm89.i.i.i, %bb42.thread91.i.i.i ], [ %158, %cleanup.i44.i.i.i ], [ %158, %bb2.i.i.i.i.i3.i.i.i.i ], [ %.pn.i.i.i, %bb39.i.i.i ]
  %174 = getelementptr inbounds nuw i8, ptr %_6.i.i, i64 16, !dbg !23691
  %175 = load i64, ptr %174, align 8, !dbg !23693, !range !127, !alias.scope !23695, !noalias !22704, !noundef !37
  %176 = icmp eq i64 %175, -1, !dbg !23693
  br i1 %176, label %common.resume, label %bb2.i.i53.i.i.i, !dbg !23693

bb2.i.i53.i.i.i:                                  ; preds = %bb60.i.i.i
; invoke core::ptr::drop_glue::<arrow_schema::field::Field>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(112) %174)
          to label %common.resume unwind label %terminate.i.i.i, !dbg !23693, !noalias !22670

bb3.i.i:                                          ; preds = %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit50, %bb49.critedge.i.i.i, %bb2.i.i42.i.i.i, %bb27.i.i.i, %bb5.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_17.sroa.7.sroa.10.i.i.i), !dbg !23700
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i.i), !dbg !23701, !noalias !22667
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB2s_NCINvYBG_B2x_19visit_deferred_boolB3x_bKB2s_NCINvXs1_B1z_B1w_INtB2A_5RowFnBU_E8dispatchBG_Es4_0NCB4s_s5_0E0NCB3K_s_0B5f_ECskkDzpO6M0zw_10boundaries.exit, !dbg !23702

bb4.i.i:                                          ; preds = %bb1.i.i
; invoke <rofl::execute::Execute<rofl_arrow::ArrowHost, rofl_examples::functions::PositiveSum<true>>>::validate::<(i64, i64)>
  invoke fastcc void @_RINvMs_NtCshZi9mpuUhIi_4rofl7executeINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EE8validateTxxEECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 captures(address) dereferenceable(32) %_11.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(192) %self, ptr noalias nofree noundef align 8 captures(address) dereferenceable(112) %_13.i.i)
          to label %bb5.i.i unwind label %bb35.thread160.i.i, !dbg !23704

bb5.i.i:                                          ; preds = %bb4.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i), !dbg !23705, !noalias !22667
  %177 = load i64, ptr %_11.i.i, align 8, !dbg !23706, !range !53, !noalias !22667, !noundef !37
  %.not.i.i = icmp eq i64 %177, -1, !dbg !23706
  br i1 %.not.i.i, label %bb48.i.i, label %bb47.i.i, !dbg !23709

bb47.i.i:                                         ; preds = %bb5.i.i
  %178 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23710
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %178, ptr noundef nonnull align 8 dereferenceable(32) %_11.i.i, i64 32, i1 false), !dbg !23717, !noalias !22663
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i), !dbg !23718, !noalias !22667
  store i64 1, ptr %_0, align 8, !dbg !23710, !alias.scope !22664, !noalias !22663
  br label %bb39.critedge.i.i, !dbg !23702

bb48.i.i:                                         ; preds = %bb5.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_11.i.i), !dbg !23718, !noalias !22667
  %_15.i.i = load i64, ptr %self, align 8, !dbg !23719, !range !5768, !alias.scope !22663, !noalias !22664, !noundef !37
  %179 = icmp eq i64 %_15.i.i, 1, !dbg !23722
  br i1 %179, label %bb7.i.i, label %bb9.i.i, !dbg !23722

bb7.i.i:                                          ; preds = %bb48.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_16.i.i), !dbg !23723, !noalias !22667
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(192) %_16.i.i, ptr noundef nonnull align 8 dereferenceable(192) %self, i64 192, i1 false), !dbg !23723, !noalias !22664
  call void @llvm.experimental.noalias.scope.decl(metadata !23724), !dbg !23727
  call void @llvm.experimental.noalias.scope.decl(metadata !23728), !dbg !23727
  call void @llvm.lifetime.start.p0(ptr nonnull %_8.sroa.6.sroa.9.i.i.i), !dbg !23730
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i35.i.i), !dbg !23730, !noalias !23733
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.sroa.15.i.i.i), !dbg !23734
  call void @llvm.experimental.noalias.scope.decl(metadata !23735), !dbg !23738
  %_3.i.i.i.i = load i64, ptr %_16.i.i, align 8, !dbg !23739, !range !5768, !alias.scope !23741, !noalias !23742, !noundef !37
  %tolerant.i.i36.i.i = icmp eq i64 %_3.i.i.i.i, 2, !dbg !23744
  br i1 %tolerant.i.i36.i.i, label %bb1.i.i78.i.i, label %start.bb4_crit_edge.i.i37.i.i, !dbg !23745

start.bb4_crit_edge.i.i37.i.i:                    ; preds = %bb7.i.i
  %.phi.trans.insert.i.i38.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 128
  %_11.0.pre.i.i39.i.i = load ptr, ptr %.phi.trans.insert.i.i38.i.i, align 8, !dbg !23746, !alias.scope !23741, !noalias !23742
  %.phi.trans.insert4.i.i40.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 136
  %_11.1.pre.i.i41.i.i = load i64, ptr %.phi.trans.insert4.i.i40.i.i, align 8, !dbg !23746, !alias.scope !23741, !noalias !23742
  br label %bb4.i.i42.i.i, !dbg !23745

bb4.i.i42.i.i:                                    ; preds = %bb11.i.i83.i.i, %start.bb4_crit_edge.i.i37.i.i
  %_11.1.i.i43.i.i = phi i64 [ %_11.1.pre.i.i41.i.i, %start.bb4_crit_edge.i.i37.i.i ], [ %_10.1.i.i80.i.i, %bb11.i.i83.i.i ], !dbg !23746
  %_11.0.i.i44.i.i = phi ptr [ %_11.0.pre.i.i39.i.i, %start.bb4_crit_edge.i.i37.i.i ], [ %_10.0.i.i79.i.i, %bb11.i.i83.i.i ], !dbg !23746
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i31.i.i), !dbg !23747, !noalias !23748
  %180 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 168, !dbg !23749
  %_12.i.i45.i.i = load ptr, ptr %180, align 8, !dbg !23749, !alias.scope !23741, !noalias !23742, !nonnull !37, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_9.i.i31.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i44.i.i, i64 noundef %_11.1.i.i43.i.i, i1 noundef zeroext %tolerant.i.i36.i.i, ptr noalias nofree noundef nonnull %_12.i.i45.i.i)
          to label %.noexc.i.i.i unwind label %cleanup.i.i.i, !dbg !23747, !noalias !23750

.noexc.i.i.i:                                     ; preds = %bb4.i.i42.i.i
  %181 = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 24, !dbg !23751
  %182 = load i8, ptr %181, align 8, !dbg !23751, !range !248, !noalias !23748, !noundef !37
  %183 = icmp eq i8 %182, 2, !dbg !23751
  br i1 %183, label %bb16.i76.i.i, label %bb46.i.i.i, !dbg !23753

bb1.i.i78.i.i:                                    ; preds = %bb7.i.i
  %184 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 136, !dbg !23754
  %_10.1.i.i80.i.i = load i64, ptr %184, align 8, !dbg !23754, !alias.scope !23741, !noalias !23742, !noundef !37
  %switch169 = icmp ult i64 %_10.1.i.i80.i.i, 2, !dbg !23755
  br i1 %switch169, label %panic3.i51.invoke, label %bb11.i.i83.i.i, !dbg !23755

panic3.i51.invoke:                                ; preds = %bb1.i.i78.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i80.i.i, i64 noundef %_10.1.i.i80.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i51.cont unwind label %cleanup.i.i.i, !dbg !23755

panic3.i51.cont:                                  ; preds = %panic3.i51.invoke
  unreachable

bb11.i.i83.i.i:                                   ; preds = %bb1.i.i78.i.i
  %185 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 128, !dbg !23754
  %_10.0.i.i79.i.i = load ptr, ptr %185, align 8, !dbg !23754, !alias.scope !23741, !noalias !23742, !nonnull !37, !align !40, !noundef !37
  br label %bb4.i.i42.i.i, !dbg !23757

cleanup.i.i.i:                                    ; preds = %panic3.i51.invoke, %bb2.i.i.i.i.i8.i44.i.i.i, %bb2.i.i.i.i.i8.i.i65.i.i, %bb4.i.i42.i.i
  %186 = landingpad { ptr, i32 }
          cleanup
  br label %bb27.i46.i.i

bb46.i.i.i:                                       ; preds = %.noexc.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %columns.i35.i.i, ptr noundef nonnull align 8 dereferenceable(24) %_9.i.i31.i.i, i64 24, i1 false), !dbg !23758, !noalias !23733
  %_9.sroa.10.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 25, !dbg !23758
  %val2.sroa.5.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 25, !dbg !23759
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %val2.sroa.5.0.columns.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(7) %_9.sroa.10.0._9.i.sroa_idx.i.i.i, i64 7, i1 false), !dbg !23758, !noalias !23733
  %_9.sroa.11.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 32, !dbg !23758
  %_9.sroa.11.0.copyload.i.i.i = load i64, ptr %_9.sroa.11.0._9.i.sroa_idx.i.i.i, align 8, !dbg !23758, !noalias !23762
  %_9.sroa.14.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 40, !dbg !23758
  %_9.sroa.14.0.copyload.i.i.i = load i8, ptr %_9.sroa.14.0._9.i.sroa_idx.i.i.i, align 8, !dbg !23758, !noalias !23762
  %_9.sroa.15.0._9.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 41, !dbg !23758
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.0._9.i.sroa_idx.i.i.i, i64 23, i1 false), !dbg !23758, !noalias !23762
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i31.i.i), !dbg !23763, !noalias !23748
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i, i64 23, i1 false), !dbg !23764, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.15.i.i.i), !dbg !23767
  %val2.sroa.5.sroa.6.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 41, !dbg !23759
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val2.sroa.5.sroa.6.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i, i64 23, i1 false), !dbg !23734, !noalias !23733
  %val2.sroa.4.0.columns.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 24, !dbg !23759
  store i8 %182, ptr %val2.sroa.4.0.columns.sroa_idx.i.i.i, align 8, !dbg !23759, !noalias !23733
  %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 32, !dbg !23759
  store i64 %_9.sroa.11.0.copyload.i.i.i, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23759, !noalias !23733
  %val2.sroa.5.sroa.5.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %columns.i35.i.i, i64 40, !dbg !23759
  store i8 %_9.sroa.14.0.copyload.i.i.i, ptr %val2.sroa.5.sroa.5.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23759, !noalias !23733
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.i.i.i), !dbg !23768, !noalias !23733
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_18.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i35.i.i)
          to label %bb4.i51.i.i unwind label %cleanup5.i.i.i, !dbg !23768, !noalias !23750

bb16.i76.i.i:                                     ; preds = %.noexc.i.i.i
  %187 = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 32, !dbg !23770
  %_9.sroa.11.32.copyload61.i.i.i = load i64, ptr %187, align 8, !dbg !23770, !noalias !23762
  %_9.sroa.14.32..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 40, !dbg !23770
  %_9.sroa.14.32.copyload62.i.i.i = load i8, ptr %_9.sroa.14.32..sroa_idx.i.i.i, align 8, !dbg !23770, !noalias !23762
  %_9.sroa.15.32..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i31.i.i, i64 41, !dbg !23770
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.32..sroa_idx.i.i.i, i64 23, i1 false), !dbg !23770, !noalias !23762
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i31.i.i), !dbg !23763, !noalias !23748
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_9.sroa.15.i.i.i, i64 23, i1 false), !dbg !23771, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.sroa.15.i.i.i), !dbg !23767
  %_63.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !23772
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_63.sroa.5.0..sroa_idx.i.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_8.sroa.6.sroa.9.i.i.i, i64 23, i1 false), !dbg !23767, !noalias !23779
  %188 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23780
  store i64 %_9.sroa.11.32.copyload61.i.i.i, ptr %188, align 8, !dbg !23780, !alias.scope !23782, !noalias !23779
  %_69.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23780
  store i8 %_9.sroa.14.32.copyload62.i.i.i, ptr %_69.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !23780, !alias.scope !23782, !noalias !23779
  store i64 1, ptr %_0, align 8, !dbg !23783, !alias.scope !23782, !noalias !23779
  br label %bb19.i.i.i, !dbg !23785

cleanup5.i.i.i:                                   ; preds = %bb46.i.i.i
  %189 = landingpad { ptr, i32 }
          cleanup
  br label %bb25.i.i.i, !dbg !23786

bb4.i51.i.i:                                      ; preds = %bb46.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.i.i.i), !dbg !23786, !noalias !23733
  call void @llvm.lifetime.start.p0(ptr nonnull %_20.sroa.5.i.i.i), !dbg !23787
  call void @llvm.lifetime.start.p0(ptr nonnull %_21.i.i.i), !dbg !23787, !noalias !23733
  %190 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 176, !dbg !23789
  %_23.i.i.i = load i64, ptr %190, align 8, !dbg !23789, !alias.scope !23728, !noalias !23790, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_21.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i35.i.i, i64 noundef %_23.i.i.i)
          to label %bb5.i52.i.i unwind label %cleanup6.i.i.i, !dbg !23787, !noalias !23750

cleanup6.i.i.i:                                   ; preds = %bb4.i51.i.i
  %191 = landingpad { ptr, i32 }
          cleanup
  br label %bb25.i.i.i

bb5.i52.i.i:                                      ; preds = %bb4.i51.i.i
  %_71.i.i.i = load i64, ptr %_21.i.i.i, align 8, !dbg !23791, !range !4730, !noalias !23733, !noundef !37
  %192 = trunc nuw i64 %_71.i.i.i to i1, !dbg !23794
  %193 = getelementptr inbounds nuw i8, ptr %_21.i.i.i, i64 8, !dbg !23795
  br i1 %192, label %bb48.i.i.i, label %bb6.i53.i.i, !dbg !23794

bb48.i.i.i:                                       ; preds = %bb5.i52.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_20.sroa.5.i.i.i, ptr noundef nonnull align 8 dereferenceable(32) %193, i64 32, i1 false), !dbg !23796, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.i.i.i), !dbg !23797, !noalias !23733
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23798
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %194, ptr noundef nonnull align 8 dereferenceable(32) %_20.sroa.5.i.i.i, i64 32, i1 false), !dbg !23797, !noalias !23779
  store i64 1, ptr %_0, align 8, !dbg !23798, !alias.scope !23782, !noalias !23779
  call void @llvm.lifetime.end.p0(ptr nonnull %_20.sroa.5.i.i.i), !dbg !23804
  br label %bb15.i57.i.i, !dbg !23805

bb6.i53.i.i:                                      ; preds = %bb5.i52.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_20.sroa.5.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %193, i64 56, i1 false), !dbg !23806, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %_21.i.i.i), !dbg !23797, !noalias !23733
  call void @llvm.lifetime.start.p0(ptr nonnull %state.i.i.i), !dbg !23807, !noalias !23733
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %state.i.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_20.sroa.5.i.i.i, i64 56, i1 false), !dbg !23787, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %_20.sroa.5.i.i.i), !dbg !23804
  %195 = getelementptr inbounds nuw i8, ptr %state.i.i.i, i64 56, !dbg !23809
  store i8 0, ptr %195, align 8, !dbg !23809, !noalias !23733
  call void @llvm.lifetime.start.p0(ptr nonnull %values.i.i.i), !dbg !23810, !noalias !23733
  call void @llvm.lifetime.start.p0(ptr nonnull %_35.i.i.i), !dbg !23814, !noalias !23733
  invoke void @_RINvXs2_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB8_9ArrowHostNtNtCshZi9mpuUhIi_4rofl6output13BooleanOutput12collect_boolKb1_NCINvMNtNtBY_7execute11packed_boolINtB23_7ExecuteBF_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKB1S_EE15boolean_attemptTxxEubKB1S_NCINvYB2t_INtNtBY_7visitor10RowVisitorBF_E19visit_deferred_boolB44_bKB1S_NCINvXs1_B2O_B2L_INtB4s_5RowFnBF_E8dispatchB2t_Es4_0NCB5s_s5_0E0NCB4h_s_0B6g_Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_35.i.i.i, i64 noundef %_23.i.i.i, ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %state.i.i.i, ptr noalias nofree noundef nonnull %_12.i.i45.i.i)
          to label %bb7.i54.i.i unwind label %cleanup8.i.i.i, !dbg !23814, !noalias !23750

cleanup8.i.i.i:                                   ; preds = %bb2.i.i32.i.i.i, %bb6.i53.i.i
  %196 = landingpad { ptr, i32 }
          cleanup
  br label %bb25.i.i.i

bb7.i54.i.i:                                      ; preds = %bb6.i53.i.i
  %197 = load i64, ptr %_35.i.i.i, align 8, !dbg !23815, !range !53, !noalias !23733, !noundef !37
  %.not20.i55.i.i = icmp eq i64 %197, -1, !dbg !23815
  %198 = getelementptr inbounds nuw i8, ptr %_35.i.i.i, i64 8, !dbg !23818
  %_79.0.i.i.i = load ptr, ptr %198, align 8, !dbg !23818, !noalias !23733
  %199 = getelementptr inbounds nuw i8, ptr %_35.i.i.i, i64 16, !dbg !23818
  %_79.1.i.i.i = load ptr, ptr %199, align 8, !dbg !23818, !noalias !23733
  br i1 %.not20.i55.i.i, label %bb51.i.i.i, label %bb50.i56.i.i, !dbg !23819

bb50.i56.i.i:                                     ; preds = %bb7.i54.i.i
  %_80.sroa.6.0._35.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_35.i.i.i, i64 24, !dbg !23820
  %_80.sroa.6.0.copyload.i.i.i = load i64, ptr %_80.sroa.6.0._35.sroa_idx.i.i.i, align 8, !dbg !23820, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %_35.i.i.i), !dbg !23821, !noalias !23733
  %200 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23822
  store i64 %197, ptr %200, align 8, !dbg !23822, !alias.scope !23782, !noalias !23779
  %_83.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23822
  store ptr %_79.0.i.i.i, ptr %_83.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !23822, !alias.scope !23782, !noalias !23779
  %_83.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !23822
  store ptr %_79.1.i.i.i, ptr %_83.sroa.5.0..sroa_idx.i.i.i, align 8, !dbg !23822, !alias.scope !23782, !noalias !23779
  %_83.sroa.6.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !23822
  store i64 %_80.sroa.6.0.copyload.i.i.i, ptr %_83.sroa.6.0..sroa_idx.i.i.i, align 8, !dbg !23822, !alias.scope !23782, !noalias !23779
  store i64 1, ptr %_0, align 8, !dbg !23822, !alias.scope !23782, !noalias !23779
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i.i), !dbg !23828, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %state.i.i.i), !dbg !23829, !noalias !23733
  br label %bb15.i57.i.i, !dbg !23805

bb51.i.i.i:                                       ; preds = %bb7.i54.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_35.i.i.i), !dbg !23821, !noalias !23733
  store ptr %_79.0.i.i.i, ptr %values.i.i.i, align 8, !dbg !23830, !noalias !23733
  %201 = getelementptr inbounds nuw i8, ptr %values.i.i.i, i64 8, !dbg !23830
  store ptr %_79.1.i.i.i, ptr %201, align 8, !dbg !23830, !noalias !23733
  call void @llvm.lifetime.start.p0(ptr nonnull %_39.i.i.i), !dbg !23833, !noalias !23733
  %202 = load i8, ptr %195, align 8, !dbg !23835, !range !168, !noalias !23733, !noundef !37
  %_42.i.i.i = trunc nuw i8 %202 to i1, !dbg !23835
  br i1 %_42.i.i.i, label %bb1.i27.i.i.i, label %bb10.i.i.i, !dbg !23836, !prof !11822

bb1.i27.i.i.i:                                    ; preds = %bb51.i.i.i
; invoke rofl_examples::functions::row_error::<rofl_arrow::ArrowHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(address) dereferenceable(32) %_39.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb8.i73.i.i unwind label %cleanup9.i.i.i, !dbg !23838, !noalias !23750

cleanup9.i.i.i:                                   ; preds = %bb1.i27.i.i.i
  %203 = landingpad { ptr, i32 }
          cleanup
  %_2.i.i.i.i.i = atomicrmw sub ptr %_79.0.i.i.i, i64 1 release, align 8, !dbg !23839, !noalias !23844
  %204 = icmp eq i64 %_2.i.i.i.i.i, 1, !dbg !23849
  br i1 %204, label %bb2.i.i.i72.i.i, label %bb25.i.i.i, !dbg !23849

bb2.i.i.i72.i.i:                                  ; preds = %cleanup9.i.i.i
  fence acquire, !dbg !23850
; invoke <alloc::sync::Arc<dyn arrow_array::array::Array>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcDNtNtCs6AFQLBbsvVR_11arrow_array5array5ArrayEL_E9drop_slowBL_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i.i) #23
          to label %bb25.i.i.i unwind label %terminate.i47.i.i, !dbg !23852, !noalias !23750

bb8.i73.i.i:                                      ; preds = %bb1.i27.i.i.i
  %.pr.i74.i.i = load i64, ptr %_39.i.i.i, align 8, !dbg !23833, !noalias !23733
  %.not21.i.i.i = icmp eq i64 %.pr.i74.i.i, -1, !dbg !23833
  br i1 %.not21.i.i.i, label %bb10.i.i.i, label %bb9.i75.i.i, !dbg !23853

bb9.i75.i.i:                                      ; preds = %bb8.i73.i.i
  %205 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !23854
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %205, ptr noundef nonnull align 8 dereferenceable(32) %_39.i.i.i, i64 32, i1 false), !dbg !23856, !noalias !23779
  store i64 0, ptr %_0, align 8, !dbg !23854, !alias.scope !23782, !noalias !23779
  call void @llvm.lifetime.end.p0(ptr nonnull %_39.i.i.i), !dbg !23857, !noalias !23733
  %_2.i.i31.i.i.i = atomicrmw sub ptr %_79.0.i.i.i, i64 1 release, align 8, !dbg !23858, !noalias !23863
  %206 = icmp eq i64 %_2.i.i31.i.i.i, 1, !dbg !23868
  br i1 %206, label %bb2.i.i32.i.i.i, label %bb11.i59.i.i, !dbg !23868

bb2.i.i32.i.i.i:                                  ; preds = %bb9.i75.i.i
  fence acquire, !dbg !23869
; invoke <alloc::sync::Arc<dyn arrow_array::array::Array>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcDNtNtCs6AFQLBbsvVR_11arrow_array5array5ArrayEL_E9drop_slowBL_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i.i) #23
          to label %bb11.i59.i.i unwind label %cleanup8.i.i.i, !dbg !23871, !noalias !23750

bb10.i.i.i:                                       ; preds = %bb8.i73.i.i, %bb51.i.i.i
  %_44.sroa.4.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !23872
  store ptr %_79.0.i.i.i, ptr %_44.sroa.4.0..sroa_idx.i.i.i, align 8, !dbg !23872, !alias.scope !23782, !noalias !23779
  %_44.sroa.5.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !23872
  store ptr %_79.1.i.i.i, ptr %_44.sroa.5.0..sroa_idx.i.i.i, align 8, !dbg !23872, !alias.scope !23782, !noalias !23779
  store <2 x i64> <i64 0, i64 -9223372036854775788>, ptr %_0, align 8, !dbg !23872, !alias.scope !23782, !noalias !23779
  call void @llvm.lifetime.end.p0(ptr nonnull %_39.i.i.i), !dbg !23857, !noalias !23733
  br label %bb11.i59.i.i, !dbg !23828

bb11.i59.i.i:                                     ; preds = %bb10.i.i.i, %bb2.i.i32.i.i.i, %bb9.i75.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i.i), !dbg !23828, !noalias !23733
  call void @llvm.lifetime.end.p0(ptr nonnull %state.i.i.i), !dbg !23829, !noalias !23733
  call void @llvm.experimental.noalias.scope.decl(metadata !23873), !dbg !23785
  call void @llvm.experimental.noalias.scope.decl(metadata !23876), !dbg !23879
  call void @llvm.experimental.noalias.scope.decl(metadata !23881), !dbg !23884
  call void @llvm.experimental.noalias.scope.decl(metadata !23886), !dbg !23889
  call void @llvm.experimental.noalias.scope.decl(metadata !23891), !dbg !23894
  call void @llvm.experimental.noalias.scope.decl(metadata !23896), !dbg !23899
  %_10.i.i.i.i.i.i.i60.i.i = load ptr, ptr %columns.i35.i.i, align 8, !dbg !23901, !alias.scope !23905, !noalias !23733, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i.i.i61.i.i = atomicrmw sub ptr %_10.i.i.i.i.i.i.i60.i.i, i64 1 release, align 8, !dbg !23906, !noalias !23909
  %207 = icmp eq i64 %_2.i.i.i.i.i.i.i61.i.i, 1, !dbg !23910
  br i1 %207, label %bb2.i.i.i.i.i.i.i66.i.i, label %bb4.i35.i.i.i, !dbg !23910

bb2.i.i.i.i.i.i.i66.i.i:                          ; preds = %bb11.i59.i.i
  fence acquire, !dbg !23911
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %columns.i35.i.i) #23
          to label %bb4.i35.i.i.i unwind label %cleanup.i.i67.i.i, !dbg !23913, !noalias !23750

cleanup.i.i67.i.i:                                ; preds = %bb2.i.i.i.i.i.i.i66.i.i
  %208 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !23914), !dbg !23879
  call void @llvm.experimental.noalias.scope.decl(metadata !23917), !dbg !23920
  call void @llvm.experimental.noalias.scope.decl(metadata !23922), !dbg !23925
  call void @llvm.experimental.noalias.scope.decl(metadata !23927), !dbg !23930
  call void @llvm.experimental.noalias.scope.decl(metadata !23932), !dbg !23935
  %_10.i.i.i.i.i1.i.i68.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23937, !alias.scope !23941, !noalias !23733, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i2.i.i69.i.i = atomicrmw sub ptr %_10.i.i.i.i.i1.i.i68.i.i, i64 1 release, align 8, !dbg !23942, !noalias !23945
  %209 = icmp eq i64 %_2.i.i.i.i.i2.i.i69.i.i, 1, !dbg !23946
  br i1 %209, label %bb2.i.i.i.i.i3.i.i70.i.i, label %bb27.i46.i.i, !dbg !23946

bb2.i.i.i.i.i3.i.i70.i.i:                         ; preds = %cleanup.i.i67.i.i
  fence acquire, !dbg !23947
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i) #23
          to label %bb27.i46.i.i unwind label %terminate.i.i71.i.i, !dbg !23949, !noalias !23750

bb4.i35.i.i.i:                                    ; preds = %bb2.i.i.i.i.i.i.i66.i.i, %bb11.i59.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !23950), !dbg !23879
  call void @llvm.experimental.noalias.scope.decl(metadata !23953), !dbg !23956
  call void @llvm.experimental.noalias.scope.decl(metadata !23958), !dbg !23961
  call void @llvm.experimental.noalias.scope.decl(metadata !23963), !dbg !23966
  call void @llvm.experimental.noalias.scope.decl(metadata !23968), !dbg !23971
  %_10.i.i.i.i.i6.i.i62.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !23973, !alias.scope !23977, !noalias !23733, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i7.i.i63.i.i = atomicrmw sub ptr %_10.i.i.i.i.i6.i.i62.i.i, i64 1 release, align 8, !dbg !23978, !noalias !23981
  %210 = icmp eq i64 %_2.i.i.i.i.i7.i.i63.i.i, 1, !dbg !23982
  br i1 %210, label %bb2.i.i.i.i.i8.i.i65.i.i, label %bb13.i64.i.i, !dbg !23982

bb2.i.i.i.i.i8.i.i65.i.i:                         ; preds = %bb4.i35.i.i.i
  fence acquire, !dbg !23983
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i) #23
          to label %bb13.i64.i.i unwind label %cleanup.i.i.i, !dbg !23985, !noalias !23750

terminate.i.i71.i.i:                              ; preds = %bb2.i.i.i.i.i3.i.i70.i.i
  %211 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !23879, !noalias !23750
  unreachable, !dbg !23879

bb13.i64.i.i:                                     ; preds = %bb2.i.i.i.i.i8.i.i65.i.i, %bb4.i35.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i35.i.i), !dbg !23785, !noalias !23733
  %212 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 16, !dbg !23986
  %213 = load i64, ptr %212, align 8, !dbg !23988
  %214 = icmp eq i64 %213, -1, !dbg !23988
  br i1 %214, label %bb8.i.i, label %bb20.sink.split.i.i.i, !dbg !23988

bb20.sink.split.i.i.i:                            ; preds = %bb19.i.i.i, %bb13.i64.i.i
  %self.val.i.i56 = phi i64 [ %229, %bb19.i.i.i ], [ %213, %bb13.i64.i.i ], !dbg !23990
  call void @llvm.experimental.noalias.scope.decl(metadata !23998), !dbg !24001
  call void @llvm.experimental.noalias.scope.decl(metadata !24002), !dbg !24005
  %215 = icmp eq i64 %self.val.i.i56, 0
  br i1 %215, label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i59, label %bb2.i.i.i57, !dbg !24006

bb2.i.i.i57:                                      ; preds = %bb20.sink.split.i.i.i
  %216 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 24, !dbg !23990
  %self.val1.i.i58 = load ptr, ptr %216, align 8, !dbg !23990, !alias.scope !24009, !nonnull !37, !noundef !37
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %self.val1.i.i58, i64 noundef %self.val.i.i56, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !24010, !noalias !24009
  br label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i59, !dbg !24015

_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i59: ; preds = %bb2.i.i.i57, %bb20.sink.split.i.i.i
  %217 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 40, !dbg !24016
; invoke core::ptr::drop_glue::<arrow_schema::datatype::DataType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema8datatype8DataTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(24) %217)
          to label %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit63 unwind label %cleanup1.i60, !dbg !24016

cleanup1.i60:                                     ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i59
  %218 = landingpad { ptr, i32 }
          cleanup
  %219 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 64, !dbg !24016
; invoke <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %219)
          to label %common.resume unwind label %terminate.i61, !dbg !24017

terminate.i61:                                    ; preds = %cleanup1.i60
  %220 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !24016
  unreachable, !dbg !24016

_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit63: ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i59
  %221 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 64, !dbg !24016
; call <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  call void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %221), !dbg !24021
  br label %bb8.i.i, !dbg !24001

terminate.i47.i.i:                                ; preds = %bb2.i.i58.i.i.i, %bb25.i.i.i, %bb2.i.i.i72.i.i
  %222 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !24025, !noalias !23724
  unreachable, !dbg !24025

bb15.i57.i.i:                                     ; preds = %bb50.i56.i.i, %bb48.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !24026), !dbg !23785
  call void @llvm.experimental.noalias.scope.decl(metadata !24029), !dbg !24032
  call void @llvm.experimental.noalias.scope.decl(metadata !24034), !dbg !24037
  call void @llvm.experimental.noalias.scope.decl(metadata !24039), !dbg !24042
  call void @llvm.experimental.noalias.scope.decl(metadata !24044), !dbg !24047
  call void @llvm.experimental.noalias.scope.decl(metadata !24049), !dbg !24052
  %_10.i.i.i.i.i.i39.i.i.i = load ptr, ptr %columns.i35.i.i, align 8, !dbg !24054, !alias.scope !24058, !noalias !23733, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i.i40.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i.i39.i.i.i, i64 1 release, align 8, !dbg !24059, !noalias !24062
  %223 = icmp eq i64 %_2.i.i.i.i.i.i40.i.i.i, 1, !dbg !24063
  br i1 %223, label %bb2.i.i.i.i.i.i45.i.i.i, label %bb4.i41.i.i.i, !dbg !24063

bb2.i.i.i.i.i.i45.i.i.i:                          ; preds = %bb15.i57.i.i
  fence acquire, !dbg !24064
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %columns.i35.i.i) #23
          to label %bb4.i41.i.i.i unwind label %cleanup.i46.i.i.i, !dbg !24066, !noalias !23750

cleanup.i46.i.i.i:                                ; preds = %bb2.i.i.i.i.i.i45.i.i.i
  %224 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !24067), !dbg !24032
  call void @llvm.experimental.noalias.scope.decl(metadata !24070), !dbg !24073
  call void @llvm.experimental.noalias.scope.decl(metadata !24075), !dbg !24078
  call void @llvm.experimental.noalias.scope.decl(metadata !24080), !dbg !24083
  call void @llvm.experimental.noalias.scope.decl(metadata !24085), !dbg !24088
  %_10.i.i.i.i.i1.i47.i.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !24090, !alias.scope !24094, !noalias !23733, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i2.i48.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i1.i47.i.i.i, i64 1 release, align 8, !dbg !24095, !noalias !24098
  %225 = icmp eq i64 %_2.i.i.i.i.i2.i48.i.i.i, 1, !dbg !24099
  br i1 %225, label %bb2.i.i.i.i.i3.i50.i.i.i, label %bb27.i46.i.i, !dbg !24099

bb2.i.i.i.i.i3.i50.i.i.i:                         ; preds = %cleanup.i46.i.i.i
  fence acquire, !dbg !24100
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i) #23
          to label %bb27.i46.i.i unwind label %terminate.i51.i.i.i, !dbg !24102, !noalias !23750

bb4.i41.i.i.i:                                    ; preds = %bb2.i.i.i.i.i.i45.i.i.i, %bb15.i57.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !24103), !dbg !24032
  call void @llvm.experimental.noalias.scope.decl(metadata !24106), !dbg !24109
  call void @llvm.experimental.noalias.scope.decl(metadata !24111), !dbg !24114
  call void @llvm.experimental.noalias.scope.decl(metadata !24116), !dbg !24119
  call void @llvm.experimental.noalias.scope.decl(metadata !24121), !dbg !24124
  %_10.i.i.i.i.i6.i42.i.i.i = load ptr, ptr %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i, align 8, !dbg !24126, !alias.scope !24130, !noalias !23733, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i7.i43.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i6.i42.i.i.i, i64 1 release, align 8, !dbg !24131, !noalias !24134
  %226 = icmp eq i64 %_2.i.i.i.i.i7.i43.i.i.i, 1, !dbg !24135
  br i1 %226, label %bb2.i.i.i.i.i8.i44.i.i.i, label %bb19.i.i.i, !dbg !24135

bb2.i.i.i.i.i8.i44.i.i.i:                         ; preds = %bb4.i41.i.i.i
  fence acquire, !dbg !24136
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val2.sroa.5.sroa.4.0.val2.sroa.5.0.columns.sroa_idx.sroa_idx.i.i.i) #23
          to label %bb19.i.i.i unwind label %cleanup.i.i.i, !dbg !24138, !noalias !23750

terminate.i51.i.i.i:                              ; preds = %bb2.i.i.i.i.i3.i50.i.i.i
  %227 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !24032, !noalias !23750
  unreachable, !dbg !24032

bb25.i.i.i:                                       ; preds = %bb2.i.i.i72.i.i, %cleanup9.i.i.i, %cleanup8.i.i.i, %cleanup6.i.i.i, %cleanup5.i.i.i
  %.pn.i50.i.i = phi { ptr, i32 } [ %196, %cleanup8.i.i.i ], [ %189, %cleanup5.i.i.i ], [ %203, %cleanup9.i.i.i ], [ %191, %cleanup6.i.i.i ], [ %203, %bb2.i.i.i72.i.i ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<rofl_arrow::ArrowHost, i8>, rofl::tuple::Column<rofl_arrow::ArrowHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(64) %columns.i35.i.i) #21
          to label %bb27.i46.i.i unwind label %terminate.i47.i.i, !dbg !23785, !noalias !23750

bb19.i.i.i:                                       ; preds = %bb2.i.i.i.i.i8.i44.i.i.i, %bb4.i41.i.i.i, %bb16.i76.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i35.i.i), !dbg !23785, !noalias !23733
  %228 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 16, !dbg !24139
  %229 = load i64, ptr %228, align 8, !dbg !24141
  %230 = icmp eq i64 %229, -1, !dbg !24141
  br i1 %230, label %bb8.i.i, label %bb20.sink.split.i.i.i, !dbg !24141

bb27.i46.i.i:                                     ; preds = %bb25.i.i.i, %bb2.i.i.i.i.i3.i50.i.i.i, %cleanup.i46.i.i.i, %bb2.i.i.i.i.i3.i.i70.i.i, %cleanup.i.i67.i.i, %cleanup.i.i.i
  %.pn23.i.i.i = phi { ptr, i32 } [ %.pn.i50.i.i, %bb25.i.i.i ], [ %208, %cleanup.i.i67.i.i ], [ %186, %cleanup.i.i.i ], [ %208, %bb2.i.i.i.i.i3.i.i70.i.i ], [ %224, %bb2.i.i.i.i.i3.i50.i.i.i ], [ %224, %cleanup.i46.i.i.i ]
  %231 = getelementptr inbounds nuw i8, ptr %_16.i.i, i64 16, !dbg !24143
  %232 = load i64, ptr %231, align 8, !dbg !24145, !range !127, !alias.scope !24147, !noalias !23790, !noundef !37
  %233 = icmp eq i64 %232, -1, !dbg !24145
  br i1 %233, label %common.resume, label %bb2.i.i58.i.i.i, !dbg !24145

bb2.i.i58.i.i.i:                                  ; preds = %bb27.i46.i.i
; invoke core::ptr::drop_glue::<arrow_schema::field::Field>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(112) %231)
          to label %common.resume unwind label %terminate.i47.i.i, !dbg !24145, !noalias !23724

bb9.i.i:                                          ; preds = %bb48.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %columns.i.i), !dbg !24152, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %_24.sroa.15.i.i), !dbg !24153
  call void @llvm.experimental.noalias.scope.decl(metadata !24154), !dbg !24157
  %tolerant.i.i.i = icmp eq i64 %_15.i.i, 2, !dbg !24158
  %234 = getelementptr inbounds nuw i8, ptr %self, i64 136
  %_10.1.i.i.i = load i64, ptr %234, align 8, !dbg !24160, !alias.scope !24161, !noalias !24162
  %switch170 = icmp ult i64 %_10.1.i.i.i, 2
  %or.cond = select i1 %tolerant.i.i.i, i1 %switch170, i1 false, !dbg !24164
  br i1 %or.cond, label %panic3.i64.invoke, label %bb4.i89.i.i, !dbg !24164

bb4.i89.i.i:                                      ; preds = %bb9.i.i
  %_11.0.i.i.i.in = getelementptr inbounds nuw i8, ptr %self, i64 128
  %_11.0.i.i.i = load ptr, ptr %_11.0.i.i.i.in, align 8, !dbg !24160, !alias.scope !24161, !noalias !24162
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i), !dbg !24165, !noalias !24166
  %235 = getelementptr inbounds nuw i8, ptr %self, i64 168, !dbg !24167
  %_12.i.i.i = load ptr, ptr %235, align 8, !dbg !24167, !alias.scope !24161, !noalias !24162, !nonnull !37, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::decode
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6decodeCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_9.i.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) %_11.0.i.i.i, i64 noundef %_10.1.i.i.i, i1 noundef zeroext %tolerant.i.i.i, ptr noalias nofree noundef nonnull %_12.i.i.i)
          to label %.noexc99.i.i unwind label %bb35.thread160.i.i, !dbg !24165

.noexc99.i.i:                                     ; preds = %bb4.i89.i.i
  %236 = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 24, !dbg !24168
  %237 = load i8, ptr %236, align 8, !dbg !24168, !range !248, !noalias !24166, !noundef !37
  %238 = icmp eq i8 %237, 2, !dbg !24168
  br i1 %238, label %bb24.i.i, label %bb52.i.i, !dbg !24170

panic3.i64.invoke:                                ; preds = %bb9.i.i
; invoke core::panicking::panic_bounds_check
  invoke void @_RNvNtCslWxY2MhVcag_4core9panicking18panic_bounds_check(i64 noundef %_10.1.i.i.i, i64 noundef %_10.1.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1db612eff35dca40c08a0a84c0c7a91f.llvm.736736261725811314) #24
          to label %panic3.i64.cont unwind label %bb35.thread160.i.i, !dbg !24171

panic3.i64.cont:                                  ; preds = %panic3.i64.invoke
  unreachable

bb8.i.i:                                          ; preds = %bb19.i.i.i, %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit63, %bb13.i64.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_8.sroa.6.sroa.9.i.i.i), !dbg !24173
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i.i), !dbg !24174, !noalias !22667
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB2s_NCINvYBG_B2x_19visit_deferred_boolB3x_bKB2s_NCINvXs1_B1z_B1w_INtB2A_5RowFnBU_E8dispatchBG_Es4_0NCB4s_s5_0E0NCB3K_s_0B5f_ECskkDzpO6M0zw_10boundaries.exit, !dbg !23702

bb52.i.i:                                         ; preds = %.noexc99.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %columns.i.i, ptr noundef nonnull align 8 dereferenceable(24) %_9.i.i.i, i64 24, i1 false), !dbg !24175, !noalias !22667
  %_24.sroa.10.0._9.i.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 25, !dbg !24175
  %val3.sroa.5.0.columns.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 25, !dbg !24176
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %val3.sroa.5.0.columns.sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(7) %_24.sroa.10.0._9.i.sroa_idx.i.i, i64 7, i1 false), !dbg !24175, !noalias !22667
  %_24.sroa.11.0._9.i.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 32, !dbg !24175
  %_24.sroa.11.0.copyload.i.i = load i64, ptr %_24.sroa.11.0._9.i.sroa_idx.i.i, align 8, !dbg !24175, !noalias !24179
  %_24.sroa.14.0._9.i.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 40, !dbg !24175
  %_24.sroa.14.0.copyload.i.i = load i8, ptr %_24.sroa.14.0._9.i.sroa_idx.i.i, align 8, !dbg !24175, !noalias !24179
  %_24.sroa.15.0._9.i.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 41, !dbg !24175
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.15.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.15.0._9.i.sroa_idx.i.i, i64 23, i1 false), !dbg !24175, !noalias !24179
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i), !dbg !24180, !noalias !24166
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_23.sroa.6.sroa.9.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.15.i.i, i64 23, i1 false), !dbg !24181, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.sroa.15.i.i), !dbg !24184
  %val3.sroa.5.sroa.6.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 41, !dbg !24176
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %val3.sroa.5.sroa.6.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_23.sroa.6.sroa.9.i.i, i64 23, i1 false), !dbg !24153, !noalias !22667
  %val3.sroa.4.0.columns.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 24, !dbg !24176
  store i8 %237, ptr %val3.sroa.4.0.columns.sroa_idx.i.i, align 8, !dbg !24176, !noalias !22667
  %val3.sroa.5.sroa.4.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 32, !dbg !24176
  store i64 %_24.sroa.11.0.copyload.i.i, ptr %val3.sroa.5.sroa.4.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i, align 8, !dbg !24176, !noalias !22667
  %val3.sroa.5.sroa.5.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %columns.i.i, i64 40, !dbg !24176
  store i8 %_24.sroa.14.0.copyload.i.i, ptr %val3.sroa.5.sroa.5.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i, align 8, !dbg !24176, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %_33.i.i), !dbg !24185, !noalias !22667
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::constants
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE9constantsCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_33.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i.i)
          to label %bb12.i.i unwind label %cleanup8.i.i, !dbg !24185

bb24.i.i:                                         ; preds = %.noexc99.i.i
  %239 = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 32, !dbg !24187
  %_24.sroa.11.32.copyload125.i.i = load i64, ptr %239, align 8, !dbg !24187, !noalias !24179
  %_24.sroa.14.32..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 40, !dbg !24187
  %_24.sroa.14.32.copyload126.i.i = load i8, ptr %_24.sroa.14.32..sroa_idx.i.i, align 8, !dbg !24187, !noalias !24179
  %_24.sroa.15.32..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_9.i.i.i, i64 41, !dbg !24187
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.15.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.15.32..sroa_idx.i.i, i64 23, i1 false), !dbg !24187, !noalias !24179
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i), !dbg !24180, !noalias !24166
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_23.sroa.6.sroa.9.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_24.sroa.15.i.i, i64 23, i1 false), !dbg !24188, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.sroa.15.i.i), !dbg !24184
  %_82.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 17, !dbg !24189
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(23) %_82.sroa.5.0..sroa_idx.i.i, ptr noundef nonnull align 1 dereferenceable(23) %_23.sroa.6.sroa.9.i.i, i64 23, i1 false), !dbg !24184, !noalias !22663
  %240 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !24195
  store i64 %_24.sroa.11.32.copyload125.i.i, ptr %240, align 8, !dbg !24195, !alias.scope !22664, !noalias !22663
  %_88.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !24195
  store i8 %_24.sroa.14.32.copyload126.i.i, ptr %_88.sroa.4.0..sroa_idx.i.i, align 8, !dbg !24195, !alias.scope !22664, !noalias !22663
  store i64 1, ptr %_0, align 8, !dbg !24196, !alias.scope !22664, !noalias !22663
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i), !dbg !24198, !noalias !22667
  br label %bb39.critedge.i.i, !dbg !24198

cleanup8.i.i:                                     ; preds = %bb52.i.i
  %241 = landingpad { ptr, i32 }
          cleanup
  br label %bb32.i.i, !dbg !24199

bb12.i.i:                                         ; preds = %bb52.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_33.i.i), !dbg !24199, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %source.i.i), !dbg !24200, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %_36.sroa.5.i.i), !dbg !24202
  call void @llvm.lifetime.start.p0(ptr nonnull %_37.i.i), !dbg !24202, !noalias !22667
  %242 = getelementptr inbounds nuw i8, ptr %self, i64 176, !dbg !24203
  %_39.i.i = load i64, ptr %242, align 8, !dbg !24203, !alias.scope !22663, !noalias !22664, !noundef !37
; invoke <(i64, i64) as rofl::tuple::InputTuple<rofl_arrow::ArrowHost>>::source
  invoke void @_RNvXsa_NtCshZi9mpuUhIi_4rofl5tupleTxxEINtB5_10InputTupleNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostE6sourceCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([64 x i8]) align 8 captures(none) dereferenceable(64) %_37.i.i, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(64) %columns.i.i, i64 noundef %_39.i.i)
          to label %bb13.i.i unwind label %cleanup9.i.i, !dbg !24202

cleanup9.i.i:                                     ; preds = %bb12.i.i
  %243 = landingpad { ptr, i32 }
          cleanup
  br label %bb32.i.i

bb13.i.i:                                         ; preds = %bb12.i.i
  %_90.i.i = load i64, ptr %_37.i.i, align 8, !dbg !24204, !range !4730, !noalias !22667, !noundef !37
  %244 = trunc nuw i64 %_90.i.i to i1, !dbg !24207
  %245 = getelementptr inbounds nuw i8, ptr %_37.i.i, i64 8, !dbg !24208
  br i1 %244, label %bb54.i.i, label %bb14.i.i, !dbg !24207

bb54.i.i:                                         ; preds = %bb13.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %_36.sroa.5.i.i, ptr noundef nonnull align 8 dereferenceable(32) %245, i64 32, i1 false), !dbg !24209, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %_37.i.i), !dbg !24210, !noalias !22667
  %246 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !24211
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %246, ptr noundef nonnull align 8 dereferenceable(32) %_36.sroa.5.i.i, i64 32, i1 false), !dbg !24210, !noalias !22663
  store i64 1, ptr %_0, align 8, !dbg !24211, !alias.scope !22664, !noalias !22663
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.sroa.5.i.i), !dbg !24217
  br label %bb22.i.i, !dbg !24218

cleanup10.i.i:                                    ; preds = %bb2.i.i108.i.i, %bb14.i.i
  %247 = landingpad { ptr, i32 }
          cleanup
  br label %bb32.i.i

bb14.i.i:                                         ; preds = %bb13.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %_36.sroa.5.i.i, ptr noundef nonnull align 8 dereferenceable(56) %245, i64 56, i1 false), !dbg !24220, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %_37.i.i), !dbg !24210, !noalias !22667
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %source.i.i, ptr noundef nonnull align 8 dereferenceable(56) %_36.sroa.5.i.i, i64 56, i1 false), !dbg !24202, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %_36.sroa.5.i.i), !dbg !24217
  call void @llvm.lifetime.start.p0(ptr nonnull %failure.i.i), !dbg !24221, !noalias !22667
  store i8 0, ptr %failure.i.i, align 1, !dbg !24223, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %collect.i.i), !dbg !24224, !noalias !22667
  store ptr %source.i.i, ptr %collect.i.i, align 8, !dbg !24226, !noalias !22667
  %248 = getelementptr inbounds nuw i8, ptr %collect.i.i, i64 8, !dbg !24226
  store ptr %prepared.i.i.i, ptr %248, align 8, !dbg !24226, !noalias !22667
  %249 = getelementptr inbounds nuw i8, ptr %collect.i.i, i64 16, !dbg !24226
  store ptr %prepared.i.i.i, ptr %249, align 8, !dbg !24226, !noalias !22667
  %250 = getelementptr inbounds nuw i8, ptr %collect.i.i, i64 24, !dbg !24226
  store ptr %failure.i.i, ptr %250, align 8, !dbg !24226, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %values.i.i), !dbg !24227, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %_50.i.i), !dbg !24229, !noalias !22667
  %_51.i.i = load i64, ptr %242, align 8, !dbg !24230, !alias.scope !22663, !noalias !22664, !noundef !37
  %_62.i.i = load ptr, ptr %235, align 8, !dbg !24231, !alias.scope !22663, !noalias !22664, !nonnull !37, !noundef !37
  invoke void @_RINvXs2_NtCs7Kazvvc7DnG_10rofl_arrow6outputNtB8_9ArrowHostNtNtCshZi9mpuUhIi_4rofl6output13BooleanOutput12collect_boolKb1_NCINvMNtNtBY_7execute11packed_boolINtB23_7ExecuteBF_INtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKB1S_EE16deferred_booleanTxxEubKB1S_NCINvYB2t_INtNtBY_7visitor10RowVisitorBF_E19visit_deferred_boolB45_bKB1S_NCINvXs1_B2O_B2L_INtB4t_5RowFnBF_E8dispatchB2t_Es4_0NCB5t_s5_0E0NCB4i_s_0B6h_Es_0ECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_50.i.i, i64 noundef %_51.i.i, ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(32) %collect.i.i, ptr noalias nofree noundef nonnull %_62.i.i)
          to label %bb15.i.i unwind label %cleanup10.i.i, !dbg !24229

bb15.i.i:                                         ; preds = %bb14.i.i
  %251 = load i64, ptr %_50.i.i, align 8, !dbg !24232, !range !53, !noalias !22667, !noundef !37
  %.not24.i.i = icmp eq i64 %251, -1, !dbg !24232
  %252 = getelementptr inbounds nuw i8, ptr %_50.i.i, i64 8, !dbg !24235
  %_98.0.i.i = load ptr, ptr %252, align 8, !dbg !24235, !noalias !22667
  %253 = getelementptr inbounds nuw i8, ptr %_50.i.i, i64 16, !dbg !24235
  %_98.1.i.i = load ptr, ptr %253, align 8, !dbg !24235, !noalias !22667
  br i1 %.not24.i.i, label %bb57.i.i, label %bb56.i.i, !dbg !24236

bb56.i.i:                                         ; preds = %bb15.i.i
  %_99.sroa.6.0._50.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_50.i.i, i64 24, !dbg !24237
  %_99.sroa.6.0.copyload.i.i = load i64, ptr %_99.sroa.6.0._50.sroa_idx.i.i, align 8, !dbg !24237, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %_50.i.i), !dbg !24238, !noalias !22667
  %254 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !24239
  store i64 %251, ptr %254, align 8, !dbg !24239, !alias.scope !22664, !noalias !22663
  %_102.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !24239
  store ptr %_98.0.i.i, ptr %_102.sroa.4.0..sroa_idx.i.i, align 8, !dbg !24239, !alias.scope !22664, !noalias !22663
  %_102.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !24239
  store ptr %_98.1.i.i, ptr %_102.sroa.5.0..sroa_idx.i.i, align 8, !dbg !24239, !alias.scope !22664, !noalias !22663
  %_102.sroa.6.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !24239
  store i64 %_99.sroa.6.0.copyload.i.i, ptr %_102.sroa.6.0..sroa_idx.i.i, align 8, !dbg !24239, !alias.scope !22664, !noalias !22663
  store i64 1, ptr %_0, align 8, !dbg !24239, !alias.scope !22664, !noalias !22663
  br label %bb21.i.i, !dbg !24245

bb57.i.i:                                         ; preds = %bb15.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_50.i.i), !dbg !24238, !noalias !22667
  store ptr %_98.0.i.i, ptr %values.i.i, align 8, !dbg !24247, !noalias !22667
  %255 = getelementptr inbounds nuw i8, ptr %values.i.i, i64 8, !dbg !24247
  store ptr %_98.1.i.i, ptr %255, align 8, !dbg !24247, !noalias !22667
  call void @llvm.lifetime.start.p0(ptr nonnull %_55.i.i), !dbg !24250, !noalias !22667
  %256 = load i8, ptr %failure.i.i, align 1, !dbg !24252, !range !168, !noalias !22667, !noundef !37
  %_58.i.i = trunc nuw i8 %256 to i1, !dbg !24252
  br i1 %_58.i.i, label %bb1.i102.i.i, label %bb59.i.i, !dbg !24253, !prof !11822

bb1.i102.i.i:                                     ; preds = %bb57.i.i
; invoke rofl_examples::functions::row_error::<rofl_arrow::ArrowHost>
  invoke void @_RINvNtCs6mBffczUiYQ_13rofl_examples9functions9row_errorNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull sret([32 x i8]) align 8 captures(address) dereferenceable(32) %_55.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_9af6f4b9ec8797d4b950ec3330fd4cbb, i64 noundef 32) #23
          to label %bb16.i.i unwind label %cleanup11.i.i, !dbg !24255

cleanup11.i.i:                                    ; preds = %bb1.i102.i.i
  %257 = landingpad { ptr, i32 }
          cleanup
  %_2.i.i.i.i = atomicrmw sub ptr %_98.0.i.i, i64 1 release, align 8, !dbg !24256, !noalias !24261
  %258 = icmp eq i64 %_2.i.i.i.i, 1, !dbg !24266
  br i1 %258, label %bb2.i.i.i.i, label %bb32.i.i, !dbg !24266

bb2.i.i.i.i:                                      ; preds = %cleanup11.i.i
  fence acquire, !dbg !24267
; invoke <alloc::sync::Arc<dyn arrow_array::array::Array>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcDNtNtCs6AFQLBbsvVR_11arrow_array5array5ArrayEL_E9drop_slowBL_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i) #23
          to label %bb32.i.i unwind label %terminate.i.i, !dbg !24269

bb16.i.i:                                         ; preds = %bb1.i102.i.i
  %.pr.i.i = load i64, ptr %_55.i.i, align 8, !dbg !24270, !noalias !22667
  %.not25.i.i = icmp eq i64 %.pr.i.i, -1, !dbg !24270
  br i1 %.not25.i.i, label %bb59.i.i, label %bb58.i.i, !dbg !24272

bb58.i.i:                                         ; preds = %bb16.i.i
  %259 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !24273
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %259, ptr noundef nonnull align 8 dereferenceable(32) %_55.i.i, i64 32, i1 false), !dbg !24279, !noalias !22663
  call void @llvm.lifetime.end.p0(ptr nonnull %_55.i.i), !dbg !24280, !noalias !22667
  store i64 1, ptr %_0, align 8, !dbg !24273, !alias.scope !22664, !noalias !22663
  %_2.i.i107.i.i = atomicrmw sub ptr %_98.0.i.i, i64 1 release, align 8, !dbg !24281, !noalias !24286
  %260 = icmp eq i64 %_2.i.i107.i.i, 1, !dbg !24291
  br i1 %260, label %bb2.i.i108.i.i, label %bb21.i.i, !dbg !24291

bb2.i.i108.i.i:                                   ; preds = %bb58.i.i
  fence acquire, !dbg !24292
; invoke <alloc::sync::Arc<dyn arrow_array::array::Array>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcDNtNtCs6AFQLBbsvVR_11arrow_array5array5ArrayEL_E9drop_slowBL_(ptr noalias nofree noundef nonnull align 8 dereferenceable(16) %values.i.i) #23
          to label %bb21.i.i unwind label %cleanup10.i.i, !dbg !24294

bb59.i.i:                                         ; preds = %bb16.i.i, %bb57.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_55.i.i), !dbg !24280, !noalias !22667
  %_60.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !24295
  store ptr %_98.0.i.i, ptr %_60.sroa.4.0..sroa_idx.i.i, align 8, !dbg !24295, !alias.scope !22664, !noalias !22663
  %_60.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !24295
  store ptr %_98.1.i.i, ptr %_60.sroa.5.0..sroa_idx.i.i, align 8, !dbg !24295, !alias.scope !22664, !noalias !22663
  store <2 x i64> <i64 0, i64 -9223372036854775788>, ptr %_0, align 8, !dbg !24295, !alias.scope !22664, !noalias !22663
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i), !dbg !24296, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %collect.i.i), !dbg !24297, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %failure.i.i), !dbg !24298, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i), !dbg !24299, !noalias !22667
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<rofl_arrow::ArrowHost, i8>, rofl::tuple::Column<rofl_arrow::ArrowHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(64) %columns.i.i)
          to label %bb19.i.i unwind label %bb35.thread160.i.i, !dbg !24198

bb19.i.i:                                         ; preds = %bb59.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i), !dbg !24198, !noalias !22667
  %261 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !24300
  %262 = load i64, ptr %261, align 8, !dbg !24302, !range !127, !alias.scope !24304, !noalias !22664, !noundef !37
  %263 = icmp eq i64 %262, -1, !dbg !24302
  br i1 %263, label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB2s_NCINvYBG_B2x_19visit_deferred_boolB3x_bKB2s_NCINvXs1_B1z_B1w_INtB2A_5RowFnBU_E8dispatchBG_Es4_0NCB4s_s5_0E0NCB3K_s_0B5f_ECskkDzpO6M0zw_10boundaries.exit, label %bb2.i.i111.i.i, !dbg !24302

bb2.i.i111.i.i:                                   ; preds = %bb19.i.i
; call core::ptr::drop_glue::<arrow_schema::field::Field>
  call fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(112) %261), !dbg !24302
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB2s_NCINvYBG_B2x_19visit_deferred_boolB3x_bKB2s_NCINvXs1_B1z_B1w_INtB2A_5RowFnBU_E8dispatchBG_Es4_0NCB4s_s5_0E0NCB3K_s_0B5f_ECskkDzpO6M0zw_10boundaries.exit, !dbg !24302

bb21.i.i:                                         ; preds = %bb2.i.i108.i.i, %bb58.i.i, %bb56.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %values.i.i), !dbg !24296, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %collect.i.i), !dbg !24297, !noalias !22667
  call void @llvm.lifetime.end.p0(ptr nonnull %failure.i.i), !dbg !24298, !noalias !22667
  br label %bb22.i.i, !dbg !24299

terminate.i.i:                                    ; preds = %bb2.i.i122.i.i, %bb32.i.i, %bb2.i.i.i.i
  %264 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !24309
  unreachable, !dbg !24309

bb22.i.i:                                         ; preds = %bb21.i.i, %bb54.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %source.i.i), !dbg !24299, !noalias !22667
  call void @llvm.experimental.noalias.scope.decl(metadata !24310), !dbg !24198
  call void @llvm.experimental.noalias.scope.decl(metadata !24313), !dbg !24316
  call void @llvm.experimental.noalias.scope.decl(metadata !24318), !dbg !24321
  call void @llvm.experimental.noalias.scope.decl(metadata !24323), !dbg !24326
  call void @llvm.experimental.noalias.scope.decl(metadata !24328), !dbg !24331
  call void @llvm.experimental.noalias.scope.decl(metadata !24333), !dbg !24336
  %_10.i.i.i.i.i.i.i.i = load ptr, ptr %columns.i.i, align 8, !dbg !24338, !alias.scope !24342, !noalias !22667, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i.i.i.i, i64 1 release, align 8, !dbg !24343, !noalias !24342
  %265 = icmp eq i64 %_2.i.i.i.i.i.i.i.i, 1, !dbg !24346
  br i1 %265, label %bb2.i.i.i.i.i.i.i.i, label %bb4.i112.i.i, !dbg !24346

bb2.i.i.i.i.i.i.i.i:                              ; preds = %bb22.i.i
  fence acquire, !dbg !24347
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(64) %columns.i.i) #23
          to label %bb4.i112.i.i unwind label %cleanup.i113.i.i, !dbg !24349

cleanup.i113.i.i:                                 ; preds = %bb2.i.i.i.i.i.i.i.i
  %266 = landingpad { ptr, i32 }
          cleanup
  call void @llvm.experimental.noalias.scope.decl(metadata !24350), !dbg !24316
  call void @llvm.experimental.noalias.scope.decl(metadata !24353), !dbg !24356
  call void @llvm.experimental.noalias.scope.decl(metadata !24358), !dbg !24361
  call void @llvm.experimental.noalias.scope.decl(metadata !24363), !dbg !24366
  call void @llvm.experimental.noalias.scope.decl(metadata !24368), !dbg !24371
  %_10.i.i.i.i.i1.i.i.i = load ptr, ptr %val3.sroa.5.sroa.4.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i, align 8, !dbg !24373, !alias.scope !24377, !noalias !22667, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i2.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i1.i.i.i, i64 1 release, align 8, !dbg !24378, !noalias !24381
  %267 = icmp eq i64 %_2.i.i.i.i.i2.i.i.i, 1, !dbg !24382
  br i1 %267, label %bb2.i.i.i.i.i3.i.i.i, label %bb46.i.i, !dbg !24382

bb2.i.i.i.i.i3.i.i.i:                             ; preds = %cleanup.i113.i.i
  fence acquire, !dbg !24383
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val3.sroa.5.sroa.4.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i) #23
          to label %bb46.i.i unwind label %terminate.i115.i.i, !dbg !24385

bb4.i112.i.i:                                     ; preds = %bb2.i.i.i.i.i.i.i.i, %bb22.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !24386), !dbg !24316
  call void @llvm.experimental.noalias.scope.decl(metadata !24389), !dbg !24392
  call void @llvm.experimental.noalias.scope.decl(metadata !24394), !dbg !24397
  call void @llvm.experimental.noalias.scope.decl(metadata !24399), !dbg !24402
  call void @llvm.experimental.noalias.scope.decl(metadata !24404), !dbg !24407
  %_10.i.i.i.i.i6.i.i.i = load ptr, ptr %val3.sroa.5.sroa.4.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i, align 8, !dbg !24409, !alias.scope !24413, !noalias !22667, !nonnull !37, !noundef !37
  %_2.i.i.i.i.i7.i.i.i = atomicrmw sub ptr %_10.i.i.i.i.i6.i.i.i, i64 1 release, align 8, !dbg !24414, !noalias !24417
  %268 = icmp eq i64 %_2.i.i.i.i.i7.i.i.i, 1, !dbg !24418
  br i1 %268, label %bb2.i.i.i.i.i8.i.i.i, label %bb25.i.i, !dbg !24418

bb2.i.i.i.i.i8.i.i.i:                             ; preds = %bb4.i112.i.i
  fence acquire, !dbg !24419
; invoke <alloc::sync::Arc<arrow_buffer::bytes::Bytes>>::drop_slow
  invoke void @_RNvMsn_NtCs6KVRSXc8uZF_5alloc4syncINtB5_3ArcNtNtCs6stDIWloaLs_12arrow_buffer5bytes5BytesE9drop_slowBK_(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %val3.sroa.5.sroa.4.0.val3.sroa.5.0.columns.sroa_idx.sroa_idx.i.i) #23
          to label %bb25.i.i unwind label %bb35.thread160.i.i, !dbg !24421

terminate.i115.i.i:                               ; preds = %bb2.i.i.i.i.i3.i.i.i
  %269 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !24316
  unreachable, !dbg !24316

bb25.i.i:                                         ; preds = %bb2.i.i.i.i.i8.i.i.i, %bb4.i112.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %columns.i.i), !dbg !24198, !noalias !22667
  br label %bb39.critedge.i.i, !dbg !24198

bb32.i.i:                                         ; preds = %bb2.i.i.i.i, %cleanup11.i.i, %cleanup10.i.i, %cleanup9.i.i, %cleanup8.i.i
  %.pn.i.i = phi { ptr, i32 } [ %247, %cleanup10.i.i ], [ %241, %cleanup8.i.i ], [ %243, %cleanup9.i.i ], [ %257, %bb2.i.i.i.i ], [ %257, %cleanup11.i.i ]
; invoke core::ptr::drop_glue::<(rofl::tuple::Column<rofl_arrow::ArrowHost, i8>, rofl::tuple::Column<rofl_arrow::ArrowHost, i8>)>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueTINtNtCshZi9mpuUhIi_4rofl5tuple6ColumnNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostaEBC_EECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(64) %columns.i.i) #21
          to label %bb46.i.i unwind label %terminate.i.i, !dbg !24198

bb39.critedge.i.i:                                ; preds = %bb25.i.i, %bb24.i.i, %bb47.i.i
  %270 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !24422
  %271 = load i64, ptr %270, align 8, !dbg !24424, !range !127, !alias.scope !24426, !noalias !22664, !noundef !37
  %272 = icmp eq i64 %271, -1, !dbg !24424
  br i1 %272, label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB2s_NCINvYBG_B2x_19visit_deferred_boolB3x_bKB2s_NCINvXs1_B1z_B1w_INtB2A_5RowFnBU_E8dispatchBG_Es4_0NCB4s_s5_0E0NCB3K_s_0B5f_ECskkDzpO6M0zw_10boundaries.exit, label %bb2.i.i120.i.i, !dbg !24424

bb2.i.i120.i.i:                                   ; preds = %bb39.critedge.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !24431), !dbg !24424
  call void @llvm.experimental.noalias.scope.decl(metadata !24434), !dbg !24437
  %273 = icmp eq i64 %271, 0
  br i1 %273, label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i72, label %bb2.i.i.i70, !dbg !24442

bb2.i.i.i70:                                      ; preds = %bb2.i.i120.i.i
  %274 = getelementptr inbounds nuw i8, ptr %self, i64 24, !dbg !24446
  %self.val1.i.i71 = load ptr, ptr %274, align 8, !dbg !24446, !alias.scope !24447, !nonnull !37, !noundef !37
; call __rustc::__rust_dealloc
  call void @_RNvCs6rREvFdRhLb_7___rustc14___rust_dealloc(ptr noundef nonnull %self.val1.i.i71, i64 noundef %271, i64 noundef range(i64 1, -9223372036854775807) 1) #19, !dbg !24448, !noalias !24447
  br label %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i72, !dbg !24453

_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i72: ; preds = %bb2.i.i.i70, %bb2.i.i120.i.i
  %275 = getelementptr inbounds nuw i8, ptr %self, i64 40, !dbg !24454
; invoke core::ptr::drop_glue::<arrow_schema::datatype::DataType>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema8datatype8DataTypeECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef align 8 dereferenceable(24) %275)
          to label %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit76 unwind label %cleanup1.i73, !dbg !24454

cleanup1.i73:                                     ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i72
  %276 = landingpad { ptr, i32 }
          cleanup
  %277 = getelementptr inbounds nuw i8, ptr %self, i64 64, !dbg !24454
; invoke <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %277)
          to label %common.resume unwind label %terminate.i74, !dbg !24455

terminate.i74:                                    ; preds = %cleanup1.i73
  %278 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCslWxY2MhVcag_4core9panicking16panic_in_cleanup() #20, !dbg !24454
  unreachable, !dbg !24454

_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit76: ; preds = %_RNvXs1_NtCs6KVRSXc8uZF_5alloc7raw_vecINtB5_6RawVechENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries.exit.i72
  %279 = getelementptr inbounds nuw i8, ptr %self, i64 64, !dbg !24454
; call <hashbrown::raw::RawTable<(alloc::string::String, alloc::string::String)> as core::ops::drop::Drop>::drop
  call void @_RNvXsg_NtCs7oNAfGD06J0_9hashbrown3rawINtB5_8RawTableTNtNtCs6KVRSXc8uZF_5alloc6string6StringBP_EENtNtNtCslWxY2MhVcag_4core3ops4drop4Drop4dropCskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %279), !dbg !24459
  br label %_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB2s_NCINvYBG_B2x_19visit_deferred_boolB3x_bKB2s_NCINvXs1_B1z_B1w_INtB2A_5RowFnBU_E8dispatchBG_Es4_0NCB4s_s5_0E0NCB3K_s_0B5f_ECskkDzpO6M0zw_10boundaries.exit, !dbg !24424

bb35.thread160.i.i:                               ; preds = %panic3.i64.invoke, %bb2.i.i.i.i.i8.i.i.i, %bb59.i.i, %bb4.i89.i.i, %bb4.i.i, %bb1.i.i
  %lpad.thr_comm.i.i = landingpad { ptr, i32 }
          cleanup
  br label %bb46.i.i, !dbg !24198

bb46.i.i:                                         ; preds = %bb35.thread160.i.i, %bb32.i.i, %bb2.i.i.i.i.i3.i.i.i, %cleanup.i113.i.i
  %.pn27158.i.i = phi { ptr, i32 } [ %lpad.thr_comm.i.i, %bb35.thread160.i.i ], [ %266, %bb2.i.i.i.i.i3.i.i.i ], [ %266, %cleanup.i113.i.i ], [ %.pn.i.i, %bb32.i.i ]
  %280 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !24463
  %281 = load i64, ptr %280, align 8, !dbg !24465, !range !127, !alias.scope !24467, !noalias !22664, !noundef !37
  %282 = icmp eq i64 %281, -1, !dbg !24465
  br i1 %282, label %common.resume, label %bb2.i.i122.i.i, !dbg !24465

bb2.i.i122.i.i:                                   ; preds = %bb46.i.i
; invoke core::ptr::drop_glue::<arrow_schema::field::Field>
  invoke fastcc void @_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries(ptr noalias nofree noundef nonnull align 8 dereferenceable(112) %280)
          to label %common.resume unwind label %terminate.i.i, !dbg !24465

_RINvXNtNtCshZi9mpuUhIi_4rofl7execute7visitorINtB5_7ExecuteNtCs7Kazvvc7DnG_10rofl_arrow9ArrowHostINtNtCs6mBffczUiYQ_13rofl_examples9functions11PositiveSumKb1_EEINtNtB7_7visitor10RowVisitorBU_E28visit_prepared_deferred_boolTxxEubKB2s_NCINvYBG_B2x_19visit_deferred_boolB3x_bKB2s_NCINvXs1_B1z_B1w_INtB2A_5RowFnBU_E8dispatchBG_Es4_0NCB4s_s5_0E0NCB3K_s_0B5f_ECskkDzpO6M0zw_10boundaries.exit: ; preds = %_RINvNtCslWxY2MhVcag_4core3ptr9drop_glueNtNtCsahM43VdRvdp_12arrow_schema5field5FieldECskkDzpO6M0zw_10boundaries.exit76, %bb39.critedge.i.i, %bb2.i.i111.i.i, %bb19.i.i, %bb8.i.i, %bb3.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_23.sroa.6.sroa.9.i.i), !dbg !24472
  ret void, !dbg !24473
}