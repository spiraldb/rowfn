// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Experimental strict row functions with statically dispatched host bindings.
//!
//! Functions select typed visitors. Hosts own decoding, validity, allocation, and publication.
//! Null inputs imply null output, and valid inputs cannot produce null. Callbacks must not panic
//! or have side effects other than writing their supplied row. Constants and retries can change
//! their evaluation count. This crate has no registration, serialization, or binary ABI contract.

#![deny(missing_docs)]

mod host;
pub use host::*;

mod input;
pub use input::*;

mod output;
pub use output::*;

mod tuple;
pub use tuple::InputTuple;

pub mod sink;

mod visitor;
pub use visitor::RowFn;
pub use visitor::RowVisitor;

mod plan;
pub use plan::Plan;
pub use plan::plan;

mod execute;
pub use execute::execute;

pub use rofl_kernels as kernels;
