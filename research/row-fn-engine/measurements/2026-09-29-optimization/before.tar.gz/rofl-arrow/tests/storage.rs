// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Arrow-only ownership tests do not add any Vortex dependency to this package.

use arrow_array::Int64Array;
use arrow_schema::ArrowError;
use rofl::{OutputBinding, OutputBuffer};
use rofl::sink::{OutputSink, UninitElementSink};
use rofl_arrow::ArrowHost;

#[test]
fn primitive_publication_preserves_allocation_and_initialized_prefix() -> Result<(), ArrowError> {
    let mut buffer = <ArrowHost as OutputBinding<i64>>::allocate(4, &mut ())?;
    let pointer = buffer.slots().as_ptr().cast::<i64>();
    buffer.slots()[0].write(10);
    buffer.slots()[1].write(20);

    let mut moved = buffer;
    assert_eq!(moved.slots().as_ptr().cast::<i64>(), pointer);
    // SAFETY: only the first two slots are published, and both retain their initialized values.
    let result = unsafe { moved.finish(2) };
    let array = result.as_any().downcast_ref::<Int64Array>().unwrap();
    assert_eq!(array.values().as_ptr(), pointer);
    assert_eq!(array.values().as_ref(), &[10, 20]);
    Ok(())
}

#[test]
fn partially_initialized_scalar_sink_can_be_abandoned() -> Result<(), ArrowError> {
    let mut sink = UninitElementSink::<ArrowHost, i64>::allocate(4, &(), &mut ())?;
    {
        let mut rows = sink.rows();
        // SAFETY: row zero is within the retained four-row view.
        let row = unsafe { UninitElementSink::<ArrowHost, i64>::row(&mut rows, 0) };
        row.write(10);
    }
    drop(sink);
    Ok(())
}
