<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- SPDX-FileCopyrightText: Copyright the Vortex contributors -->

# Shared rofl functions and evidence fixtures

The function definitions in `src/functions.rs` share their dispatch rules and row operations across
Vortex and Arrow. They import framework capabilities and local semantic traits. Native mappings live
in separate modules, including downstream timestamp bindings that require no changes to `rofl`.

| Function | Paths exercised |
| --- | --- |
| `Add<false>` and `Add<true>`. | Eight integer widths, owned output, constants, and deferred failure. |
| `Divide`. | Immediate errors and exact scalar-slot initialization. |
| `PositiveSum<MULTIVERSIONED>`. | Packed Boolean output, checked addition, and nullable dense retry. |
| `Trim`. | Borrowed UTF-8 input and output-owned string storage. |
| `Scale`. | Float32/Float64 lists, runtime width, prepared constants, and row initialization. |
| `AdjustTicks`. | An external timestamp domain with checked ticks and retained native metadata. |
| `Seven` and `Not`. | Nullary registration and sliced Boolean inputs. |

`tests/arithmetic.rs` registers and deserializes `SevenPlugin` through Vortex's existing registry.
Its external persistence wrapper delegates to `VortexRowFn<Seven>`. No built-in case is added.
Whole-batch functions can still use `ScalarFnVTable` directly.

## Tests

The fixtures cover values, nulls, observable errors, metadata, explicit scalars, empty batches,
dictionary nulls, unused dictionary entries, string ownership, list shape, custom bindings, and
filtered decoding. Vortex's adapter tests cover its execution allocator and primitive payload reuse.
The framework and Arrow rustdoc examples contain compile-fail lifetime and token cases.

These tests have not run. Run only the relevant package tests or doctests when verification is
requested. The fixtures are outside `rofl` and `rofl-arrow` so their Vortex dependency cannot leak
into either independent package.

## Benchmarks

`benches/boundaries.rs` supplies the following comparisons in one benchmark binary:

- `direct_typed_collection` and `shared_collection` use the same Arrow output allocation.
- `shared_executor` adds typed dispatch, decoding, validity, and publication.
- `arrow_invocation` adds the Arrow batch boundary and supports an explicit scalar operand.
- `arrow_native_wrapping_add` uses Arrow's wrapping addition under matching integer semantics.
- `vortex_add` compares the retained and extracted Vortex executors on identical batches.
- `nullable_bool` compares nullable dense acceptance and null-only failure followed by retry.

The Boolean comparison includes both Vortex executors, the Arrow adapter, and a valid-only Arrow
reference loop. The reference loop reports errors only on valid rows. It is a semantic baseline,
not a claim that Arrow provides an equivalent fused checked predicate kernel.

The workspace bench profile retains `codegen-units = 16` and `lto = false`. Use one compiler, target,
feature set, allocator, and profile for a comparison. Preserve the compiler version, target triple,
flags, full command, source diff, raw results, and generated-code evidence with each measurement.
Do not compare this extraction against historical research timings.

For an authorized run, the focused benchmark command is:

```sh
cargo bench -p rofl-examples --bench boundaries
```

No benchmark or compiler experiment has run for this implementation. The measurements must establish
whether module boundaries preserve constant specialization, loop unswitching, vectorization, and
Boolean retry behavior before any performance equivalence claim.
