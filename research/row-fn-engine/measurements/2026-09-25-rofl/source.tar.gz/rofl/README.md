<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- SPDX-FileCopyrightText: Copyright the Vortex contributors -->

# rofl

`rofl` is an experimental strict row-function framework. A function selects typed visitors once per
batch. The same dispatch rules and row operations can then execute over different hosts, while each
host retains its native types, input owners, allocator, and output construction.

This package is unpublished. Its source, adapters, tests, and benchmarks are implemented in this
workspace, but compilation and execution have not been verified. See the
[implementation record](../research/row-fn-engine/implementation.md) for the evidence boundary.

## Function authors

Implement `RowFn<H>` over the capabilities that the function requires. Use `dispatch` to select its
row kinds and output visitor from options and native input metadata. The framework validates the
selected input bindings before decoding. Keep cross-argument rules in this shared dispatch method.
A host-specific capability can classify native metadata without duplicating the function binder.

```rust
use rofl::{Host, HostResult, InputBinding, OutputBinding, RowFn, RowVisitor};

#[derive(Clone)]
struct WrappingAdd;

impl<H> RowFn<H> for WrappingAdd
where
    H: Host + InputBinding<i64> + OutputBinding<i64>,
{
    type Options = ();
    const ARG_NAMES: &'static [&'static str] = &["lhs", "rhs"];
    const INFALLIBLE: bool = true;

    fn dispatch<V: RowVisitor<H>>(
        &self,
        _: &(),
        _: &[H::NativeType],
        visitor: V,
    ) -> HostResult<H, V::VisitResult> {
        visitor.visit::<(i64, i64), i64>(|(lhs, rhs)| lhs.wrapping_add(rhs))
    }
}
```

The [proof functions](../rofl-examples/src/functions.rs) extend this pattern to runtime dispatch over
eight integer widths, immediate division errors, deferred Boolean failures, borrowed strings,
runtime-width lists, and timestamps. Their host mappings classify native types. Their shared
`dispatch` methods select visitors and define row operations for both Vortex and Arrow.

The contract is strict:

- Null inputs imply a null result. Valid inputs cannot produce null.
- Callbacks cannot panic or have observable side effects outside their supplied output row.
- Constants can reduce callback evaluations. Rejected deferred evidence can cause reevaluation.
- Preparation belongs to one invocation. Constants can change, and a retry prepares again.
- `INFALLIBLE` describes row semantics. It does not promise that decoding or allocation succeeds.

Use `visit` for owned output, `visit_into` for a sink, and their `visit_prepared*` forms for shared
invocation state. Owned output cannot require `Drop`. Its default value is only a placeholder for
null rows. Use `visit_deferred` when a compact OR-reduced value can record row failures. Its default
must mean success, including when no rows execute. Failure evidence cannot be wider than the output.

`visit_bool` and `visit_deferred_bool` pack directly into host storage on dense paths. Their const
parameter selects the existing multiversioned packing mode. This is a code-generation choice that
requires measurement for the actual callback. Selected and filtered paths retain ordinary Boolean
output storage.

An uninitialized sink callback must return evidence for its exact supplied row. The
`InitializedElement::write` and `InitializedRow::fill` constructors are unsafe because their tokens
cannot encode that relationship. A token from a different slot, a subslice, or an earlier callback
cannot authorize publication. Initialization must remain intact until the callback returns.

## Adapter authors

Implement binding traits on a local host marker. `Host` supplies the associated column, native type,
context, and error types. It does not contain decoding or execution operations.

| Capability | Responsibility |
| --- | --- |
| `TypeBinding` | Outer nullability and value-preserving output labels. |
| `InputBinding<K>` | Semantic validation, retained decoded owners, and typed borrowed views. |
| `OutputBinding<T>` | Native output metadata, payload allocation, and collection. |
| `OutputBuffer<T>` | Stable slots, safe abandonment, and initialized-prefix publication. |
| `OutputSink<H>` | Stable row identity, initialization, and host-specific finalization. |
| `BooleanOutput` | Direct packing into host-owned bitmap storage. |
| `BatchBinding` | Validity, filtering, constants, and final publication. |

A row kind defines a Rust value family, such as `i64`, `&str`, or `&[f64]`. Its input binding owns the
decoded representation and lends values through `RowView`. Views cannot outlive their decoded owner.
Prepared values and row callbacks stay inside that owner's invocation scope. No storage receives a
manufactured `'static` lifetime.

Validate semantics before exposing physical storage. An unknown extension is not an integer merely
because it stores 64-bit values. Outer nullability can change independently of nested constraints.
The [timestamp domain](../rofl-examples/src/timestamp.rs) demonstrates a downstream row kind and
bindings for both hosts without changes to this crate.

Generic primitive bindings belong on the adapter's local marker. Keep their bounds limited to the
adapter's supported primitive mappings. Downstream packages can then implement bindings for their
own row kinds without a universal blanket implementation occupying that space.

`RowView`, `OutputBuffer`, `OutputSink`, and `BooleanOutput` are unsafe contracts. Shared lane sources
also implement the unsafe `IndexedSource` trait. In particular, a Boolean collector must never call
its closure with an index outside the requested row count. That closure can contain unchecked reads.

### Ownership and errors

`OutputBuffer` is an unsafe contract. Its slots and their contents must remain stable across views
and moves. Dropping partially initialized storage must be safe. `finish` may read only the initialized
prefix that its caller establishes. The finished result belongs to the host. Primitive adapters can
publish the same payload allocation without a second collector.

`OutputSink` also requires stable row identity and safe abandonment after an error or unwind.
Skipped rows are initialized before selected traversal. An initialized string sink can use `()` as
its token because every row is already safe to publish. A host can report a representation or
finalization failure after traversal, but that failure remains terminal.

The executor distinguishes semantic row fallibility, decoder fallibility, null-payload access, and
infrastructure failure. Only rejection by a deferred visitor's finish callback can trigger a dense
retry or null-based error suppression. Decoder, allocation, validation, and publication errors return
directly. A decoder can decline null-tolerant access before decoding, which selects filtering instead.

`BatchBinding::validity` must preserve lazy validity where the host supports it. Dense success never
requests a selection. Selected traversal resolves validity, tries a safe view of the original
inputs, and otherwise filters inputs before scattering into the original output row positions.

## Invocation and registration

`execute` takes explicit operands, a logical row count, and planned output metadata. A length-one
array is not automatically a scalar. Nullary functions use the explicit row count, including zero.
A scalar-only batch can evaluate one row and ask the host to broadcast its result.

Registration remains a host concern. Vortex uses `VortexRowFn<F>` through its existing scalar-function
registry. The wrapper owns the Vortex ID and leaves serialization unsupported by default. A package
that needs serialization, optimizer rules, or statistics rules can implement its own vtable and
delegate execution to the adapter. Whole-batch functions continue to use that same registry directly.

`rofl` and `rofl-kernels` have no Arrow or Vortex dependencies. `rofl-arrow` depends on Arrow and this
framework. Cross-host fixtures live in `rofl-examples`, outside the independent packages. These Rust
traits do not define a stable binary ABI. Future FFI must define registration and invocation at the
batch boundary.
