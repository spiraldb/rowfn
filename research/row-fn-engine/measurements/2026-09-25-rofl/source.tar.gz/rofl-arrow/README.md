<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- SPDX-FileCopyrightText: Copyright the Vortex contributors -->

# rofl-arrow

`rofl-arrow` executes portable strict row functions directly on Arrow arrays. It owns Arrow decoding,
validity, allocation, and output fields. It does not construct Vortex arrays or depend on Vortex,
including through development dependencies.

The adapter is experimental and unpublished. It uses the workspace's locked Arrow 59.3.0 packages.
The implementation and conformance tests have not been compiled or executed yet.

## Batch interface

Supply an `ArrowOperand` for each argument, including its input `Field` and explicit `scalar` flag.
Array operands must match the logical batch length. Scalar operands must contain exactly one value,
including when the logical batch has zero rows. A length-one array remains an array unless the caller
marks it as a scalar.

Call `plan` with the input fields to obtain the output field. Pass that field, the operands, and the
logical row count to `invoke`. The result contains both an Arrow array and its planned field. The
field survives empty and all-null batches, including its nullability and semantic metadata.

```rust,ignore
let output = rofl_arrow::plan(&function, &options, &input_fields)?;
let result = rofl_arrow::invoke(&function, &options, &operands, batch_rows, output)?;
```

The function's semantic capabilities must map Arrow fields to supported row kinds. Native runtime
types remain in this adapter. Unknown Arrow extension metadata is rejected by ordinary primitive,
string, and list bindings. A dedicated domain binding must establish any additional interpretation.

## Storage mappings

| Input | Binding behavior |
| --- | --- |
| Signed and unsigned 8, 16, 32, and 64-bit integers, `Float32`, `Float64`. | Retain `ScalarBuffer` storage and borrow typed slices. |
| `Boolean`. | Retain bitmap storage and preserve bit offsets, including unaligned slices. |
| `Utf8`, `LargeUtf8`, `Utf8View`. | Retain the native array and lend validated strings. Null payloads read as empty strings. |
| Fixed-size lists of supported primitives. | Borrow child slices, retain runtime width, and reject nullable children. |
| Dictionaries of supported primitives or strings. | Materialize referenced logical rows through Arrow's `take` kernel before typed decoding. |
| Timestamp ticks. | Supplied by the external proof package, preserving units, timezone, and field metadata. |

Dictionary materialization preserves null keys and valid keys that refer to null values. The row
function does not evaluate unused dictionary entries. This is an explicit decoding path, not a
rewrite that evaluates the function once over every dictionary value.

Primitive results use Arrow-owned allocations and retain their payload allocation at publication.
Boolean dense paths pack directly into Arrow-owned bitmap storage. Initial string output uses
`Utf8View`, copying each result into output-owned storage. Results remain valid after input arrays
and decoded owners are dropped. View size limits produce terminal adapter errors.

Fixed-size-list output carries an explicit row count, so width zero does not erase batch length.
Unsupported nested nullability and semantic mappings return errors. Timestamp adjustment changes
integer ticks only. It performs no unit conversion, calendar arithmetic, or timezone conversion.

## Evidence and follow-up

Arrow-only invocation and allocation fixtures live in this package's `tests` directory. Cross-host
tests and focused benchmarks are in [`rofl-examples`](../rofl-examples). Compile-fail examples cover
borrowed owner lifetimes and initialization tokens. None has run for this extraction. Source review
is not evidence of memory safety or performance equivalence.

DataFusion can later wrap this invocation boundary. DuckDB and Velox need batch-level FFI designs.
Arrow C Data alone does not define function identity, registration, options, or invocation semantics.
