// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Existing Arrow scalar kernels versus complete rofl invocations with matched semantics.

use std::sync::Arc;

use arrow_array::Array;
use arrow_array::ArrayRef;
use arrow_array::Int64Array;
use arrow_array::Scalar;
use arrow_array::StringArray;
use arrow_array::StringViewArray;
use arrow_schema::ArrowError;
use arrow_schema::Field;
use divan::Bencher;
use divan::black_box;
use rofl_arrow::ArrowOperand;
use rofl_examples::Concat;
use rofl_examples::Multiply;
use rofl_examples::NoOptions;
use rofl_examples::StringPredicate;
use vortex_error::VortexExpect;

const SIZES: &[usize] = &[0, 64, 1024, 16_384];

#[derive(Clone, Copy, Debug)]
enum Case {
    StartsWithScalar,
    StartsWithArray,
    StartsWithUtf8Scalar,
    EndsWithScalar,
    EndsWithArray,
    ContainsScalar,
    ContainsArray,
    ContainsScalarDense,
    ContainsUtf8Scalar,
    AsciiEqScalar,
    AsciiEqArray,
    ConcatShort,
    ConcatLong,
    ConcatLongDense,
    MultiplyScalar,
    MultiplyArray,
    MultiplyArrayDense,
}

const CASES: &[Case] = &[
    Case::StartsWithScalar,
    Case::StartsWithArray,
    Case::StartsWithUtf8Scalar,
    Case::EndsWithScalar,
    Case::EndsWithArray,
    Case::ContainsScalar,
    Case::ContainsArray,
    Case::ContainsScalarDense,
    Case::ContainsUtf8Scalar,
    Case::AsciiEqScalar,
    Case::AsciiEqArray,
    Case::ConcatShort,
    Case::ConcatLong,
    Case::ConcatLongDense,
    Case::MultiplyScalar,
    Case::MultiplyArray,
    Case::MultiplyArrayDense,
];

impl Case {
    fn scalar(self) -> bool {
        matches!(self, Self::StartsWithScalar | Self::StartsWithUtf8Scalar | Self::EndsWithScalar
            | Self::ContainsScalar | Self::ContainsScalarDense | Self::ContainsUtf8Scalar
            | Self::AsciiEqScalar | Self::MultiplyScalar)
    }

    fn dense(self) -> bool {
        matches!(self, Self::ContainsScalarDense | Self::ConcatLongDense | Self::MultiplyArrayDense)
    }

    fn concat(self) -> bool {
        matches!(self, Self::ConcatShort | Self::ConcatLong | Self::ConcatLongDense)
    }

    fn multiply(self) -> bool {
        matches!(self, Self::MultiplyScalar | Self::MultiplyArray | Self::MultiplyArrayDense)
    }

    fn predicate(self) -> StringPredicate {
        match self {
            Self::StartsWithScalar | Self::StartsWithArray | Self::StartsWithUtf8Scalar => StringPredicate::StartsWith,
            Self::EndsWithScalar | Self::EndsWithArray => StringPredicate::EndsWith,
            Self::ContainsScalar | Self::ContainsArray | Self::ContainsScalarDense | Self::ContainsUtf8Scalar => StringPredicate::Contains,
            Self::AsciiEqScalar | Self::AsciiEqArray => StringPredicate::EqIgnoreAsciiCase,
            _ => unreachable!("numeric and concatenation cases select their own function"),
        }
    }
}

struct Fixture {
    case: Case,
    inputs: [ArrowOperand; 2],
    rows: usize,
    output: Field,
}

fn operand(column: ArrayRef, scalar: bool) -> ArrowOperand {
    ArrowOperand {
        dtype: Field::new("input", column.data_type().clone(), column.null_count() != 0),
        column,
        scalar,
    }
}

impl Fixture {
    fn new(case: Case, rows: usize) -> Result<Self, ArrowError> {
        let valid = |index: usize, right: bool| {
            case.dense() || if right { !index.is_multiple_of(11) } else { !index.is_multiple_of(8) }
        };
        let inputs = if case.multiply() {
            let left = Int64Array::from_iter((0..rows).map(|index| valid(index, false).then_some(index as i64 - 512)));
            let right = if case.scalar() {
                Int64Array::from(vec![3])
            } else {
                Int64Array::from_iter((0..rows).map(|index| valid(index, true).then_some((index % 7) as i64 - 3)))
            };
            [operand(Arc::new(left), false), operand(Arc::new(right), case.scalar())]
        } else {
            let values = [
                "arrow needle tail",
                "ARROW NEEDLE TAIL",
                "other payload without a match",
                "arrow λneedle tail",
                "",
                "λ café 🙂",
                "arrow a longer payload with the needle near the end and a tail",
                "somethingneedle",
            ];
            let pattern = match case {
                Case::StartsWithScalar | Case::StartsWithUtf8Scalar => "arrow",
                Case::EndsWithScalar => "tail",
                Case::AsciiEqScalar => "ARROW NEEDLE TAIL",
                _ => "needle",
            };
            let left: Vec<_> = (0..rows + 3).map(|index| {
                valid(index, false).then_some(if matches!(case, Case::ConcatShort) {
                    ["arrow", "λ", "", "data"][index % 4]
                } else {
                    values[index % values.len()]
                })
            }).collect();
            let right: Vec<_> = if case.scalar() {
                vec![Some(pattern)]
            } else {
                (0..rows + 3).map(|index| valid(index, true).then_some(if case.concat() {
                    if matches!(case, Case::ConcatShort) { "-rs" } else { "-suffix with owned bytes" }
                } else {
                    ["arrow", "TAIL", "needle", "absent", "", "λ", "tail", "NEEDLE"][index % 8]
                })).collect()
            };
            let array = |values: Vec<Option<&str>>, scalar: bool| -> ArrayRef {
                let array: ArrayRef = if matches!(case, Case::StartsWithUtf8Scalar | Case::ContainsUtf8Scalar) {
                    Arc::new(StringArray::from(values))
                } else {
                    Arc::new(StringViewArray::from(values))
                };
                if scalar { array } else { array.slice(3, rows) }
            };
            [operand(array(left, false), false), operand(array(right, case.scalar()), case.scalar())]
        };
        let fields = inputs.each_ref().map(|input| input.dtype.clone());
        let output = if case.multiply() {
            rofl_arrow::plan(&Multiply, &NoOptions, &fields)?
        } else if case.concat() {
            rofl_arrow::plan(&Concat, &NoOptions, &fields)?
        } else {
            rofl_arrow::plan(&case.predicate(), &NoOptions, &fields)?
        };
        let fixture = Self { case, inputs, rows, output };
        assert_eq!(fixture.native()?.to_data(), fixture.invoke()?.to_data(), "{case:?}, {rows} rows");

        Ok(fixture)
    }

    fn invoke(&self) -> Result<ArrayRef, ArrowError> {
        let output = if self.case.multiply() {
            rofl_arrow::invoke(&Multiply, &NoOptions, &self.inputs, self.rows, self.output.clone())?
        } else if self.case.concat() {
            rofl_arrow::invoke(&Concat, &NoOptions, &self.inputs, self.rows, self.output.clone())?
        } else {
            rofl_arrow::invoke(&self.case.predicate(), &NoOptions, &self.inputs, self.rows, self.output.clone())?
        };

        Ok(output.array)
    }

    fn native(&self) -> Result<ArrayRef, ArrowError> {
        let left = &self.inputs[0].column;
        let right = &self.inputs[1].column;
        if self.case.concat() {
            return arrow_string::concat_elements::concat_elements_dyn(left.as_ref(), right.as_ref());
        }

        let scalar;
        let rhs: &dyn arrow_array::Datum = if self.case.scalar() {
            scalar = Scalar::new(right);
            &scalar
        } else {
            right
        };
        if self.case.multiply() {
            return arrow_arith::numeric::mul(left, rhs);
        }

        let values = match self.case.predicate() {
            StringPredicate::StartsWith => arrow_string::like::starts_with(left, rhs)?,
            StringPredicate::EndsWith => arrow_string::like::ends_with(left, rhs)?,
            StringPredicate::Contains => arrow_string::like::contains(left, rhs)?,
            StringPredicate::EqIgnoreAsciiCase => arrow_string::like::eq_ignore_ascii_case(left, rhs)?,
        };

        Ok(Arc::new(values))
    }
}

#[divan::bench(args = CASES, consts = SIZES)]
fn arrow_native<const ROWS: usize>(bencher: Bencher, case: &Case) {
    let fixture = Fixture::new(*case, ROWS).vortex_expect("matched fixture results");
    bencher.bench(|| black_box(&fixture).native().vortex_expect("validated Arrow kernel"));
}

#[divan::bench(args = CASES, consts = SIZES)]
fn arrow_rofl<const ROWS: usize>(bencher: Bencher, case: &Case) {
    let fixture = Fixture::new(*case, ROWS).vortex_expect("matched fixture results");
    bencher.bench(|| black_box(&fixture).invoke().vortex_expect("validated rofl invocation"));
}

fn main() {
    divan::main();
}
