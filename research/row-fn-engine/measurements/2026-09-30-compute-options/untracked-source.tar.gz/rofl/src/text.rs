// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

//! Borrowed text operations that can retain a host's string-view metadata.

use crate::InputBinding;
use crate::RowKind;
use crate::Utf8;

/// A valid UTF-8 value whose binding can use stored lengths and prefixes.
pub trait TextValue {
    /// Borrow the complete string.
    fn as_str(&self) -> &str;

    /// Return the UTF-8 byte length without reading referenced storage when possible.
    fn byte_len(&self) -> usize { self.as_str().len() }

    /// Return an equality key for a complete inline value, when the binding has one.
    /// Keys compare equal exactly when the strings do. Implementations that return keys must
    /// use the same encoding for values that can be compared with each other.
    fn inline_eq_key(&self) -> Option<u128> { None }

    /// Return a sort key for a complete inline value, when the binding has one.
    /// Key order must match UTF-8 byte order, including equality. Implementations that return
    /// keys must use the same ordering for values that can be compared with each other.
    fn inline_key(&self) -> Option<u128> { None }

    /// Borrow the first `len` bytes, or an empty slice when the string is shorter.
    /// The byte range need not end at a character boundary.
    fn prefix(&self, len: usize) -> &[u8] {
        self.as_str().as_bytes().get(..len).unwrap_or_default()
    }

    /// Borrow the last `len` bytes, or an empty slice when the string is shorter.
    /// The byte range need not start at a character boundary.
    fn suffix(&self, len: usize) -> &[u8] {
        let bytes = self.as_str().as_bytes();
        bytes.get(bytes.len().wrapping_sub(len)..).unwrap_or_default()
    }
}

impl TextValue for &str {
    fn as_str(&self) -> &str { self }
}

/// A host's string row family, retaining metadata until the function requests bytes.
///
/// The value family must implement [`TextValue`]. Functions state that bound on its borrowed value.
/// The ordinary [`crate::Utf8`] family remains available for functions that need only `&str`.
pub trait TextBinding: InputBinding<Self::Text> + InputBinding<Utf8> {
    /// The row kind used by text operations on this host.
    type Text: RowKind;

    /// Whether a native string type uses the host's view representation.
    /// Dispatch calls this before selecting a typed visitor, never inside the row loop.
    fn uses_views(dtype: &Self::NativeType) -> bool;
}
